# Host a match from the join window: open a lobby on this PC, see who joins, start the match,
# stop the server. Dot-sourced by Join-Prophecy.ps1 (which owns the main window, the name/leader
# pick, the update check and the patcher); it only defines functions and the Host window.
#
# Every friend's copy carries the whole host patch set (client-patches.json), so the lobby works
# like the dev launcher's Host page: the match holds while HoldMatch.flag sits next to Phoenix.exe,
# and Start match deletes it. Joiners need the same published version as the host, so the window
# only opens a lobby when this copy is on the newest version from the update feed.
#
# Reaching the host:
#   LAN       other PCs in the same house join this PC's LAN address directly.
#   Internet  the window asks the router to forward the game port (UDP) to this PC: UPnP first
#             (Windows' built-in HNetCfg.NATUPnP, nothing installed), then NAT-PMP (UDP to the
#             gateway's port 5351). The forward is removed again by Stop server. It can't work
#             when the router has both turned off, or behind carrier-grade NAT (the router's own
#             outside address is private, e.g. 100.64.x.x): the window says so, and a tunnel
#             (playit.gg, Tailscale, Radmin VPN) set up by the host is the fallback.
#   Windows Firewall asks once, the first time the game listens; the host clicks Allow.
#
# Needs only Windows PowerShell 5.1. Nothing is installed.

# ---- the host's game log --------------------------------------------------------------------
# A small twin of launcher\core\hostlog.py: follows each connection from first packet to leaving,
# plus the match state and round. Pure functions over a hashtable, so it can be checked without
# Windows (launcher\tools\test_host_prophecy.ps1).

$HostLogRx = [ordered]@{
  listen  = 'IpNetDriver listening on port (\d+)'
  accept  = 'NotifyAcceptingConnection accepted from: ([\d.]+:\d+)'
  conn    = 'AddClientConnection: Added client connection: .*?RemoteAddr: ([^,\s]+)'
  version = 'Client connecting with invalid version'
  login   = 'Login request: \?Name=([^?\s]+)(\S*)'
  leader  = 'LeaderPick: player (\d+) asked (-?\d+), got (\d+)'
  pname   = 'PlayerName: player (\d+) is (\S+)'
  join    = 'Join succeeded: (.+)'
  timeout = 'Connection TIMED OUT.*?RemoteAddr: ([^,\s]+)'
  close   = 'UNetConnection::Close: .*?RemoteAddr: ([^,\s]+)'
  state   = 'Match State Changed from \w+ to (\w+)'
  fight   = 'Unit composition for board (\d+), round (\d+), player (\S+) against opponent (\S+?) ##'
  exit    = 'LogExit: (Game engine shut down|Preparing to exit)'
}
$HostGone = @('wrong version', 'timed out', 'left')
$HostPreMatch = @('', 'EnteringMap', 'WaitingToStart')
$HostPhases = @{ Introductions = 'intro'; Prepare = 'shopping'; Standby = 'about to fight'; Combat = 'fighting'
  Result = 'results'; Transition = 'next round'; InProgress = 'starting'; WaitingToStart = 'waiting in the lobby'
  EnteringMap = 'loading'; WaitingPostMatch = 'match over'; LeavingMap = 'closing' }

function New-HostLog {
  param([datetime]$After = [datetime]::MinValue)  # skip lines stamped before this (UTC): an older game's log
  @{ players = [ordered]@{}; port = 0; state = ''; round = 0; events = New-Object System.Collections.ArrayList
     conn = $null; login = $null; ids = @{}; exiting = $false; after = $After; now = $null }
}

function New-HostPlayer($key, $status) {
  [pscustomobject]@{ key = $key; status = $status; pc = ''; name = ''; leader = 0; ghost = $false; since = (Get-Date) }
}

function Get-HostPlayerLabel($p) { if ($p.name) { $p.name } elseif ($p.pc) { $p.pc } else { $p.key } }

function Set-HostPlayerStatus($p, $status) { if ($p.status -ne $status) { $p.status = $status; $p.since = Get-Date } }

function Add-HostEvent($log, $text) {
  # The time the game logged it (UTC stamp, shown in local time), else now.
  $t = if ($log.now) { $log.now.ToLocalTime() } else { Get-Date }
  [void]$log.events.Add(('{0:HH:mm:ss}  {1}' -f $t, $text))
  while ($log.events.Count -gt 200) { $log.events.RemoveAt(0) }
}

# One log line into $log.
function Update-HostLog($log, [string]$line) {
  # "[2026.10.31-11.38.50:625][...]": the game stamps its log in UTC.
  $ts = [regex]::Match($line, '^\[(\d{4})\.(\d\d)\.(\d\d)-(\d\d)\.(\d\d)\.(\d\d)')
  if ($ts.Success) {
    $v = @(1..6 | ForEach-Object { [int]$ts.Groups[$_].Value })
    $log.now = New-Object DateTime($v[0], $v[1], $v[2], $v[3], $v[4], $v[5], [DateTimeKind]::Utc)
  }
  if ($log.now -and $log.now -lt $log.after) { return }
  foreach ($kind in $HostLogRx.Keys) {
    $m = [regex]::Match($line, $HostLogRx[$kind])
    if (-not $m.Success) { continue }
    $g = @($m.Groups | Select-Object -Skip 1 | ForEach-Object { $_.Value })
    switch ($kind) {
      'listen' { $log.port = [int]$g[0]; Add-HostEvent $log "Server listening on port $($g[0])" }
      'accept' {
        $p = $log.players[$g[0]]
        if (-not $p -or $HostGone -contains $p.status) {
          if ($p) { $log.players.Remove($g[0]) }
          $log.players[$g[0]] = New-HostPlayer $g[0] 'connecting'
          Add-HostEvent $log "Someone is connecting from $($g[0])"
        }
      }
      'conn' {
        $p = $log.players[$g[0]]
        if (-not $p) { $p = New-HostPlayer $g[0] 'connecting'; $log.players[$g[0]] = $p }
        Set-HostPlayerStatus $p 'logging in'
        $log.conn = $g[0]
      }
      'version' {
        $p = if ($log.conn) { $log.players[$log.conn] } else { $null }
        if ($p) { Set-HostPlayerStatus $p 'wrong version'; Add-HostEvent $log "Refused $(Get-HostPlayerLabel $p): different game version (they press Update, then Join)" }
        else { Add-HostEvent $log 'Refused a player: different game version (they press Update, then Join)' }
      }
      'login' {
        $key = if ($log.conn) { $log.conn } else { 'host' }
        $log.conn = $null
        $p = $log.players[$key]
        if (-not $p) { $p = New-HostPlayer $key 'logging in'; $log.players[$key] = $p }
        Set-HostPlayerStatus $p 'logging in'
        $p.pc = $g[0] -replace '-[0-9A-Fa-f]{16,}$', ''
        $nick = [regex]::Match($g[1], '\?Nick=([^?\s]+)', 'IgnoreCase')
        $p.name = if ($nick.Success) { $nick.Groups[1].Value } else { $p.pc }
        $log.login = $key
      }
      'leader' { $log.ids[$g[0]] = [int]$g[2] }
      'pname' {
        $p = if ($log.login) { $log.players[$log.login] } else { $null }
        if (-not $p -and -not $log.players.Contains('host')) {
          # The host's own player has no Login request line; its name line is its join.
          $st = if ($HostPreMatch -contains $log.state) { 'in lobby' } else { 'playing' }
          $p = New-HostPlayer 'host' $st
          $log.players['host'] = $p
        }
        if ($p) {
          if ($log.ids.ContainsKey($g[0])) { $p.leader = $log.ids[$g[0]]; $log.ids.Remove($g[0]) }
          $p.name = $g[1]
        }
      }
      'join' {
        $p = if ($log.login) { $log.players[$log.login] } else { $null }
        if (-not $p) { break }
        $n = $g[0].Trim()
        if ($n -and $n -notmatch '^Player \d+$') { $p.name = $n }
        $st = if ($HostPreMatch -contains $log.state) { 'in lobby' } else { 'playing' }
        Set-HostPlayerStatus $p $st
        $log.login = $null
        # The same PC joining again leaves its old connection open until it times out (25 s).
        foreach ($o in @($log.players.Values)) {
          if ($o -ne $p -and $o.key -ne 'host' -and $o.pc -eq $p.pc -and $HostGone -notcontains $o.status) { $o.ghost = $true }
        }
        if ($p.key -ne 'host') { Add-HostEvent $log "$(Get-HostPlayerLabel $p) joined" }
      }
      'timeout' {
        $p = $log.players[$g[0]]
        if ($p -and $HostGone -notcontains $p.status) { Set-HostPlayerStatus $p 'timed out'; Add-HostEvent $log "$(Get-HostPlayerLabel $p) timed out (no packets for 25 s)" }
      }
      'close' {
        $p = $log.players[$g[0]]
        if ($p -and $HostGone -notcontains $p.status) { Set-HostPlayerStatus $p 'left'; Add-HostEvent $log "$(Get-HostPlayerLabel $p) left" }
      }
      'state' {
        if ($g[0] -eq $log.state) { break }  # GameMode and GameState both log each change
        $before = $log.state
        $log.state = $g[0]
        if ($HostPreMatch -contains $before -and $HostPreMatch -notcontains $g[0]) {
          foreach ($p in @($log.players.Values)) { if ($p.status -eq 'in lobby') { Set-HostPlayerStatus $p 'playing' } }
          Add-HostEvent $log 'Match started'
        }
      }
      'fight' { if ([int]$g[1] -ne $log.round) { $log.round = [int]$g[1]; Add-HostEvent $log "Round $($g[1]): fights begin" } }
      'exit' { if (-not $log.exiting) { $log.exiting = $true; Add-HostEvent $log 'Game is shutting down' } }
    }
    return
  }
}

# Players connected now, the host first.
function Get-HostPresent($log) {
  $rows = @($log.players.Values | Where-Object { $HostGone -notcontains $_.status })
  @($rows | Where-Object { $_.key -eq 'host' }) + @($rows | Where-Object { $_.key -ne 'host' })
}

function Get-HostPhase($log) {
  if ($HostPhases.ContainsKey($log.state)) { $HostPhases[$log.state] } elseif ($log.state) { $log.state } else { 'not started' }
}

# ---- addresses and the router ---------------------------------------------------------------

# This PC's LAN address: the one Windows uses for its default route.
function Get-LanIp {
  try {
    $s = New-Object Net.Sockets.Socket([Net.Sockets.AddressFamily]::InterNetwork, [Net.Sockets.SocketType]::Dgram, [Net.Sockets.ProtocolType]::Udp)
    $s.Connect('192.0.2.1', 9)  # UDP connect sends nothing; it only picks a route
    $ip = $s.LocalEndPoint.Address.IPAddressToString
    $s.Close()
    return $ip
  } catch { return '' }
}

# True for addresses nobody outside can reach: private ranges and carrier-grade NAT (100.64/10).
function Test-PrivateIp([string]$ip) {
  $b = @($ip -split '\.' | ForEach-Object { [int]$_ })
  if ($b.Count -ne 4) { return $true }
  return ($b[0] -eq 10) -or ($b[0] -eq 127) -or ($b[0] -eq 0) -or ($b[0] -eq 192 -and $b[1] -eq 168) -or
    ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or ($b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127) -or
    ($b[0] -eq 169 -and $b[1] -eq 254)
}

# Runs in a background job (Start-Job), so the window stays responsive while the router answers.
# Action 'open' forwards UDP $Port to $LanIp, 'close' removes the forward. Prints lines:
#   OK <upnp|natpmp> <outside address>      forward in place
#   PRIVATE <upnp|natpmp> <outside address> forward made, but the router's outside address is
#                                           private (carrier-grade or double NAT): useless
#   FAIL <why>                              no router answered, or it refused
#   CLOSED <upnp|natpmp|none>
$RouterScript = {
  param([string]$Action, [int]$Port, [string]$LanIp, [string]$Label = 'Prophecy Rewritten', [string]$Gateway = '', [switch]$NoUpnp)
  function Test-Private([string]$ip) {
    $b = @($ip -split '\.' | ForEach-Object { [int]$_ })
    if ($b.Count -ne 4) { return $true }
    return ($b[0] -eq 10) -or ($b[0] -eq 192 -and $b[1] -eq 168) -or ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or
      ($b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127) -or ($b[0] -eq 0)
  }
  function Get-Gateway {
    if ($Gateway) { return $Gateway }
    try {
      $r = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled = true' -ErrorAction Stop |
        Where-Object { $_.DefaultIPGateway } | Select-Object -First 1
      return @($r.DefaultIPGateway | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' })[0]
    } catch { return $null }
  }
  # NAT-PMP (RFC 6886): one UDP request to the gateway's port 5351, answer within 2 s.
  function Send-NatPmp([string]$gw, [byte[]]$req) {
    $u = New-Object Net.Sockets.UdpClient
    try {
      $u.Client.ReceiveTimeout = 2000
      $u.Connect($gw, 5351)
      [void]$u.Send($req, $req.Length)
      $ep = New-Object Net.IPEndPoint([Net.IPAddress]::Any, 0)
      return $u.Receive([ref]$ep)
    } catch { return $null } finally { $u.Close() }
  }
  function Get-PortBytes([int]$v) { $hi = ($v -shr 8) -band 255; $lo = $v -band 255; return [byte[]]@($hi, $lo) }
  function Invoke-NatPmpMap([string]$gw, [int]$lifetime) {
    $life = [BitConverter]::GetBytes([uint32]$lifetime); [Array]::Reverse($life)
    $req = [byte[]](@(0, 1, 0, 0) + (Get-PortBytes $Port) + (Get-PortBytes $Port) + $life)
    $r = Send-NatPmp $gw $req
    return ($r -and $r.Length -ge 16 -and $r[1] -eq 129 -and $r[2] -eq 0 -and $r[3] -eq 0)
  }

  $why = @()
  if ($Action -eq 'open') {
    # UPnP through Windows' own NAT traversal object. StaticPortMappingCollection is $null when no
    # UPnP router answered (UPnP off, or Windows' discovery service off).
    try {
      if ($NoUpnp) { throw 'skipped' }
      $nat = New-Object -ComObject HNetCfg.NATUPnP
      $maps = $nat.StaticPortMappingCollection
      if ($maps) {
        try { $maps.Remove($Port, 'UDP') } catch { }
        $m = $maps.Add($Port, 'UDP', $Port, $LanIp, $true, $Label)
        $ext = [string]$m.ExternalIPAddress
        if ($ext) { if (Test-Private $ext) { "PRIVATE upnp $ext" } else { "OK upnp $ext" }; return }
        $why += 'the router took the UPnP forward but gave no outside address'
      } else { $why += 'no router answered UPnP' }
    } catch { $why += "UPnP failed ($($_.Exception.Message.Trim()))" }
    $gw = Get-Gateway
    if ($gw) {
      $r = Send-NatPmp $gw ([byte[]]@(0, 0))
      if ($r -and $r.Length -ge 12 -and $r[1] -eq 128 -and $r[2] -eq 0 -and $r[3] -eq 0) {
        $ext = '{0}.{1}.{2}.{3}' -f $r[8], $r[9], $r[10], $r[11]
        if (Invoke-NatPmpMap $gw 7200) { if (Test-Private $ext) { "PRIVATE natpmp $ext" } else { "OK natpmp $ext" }; return }
        $why += 'the router refused the NAT-PMP forward'
      } else { $why += 'no router answered NAT-PMP' }
    } else { $why += 'no gateway found' }
    "FAIL $($why -join '; ')"
    return
  }
  if ($Action -eq 'close') {
    $done = 'none'
    try {
      $maps = (New-Object -ComObject HNetCfg.NATUPnP).StaticPortMappingCollection
      if ($maps) { $maps.Remove($Port, 'UDP'); $done = 'upnp' }
    } catch { }
    $gw = Get-Gateway
    if ($gw -and (Invoke-NatPmpMap $gw 0)) { $done = 'natpmp' }
    "CLOSED $done"
  }
}


# ---- the Host window --------------------------------------------------------------------------
# Uses from Join-Prophecy.ps1: $form, $bin, $bundle, $cfg, $leaders, $nameBox, $pick, $logFile,
# $fg, $dim, $good, $bad, $gold, Assert-CanStart, Update-FromHost, Get-OurGame, Get-Cfg, Save-Cfg,
# New-RandomName, Get-Version. Everything here lives in script scope ($script:hostUi holds the
# controls), because the window's event handlers run after Show-HostWindow has returned.

function Set-HostMsg($text, $color) {
  $u = $script:hostUi
  $u.msg.Text = $text
  $u.msg.ForeColor = if ($color) { $color } else { $dim }
  $u.win.Refresh()
}

function Get-HostLeaderName($id) {
  if (-not $id) { return 'random' }
  $l = $leaders | Where-Object { [int]$_.id -eq [int]$id } | Select-Object -First 1
  if ($l) { $l.name } else { "$id" }
}

function Update-HostWho {
  $leaderText = if ($pick.SelectedIndex -gt 0) { $leaders[$pick.SelectedIndex - 1].name } else { 'a random leader' }
  $nm = if ($nameBox.Text) { $nameBox.Text } else { '(random name)' }
  $script:hostUi.who.Text = "You play as $nm with $leaderText (change these in the main window)."
}

# The router job's answer, shown in the address box and the note under it.
function Show-RouterResult([string]$line) {
  $u = $script:hostUi
  $port = $script:hostPort
  $script:routerState = $line
  $parts = $line -split ' ', 3
  switch ($parts[0]) {
    'OK' {
      $u.netBox.Text = "$($parts[2]):$port"
      $how = if ($parts[1] -eq 'upnp') { 'UPnP' } else { 'NAT-PMP' }
      $u.netNote.Text = "Your router forwards port $port to this PC ($how) until you press Stop server. If friends still can't get in, your internet provider may block it: use a tunnel (playit.gg, Tailscale or Radmin VPN) and give them that address instead."
      $u.netNote.ForeColor = $good
    }
    'PRIVATE' {
      $u.netBox.Text = ''
      # 100.64/10 is the provider's shared range; any other private address means a second router
      # (usually the provider's modem) sits in front of this one.
      $cg = $parts[2] -match '^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.'
      $u.netNote.Text = if ($cg) { "Your router opened the port, but its outside address ($($parts[2])) is shared: your internet provider puts many homes behind one address, so friends can't reach you this way. Use a tunnel (playit.gg, Tailscale or Radmin VPN), or let someone else host." }
        else { "Your router opened the port, but there is a second router in front of it (its outside address $($parts[2]) is private), usually the internet provider's modem. Put the modem in bridge mode, or forward UDP $port on it to your router, or use a tunnel (playit.gg, Tailscale or Radmin VPN)." }
      $u.netNote.ForeColor = $bad
    }
    default {
      $u.netBox.Text = ''
      $u.netNote.Text = "Your router didn't open the port ($((@($parts) | Select-Object -Skip 1) -join ' ')). Turn on UPnP in your router's settings, or use a tunnel (playit.gg, Tailscale or Radmin VPN). Friends in your house can still use the LAN address."
      $u.netNote.ForeColor = $bad
    }
  }
}

function Start-Router([string]$action) {
  if ($script:routerJob) { Remove-Job $script:routerJob -Force -ErrorAction SilentlyContinue }
  $script:routerJob = Start-Job -ScriptBlock $RouterScript -ArgumentList $action, $script:hostPort, $script:hostLanIp
  $script:routerAction = $action
  $script:routerStart = Get-Date
}

# Removes the router forward this window made (waits up to 10 s for the router).
function Close-Router {
  if ($script:routerState -notmatch '^(OK|PRIVATE) ') { return }
  Start-Router 'close'
  Wait-Job $script:routerJob -Timeout 10 | Out-Null
  Remove-Job $script:routerJob -Force -ErrorAction SilentlyContinue
  $script:routerJob = $null
  $script:routerState = ''
}

# Ends the game from this folder: asks its window to close, forces it after 8 s, and ends a crash
# reporter from this folder (a host closed late in a match can hang, then report a crash).
function Stop-HostGame {
  foreach ($p in @(Get-OurGame)) { try { [void]$p.CloseMainWindow() } catch { } }
  $end = (Get-Date).AddSeconds(8)
  while (@(Get-OurGame).Count -and (Get-Date) -lt $end) { Start-Sleep -Milliseconds 300; [Windows.Forms.Application]::DoEvents() }
  Get-OurGame | Stop-Process -Force -ErrorAction SilentlyContinue
  Get-Process AutoReporter -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$bundle\*" } | Stop-Process -Force -ErrorAction SilentlyContinue
  Remove-Item $script:holdFlag -ErrorAction SilentlyContinue
}

# Once a second: the router's answer, new game log lines, and the buttons.
function Update-HostWindow {
  $u = $script:hostUi
  $j = $script:routerJob
  if ($j -and $script:routerAction -eq 'open') {
    if ($j.State -in 'Completed', 'Failed', 'Stopped') {
      $out = @(Receive-Job $j -ErrorAction SilentlyContinue | ForEach-Object { "$_" })
      Remove-Job $j -Force -ErrorAction SilentlyContinue
      $script:routerJob = $null
      $line = [string]($out | Where-Object { $_ -match '^(OK|PRIVATE|FAIL) ' } | Select-Object -Last 1)
      if (-not $line) { $line = 'FAIL the router check ended without an answer' }
      Show-RouterResult $line
    } elseif (((Get-Date) - $script:routerStart).TotalSeconds -gt 30) {
      Stop-Job $j -ErrorAction SilentlyContinue
      Remove-Job $j -Force -ErrorAction SilentlyContinue
      $script:routerJob = $null
      Show-RouterResult 'FAIL no router answered within 30 s'
    }
  }
  if (Test-Path $logFile) {
    try {
      $fs = [IO.File]::Open($logFile, 'Open', 'Read', 'ReadWrite')
      try {
        if ($fs.Length -lt $script:hostPos) { $script:hostPos = 0; $script:hostLog = New-HostLog -After $script:hostLog.after }
        [void]$fs.Seek($script:hostPos, 'Begin')
        $text = (New-Object IO.StreamReader($fs)).ReadToEnd()
        $script:hostPos = $fs.Length
      } finally { $fs.Close() }
      foreach ($l in ($text -split "`r?`n")) { if ($l) { Update-HostLog $script:hostLog $l } }
    } catch { }
  }
  $hl = $script:hostLog
  $present = @(Get-HostPresent $hl)
  $u.list.BeginUpdate()
  $u.list.Items.Clear()
  foreach ($p in $present) {
    $st = $p.status
    if ($p.key -eq 'host') { $st += ' (you)' }
    if ($p.ghost) { $st += ', old connection' }
    $it = New-Object Windows.Forms.ListViewItem([string](Get-HostPlayerLabel $p))
    [void]$it.SubItems.Add([string](Get-HostLeaderName $p.leader))
    [void]$it.SubItems.Add($st)
    [void]$u.list.Items.Add($it)
  }
  $u.list.EndUpdate()
  $evText = (@($hl.events) | Select-Object -Last 30) -join "`r`n"
  if ($u.events.Text -ne $evText) { $u.events.Text = $evText; $u.events.SelectionStart = $evText.Length; $u.events.ScrollToCaret() }
  if (-not (Get-OurGame)) {
    $u.phase.Text = if ($script:hostOpened) { 'Server stopped.' } else { 'No lobby open.' }
    $u.open.Enabled = $true; $u.start.Enabled = $false; $u.stop.Enabled = $false
    if ($script:hostOpened) { $script:hostOpened = $false; Close-Router }
    return
  }
  $u.open.Enabled = $false
  $u.stop.Enabled = $true
  $u.start.Enabled = (Test-Path $script:holdFlag) -and $hl.state -eq 'WaitingToStart'
  $n = $present.Count
  if ($hl.state -in '', 'EnteringMap') { $u.phase.Text = 'Loading the lobby ...' }
  elseif ($hl.state -eq 'WaitingToStart') { $u.phase.Text = "Lobby open: $n player$(if ($n -ne 1) { 's' }) in. Press Start match when everyone is here." }
  else { $u.phase.Text = "Match running: $(Get-HostPhase $hl)$(if ($hl.round) { ", round $($hl.round)" }). Bots fill the empty seats." }
}

function Open-HostLobby {
  $u = $script:hostUi
  try {
    Update-HostWho
    Assert-CanStart
    # Joiners must have this copy's version, so host the newest published one.
    $r = Update-FromHost
    if ($r -eq 'restarting') { return }
    if ($r -eq 'failed') { throw 'The update failed, so this copy may not match your friends. Press Update in the main window and try again.' }
    $leaderId = if ($pick.SelectedIndex -gt 0) { [int]$leaders[$pick.SelectedIndex - 1].id } else { 0 }
    $nameBox.Text = ($nameBox.Text -replace '[^A-Za-z0-9_.-]', '')
    if (-not $nameBox.Text) { $nameBox.Text = New-RandomName }
    $cfg | Add-Member -NotePropertyName leader -NotePropertyValue $leaderId -Force
    $cfg | Add-Member -NotePropertyName name -NotePropertyValue $nameBox.Text -Force
    $cfg | Add-Member -NotePropertyName host_open_port -NotePropertyValue $u.upnp.Checked -Force
    if (-not $u.upnp.Checked) { $cfg | Add-Member -NotePropertyName host_address -NotePropertyValue $u.netBox.Text.Trim() -Force }
    Save-Cfg
    if (Test-Path $logFile) { Move-Item $logFile ($logFile -replace '\.log$', '-previous.log') -Force -ErrorAction SilentlyContinue }
    $script:hostPos = 0
    $script:hostLog = New-HostLog -After ([DateTime]::UtcNow.AddSeconds(-5))
    $u.events.Text = ''
    $script:routerState = ''
    if ($u.upnp.Checked -and $script:hostLanIp) {
      $u.netBox.Text = ''
      $u.netNote.Text = 'Asking your router to open the port ...'
      $u.netNote.ForeColor = $dim
      Start-Router 'open'
    } else {
      $u.netNote.Text = if ($u.netBox.Text.Trim()) { "Friends outside your house join $($u.netBox.Text.Trim()). Keep your tunnel running while you host; it must forward to UDP $($script:hostPort) on this PC." }
        else { 'No tunnel address set, so only friends in your house can join (LAN address below). Paste your playit.gg address above for others.' }
      $u.netNote.ForeColor = $dim
    }
    Set-HostMsg 'Starting the game as host ...'
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $bin 'Start-Preset.ps1') -Role host -Preset ([string](Get-Cfg 'host_preset' 'play')) -HoldForHost -NoOverrides -Port $script:hostPort -Dev $bundle -Leader $leaderId -Name $nameBox.Text 2>&1
    if ($LASTEXITCODE) { throw ($out | Out-String) }
    $script:hostOpened = $true
    $note = if ($r -eq 'unreachable') { " Couldn't check for updates, so make sure friends have version $(Get-Version)." } else { '' }
    Set-HostMsg "The game is starting. The first time, Windows asks whether Prophecy may use the network: click Allow.$note" $good
  } catch {
    Set-HostMsg $_.Exception.Message $bad
  }
}

function New-HostControl($type, $x, $y, $wd, $ht, $text) {
  $c = New-Object "Windows.Forms.$type"
  $c.SetBounds($x, $y, $wd, $ht)
  if ($null -ne $text) { $c.Text = $text }
  if ($type -eq 'Button') { $c.FlatStyle = 'Flat' }
  $script:hostUi.win.Controls.Add($c)
  return $c
}

function Show-HostWindow {
  if ($script:hostUi -and -not $script:hostUi.win.IsDisposed) { $script:hostUi.win.Activate(); return }
  $script:hostPort = [int](Get-Cfg 'host_port' 7777)
  $script:hostLanIp = Get-LanIp
  $script:hostLog = New-HostLog
  $script:hostPos = 0
  $script:routerJob = $null
  $script:routerState = ''
  $script:hostOpened = [bool](Get-OurGame)
  $script:holdFlag = Join-Path $bin 'HoldMatch.flag'

  $w = New-Object Windows.Forms.Form
  $w.Text = "Host a Prophecy match (version $(Get-Version))"
  $w.ClientSize = New-Object Drawing.Size(520, 560)
  $w.FormBorderStyle = 'FixedDialog'
  $w.MaximizeBox = $false
  $w.StartPosition = 'CenterParent'
  $w.BackColor = $form.BackColor
  $w.ForeColor = $fg
  $w.Font = $form.Font
  $script:hostUi = @{ win = $w }
  $u = $script:hostUi

  $h = New-HostControl Label 18 12 480 30 'Host a match'
  $h.Font = New-Object Drawing.Font('Segoe UI', 14, [Drawing.FontStyle]::Bold)
  $h.ForeColor = $gold
  $u.who = New-HostControl Label 20 44 480 22 ''
  $u.who.ForeColor = $dim
  # Experimental: kept for later (2026-11-01: tunnels are the supported route for now).
  $u.upnp = New-HostControl CheckBox 20 68 480 24 'Experimental: ask my router to open the port instead of a tunnel'
  $u.upnp.Checked = [bool](Get-Cfg 'host_open_port' $false)
  $u.open = New-HostControl Button 20 98 150 34 'Open lobby'
  $u.open.Font = New-Object Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
  $u.open.BackColor = $gold
  $u.open.ForeColor = [Drawing.Color]::FromArgb(26, 26, 26)
  $u.start = New-HostControl Button 182 98 150 34 'Start match'
  $u.start.Enabled = $false
  $u.stop = New-HostControl Button 344 98 156 34 'Stop server'
  $u.stop.Enabled = $false
  [void](New-HostControl Label 20 144 480 22 'Give your friends this address (your playit.gg or other tunnel address):')
  $u.netBox = New-HostControl TextBox 20 168 380 26 ([string](Get-Cfg 'host_address' ''))
  $u.netBox.Font = New-Object Drawing.Font('Consolas', 11)
  $copy = New-HostControl Button 410 166 90 28 'Copy'
  $u.netNote = New-HostControl Label 20 198 480 52 'Paste your tunnel address (playit.gg, Tailscale or Radmin VPN) above for friends outside your house; it is saved for next time. Friends in your house can use the LAN address below.'
  $u.netNote.ForeColor = $dim
  $lanText = if ($script:hostLanIp) { "Same house (LAN): $($script:hostLanIp):$($script:hostPort)" } else { 'Same house (LAN): no network address found' }
  $lan = New-HostControl Label 20 252 480 22 $lanText
  $lan.ForeColor = $dim
  $u.phase = New-HostControl Label 20 282 480 22 'No lobby open.'
  $u.phase.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
  $u.list = New-HostControl ListView 20 308 480 130 $null
  $u.list.View = 'Details'
  $u.list.FullRowSelect = $true
  $u.list.HeaderStyle = 'Nonclickable'
  $u.list.BackColor = [Drawing.Color]::FromArgb(38, 42, 51)
  $u.list.ForeColor = $fg
  [void]$u.list.Columns.Add('Player', 160)
  [void]$u.list.Columns.Add('Leader', 110)
  [void]$u.list.Columns.Add('Status', 200)
  $u.events = New-HostControl TextBox 20 446 480 70 ''
  $u.events.Multiline = $true
  $u.events.ReadOnly = $true
  $u.events.ScrollBars = 'Vertical'
  $u.events.BackColor = [Drawing.Color]::FromArgb(38, 42, 51)
  $u.events.ForeColor = $dim
  $u.events.Font = New-Object Drawing.Font('Consolas', 8.5)
  $u.msg = New-HostControl Label 20 520 480 36 ''
  $u.msg.ForeColor = $dim
  Update-HostWho

  $copy.Add_Click({ if ($script:hostUi.netBox.Text) { [Windows.Forms.Clipboard]::SetText($script:hostUi.netBox.Text) } })
  $u.open.Add_Click({ Open-HostLobby })
  $u.start.Add_Click({
    Remove-Item $script:holdFlag -ErrorAction SilentlyContinue
    Set-HostMsg 'Match starting. Bots fill the empty seats.' $good
  })
  $u.stop.Add_Click({
    Set-HostMsg 'Stopping the server ...'
    Stop-HostGame
    Close-Router
    Set-HostMsg 'Server stopped.'
  })
  $u.tick = New-Object Windows.Forms.Timer
  $u.tick.Interval = 1000
  $u.tick.Add_Tick({ Update-HostWindow })
  $w.Add_FormClosing({
    param($s, $e)
    if ((Get-OurGame) -and $script:hostOpened) {
      $a = [Windows.Forms.MessageBox]::Show('Stop the server too? Players in your match will be dropped.', $s.Text, 'YesNoCancel', 'Question')
      if ($a -eq 'Cancel') { $e.Cancel = $true; return }
      if ($a -eq 'Yes') { Stop-HostGame }
    }
    if (-not (Get-OurGame)) { Close-Router }
    $script:hostUi.tick.Stop()
  })
  $u.tick.Start()
  $w.Show($form)
}
