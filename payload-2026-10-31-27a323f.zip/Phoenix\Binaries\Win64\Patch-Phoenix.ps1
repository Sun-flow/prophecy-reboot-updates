# Applies the player-side exe patches (client-patches.json, exported from
# research\prophecy\dev-copy\patches\phoenix_patches.py export-client) to a friend's Phoenix.exe.
# Friends have no Python, so this is the PowerShell twin of "phoenix_patches.py apply" (CLIENT_SET,
# the whole host set, so a friend's copy can host a match as well as join one).
#
#   Patch-Phoenix.ps1                         # Phoenix.exe and client-patches.json next to this script
#   Patch-Phoenix.ps1 -Exe <path> -Json <path>
#   Patch-Phoenix.ps1 -Check                  # only report; never writes (exit 0 = every patch in place)
#
# Safe to run before every launch, and quick when nothing changes (nothing is written then). Each
# patch is applied only if every site still has its original bytes, skipped if already applied, and
# refused if the exe has something else there. An earlier version of a patch (listed under
# "old_versions") is put back to the original bytes and replaced by the current one ("upgraded
# from ..."). A patch listed under "requires" is only applied when that file is in the game copy
# (else a "MISSING" line). The first change saves Phoenix.orig.exe next to the exe.
#
# After writing, the exe is read back from disk and every patch is checked again, so a patch that
# was skipped for any reason can't go unnoticed (2026-10-31: board-layout was silently left off on
# every friend's PC). Prints one line per patch, then a last line and exit code:
#   0  RESULT ok <n> patches in place
#   4  RESULT missing <patch, ...>   left off because a file they need isn't in the copy yet
#   1  RESULT failed <patch, ...>    the exe has other bytes there, or the write didn't stick
# Needs only Windows PowerShell 5.1. Counts below never use .Count on a pipeline result: in 5.1 a
# lone [pscustomobject] has no .Count, which is what hid the board-layout skip.
param(
  [string]$Exe = '',
  [string]$Json = '',
  [switch]$Check
)
$ErrorActionPreference = 'Stop'
# Anything unexpected still ends with a RESULT line and exit 1, never a bare PowerShell error.
trap { "RESULT failed $($_.Exception.Message)"; exit 1 }
if (-not $Exe) { $Exe = Join-Path $PSScriptRoot 'Phoenix.exe' }
if (-not $Json) { $Json = Join-Path $PSScriptRoot 'client-patches.json' }
function Done([int]$code, [string]$text) { "RESULT $text"; exit $code }
if (-not (Test-Path $Json)) { 'No client-patches.json; nothing to patch.'; Done 0 'ok 0 patches in place' }
if (-not (Test-Path $Exe)) { Done 1 "failed Phoenix.exe not found at $Exe" }
try {
  $spec = Get-Content $Json -Raw | ConvertFrom-Json
  $data = [IO.File]::ReadAllBytes($Exe)
} catch { Done 1 "failed couldn't read $(Split-Path $Exe -Leaf) or client-patches.json: $($_.Exception.Message)" }
# Every site's original bytes are checked below, which is the real version check: a different
# Phoenix.exe build fails it and is left alone. Patches made for build $spec.exe_version.

function Get-Hex([string]$hex) {
  $b = New-Object byte[] ($hex.Length / 2)
  for ($i = 0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($hex.Substring(2 * $i, 2), 16) }
  return ,$b
}

$pe = [BitConverter]::ToInt32($data, 0x3C)

# Patches too big for the exe's padding live in an extra section (code_section in the json):
# append it, int3-filled, if a patch needs it and it isn't there yet (add_code_section in
# phoenix_patches.py does the same). Changes are written below only if a patch applies.
$cs = $spec.code_section
$addedSection = $false
if ($cs) {
  $csRva = [long]$cs.rva
  $needs = @($spec.patches.PSObject.Properties | ForEach-Object { $_.Value } | Where-Object {
    $r = [Convert]::ToInt64($_.rva, 16); $r -ge $csRva -and $r -lt $csRva + [long]$cs.size })
  $n = [BitConverter]::ToUInt16($data, $pe + 6)
  $osz = [BitConverter]::ToUInt16($data, $pe + 20)
  $have = $false
  $haveIdx = -1
  for ($i = 0; $i -lt $n; $i++) { if ([BitConverter]::ToUInt32($data, $pe + 24 + $osz + $i * 40 + 12) -eq $csRva) { $have = $true; $haveIdx = $i } }
  # An older, smaller section (0x1000 before the minimap) as the last section: grow it in place.
  if ($needs.Count -and $have -and $haveIdx -eq $n - 1) {
    $o = $pe + 24 + $osz + $haveIdx * 40
    $rsz = [long][BitConverter]::ToUInt32($data, $o + 16)
    $rptr = [long][BitConverter]::ToUInt32($data, $o + 20)
    if ($rsz -lt [long]$cs.size) {
      $grown = New-Object byte[] ($rptr + [long]$cs.size)
      [Array]::Copy($data, $grown, $rptr + $rsz)
      for ($i = $rptr + $rsz; $i -lt $grown.Length; $i++) { $grown[$i] = 0xCC }
      foreach ($f in 8, 16) { [Array]::Copy([BitConverter]::GetBytes([uint32]$cs.size), 0, $grown, $o + $f, 4) }
      [Array]::Copy([BitConverter]::GetBytes([uint32]($csRva + [long]$cs.size)), 0, $grown, $pe + 24 + 56, 4)
      $data = $grown
      $addedSection = $true
    }
  }
  if ($needs.Count -and -not $have) {
    if ([BitConverter]::ToUInt32($data, $pe + 24 + 56) -ne $csRva) { Done 1 'failed this Phoenix.exe is not the build these patches are for (image size differs).' }
    $hdr = $pe + 24 + $osz + $n * 40
    $falign = [BitConverter]::ToUInt32($data, $pe + 24 + 36)
    $raw = [long]([Math]::Ceiling($data.Length / $falign) * $falign)
    $grown = New-Object byte[] ($raw + [long]$cs.size)
    [Array]::Copy($data, $grown, $data.Length)
    for ($i = $raw; $i -lt $grown.Length; $i++) { $grown[$i] = 0xCC }
    $nameBytes = [Text.Encoding]::ASCII.GetBytes($cs.name)
    [Array]::Copy($nameBytes, 0, $grown, $hdr, $nameBytes.Length)
    $fields = @([uint32]$cs.size, [uint32]$csRva, [uint32]$cs.size, [uint32]$raw)
    for ($i = 0; $i -lt 4; $i++) { [Array]::Copy([BitConverter]::GetBytes($fields[$i]), 0, $grown, $hdr + 8 + 4 * $i, 4) }
    [Array]::Copy([BitConverter]::GetBytes([uint32]$cs.chars), 0, $grown, $hdr + 36, 4)
    [Array]::Copy([BitConverter]::GetBytes([uint16]($n + 1)), 0, $grown, $pe + 6, 2)
    [Array]::Copy([BitConverter]::GetBytes([uint32]($csRva + [long]$cs.size)), 0, $grown, $pe + 24 + 56, 4)
    $data = $grown
    $addedSection = $true
  }
}

# PE section table: rva -> file offset (same as rva2off in phoenix_patches.py).
$nsec = [BitConverter]::ToUInt16($data, $pe + 6)
$optsz = [BitConverter]::ToUInt16($data, $pe + 20)
$sections = for ($i = 0; $i -lt $nsec; $i++) {
  $o = $pe + 24 + $optsz + $i * 40
  [pscustomobject]@{ va = [BitConverter]::ToUInt32($data, $o + 12); rawsize = [BitConverter]::ToUInt32($data, $o + 16); raw = [BitConverter]::ToUInt32($data, $o + 20) }
}
function Get-Offset([long]$rva) {
  foreach ($s in $sections) { if ($rva -ge $s.va -and $rva -lt $s.va + $s.rawsize) { return [long]($s.raw + $rva - $s.va) } }
  throw ('rva 0x{0:x} is not in any section' -f $rva)
}
function Test-Bytes([long]$off, [byte[]]$want) {
  for ($i = 0; $i -lt $want.Length; $i++) { if ($data[$off + $i] -ne $want[$i]) { return $false } }
  return $true
}

# Sites of one patch (or of one old version of it) as an array of {rva, off, orig, new}, always an
# array however many sites there are.
function Get-Sites($list) {
  $out = New-Object System.Collections.ArrayList
  foreach ($site in @($list)) {
    $rva = [Convert]::ToInt64($site.rva, 16)
    [void]$out.Add([pscustomobject]@{ rva = $rva; off = (Get-Offset $rva); orig = (Get-Hex $site.orig); new = (Get-Hex $site.new) })
  }
  return ,$out.ToArray()
}
# How many of $sites hold their 'new' (or 'orig') bytes in $data, counted one by one.
function Get-Matching($sites, [string]$which) {
  $n = 0
  foreach ($s in $sites) { if (Test-Bytes $s.off $s.$which) { $n++ } }
  return $n
}
function Get-FirstDiff($sites) {
  foreach ($s in $sites) { if (-not (Test-Bytes $s.off $s.orig)) { return ('0x{0:x}' -f $s.rva) } }
  return '?'
}

$changed = $addedSection
$expect = New-Object System.Collections.ArrayList   # patches that must be in place afterwards
$missing = New-Object System.Collections.ArrayList
$failed = New-Object System.Collections.ArrayList
$todo = New-Object System.Collections.ArrayList     # -Check: patches that are not in place yet
$total = 0
foreach ($p in $spec.patches.PSObject.Properties) {
  $total++
  # Some patches need a file in the game copy too (shop-six: the shop-screen pak). Without it the
  # patch stays off, and the line starting "MISSING" tells the join window to say so.
  $need = if ($spec.requires) { $spec.requires.($p.Name) } else { $null }
  if ($need -and -not (Test-Path (Join-Path (Split-Path $Exe) $need))) {
    "MISSING $($p.Name): needs $(Split-Path $need -Leaf); left off"
    [void]$missing.Add($p.Name)
    continue
  }
  $sites = Get-Sites $p.Value
  if ((Get-Matching $sites 'new') -eq $sites.Length) { "$($p.Name): already applied"; [void]$expect.Add($p.Name); continue }
  # An earlier version fully in place: undo it in memory (written only together with the new one).
  $undo = $null
  $from = ''
  $olds = if ($spec.old_versions) { $spec.old_versions.($p.Name) } else { $null }
  if ($olds) {
    foreach ($v in $olds.PSObject.Properties) {
      $vs = Get-Sites $v.Value
      if ((Get-Matching $vs 'new') -eq $vs.Length) { $undo = $vs; $from = $v.Name; break }
    }
  }
  if ($Check) {
    $state = if ($from) { "older version ($from)" } elseif ((Get-Matching $sites 'orig') -eq $sites.Length) { 'not applied' } else { "other bytes at $(Get-FirstDiff $sites)" }
    "$($p.Name): $state"
    [void]$todo.Add($p.Name)
    continue
  }
  $keep = $null
  if ($undo) {
    $keep = $data.Clone()
    foreach ($s in $undo) { [Array]::Copy($s.orig, 0, $data, $s.off, $s.orig.Length) }
  }
  if ((Get-Matching $sites 'orig') -ne $sites.Length) {
    if ($keep) { $data = $keep }
    "FAILED $($p.Name): this Phoenix.exe has other bytes at $(Get-FirstDiff $sites); left alone"
    [void]$failed.Add($p.Name)
    continue
  }
  foreach ($s in $sites) { [Array]::Copy($s.new, 0, $data, $s.off, $s.new.Length) }
  if ($from) { "$($p.Name): upgraded from $from" } else { "$($p.Name): applied" }
  [void]$expect.Add($p.Name)
  $changed = $true
}

if ($Check) {
  if ($todo.Count) { Done 1 "failed not in place: $($todo -join ', ')" }
  if ($missing.Count) { Done 4 "missing $($missing -join ', ')" }
  Done 0 "ok $total patches in place"
}

if ($changed) {
  $backup = Join-Path (Split-Path $Exe) 'Phoenix.orig.exe'
  try {
    if (-not (Test-Path $backup)) { Copy-Item $Exe $backup; "backup: $backup" }
    $tmp = "$Exe.tmp"
    [IO.File]::WriteAllBytes($tmp, $data)
    Move-Item $tmp $Exe -Force
  } catch {
    Remove-Item "$Exe.tmp" -ErrorAction SilentlyContinue
    Done 1 "failed couldn't update Phoenix.exe (is the game still running?): $($_.Exception.Message)"
  }
  # Read it back: what counts is what is on disk.
  $data = [IO.File]::ReadAllBytes($Exe)
}

# Self-check: every patch reported as in place really is.
foreach ($p in $spec.patches.PSObject.Properties) {
  if (-not $expect.Contains($p.Name)) { continue }
  $sites = Get-Sites $p.Value
  if ((Get-Matching $sites 'new') -ne $sites.Length) {
    "FAILED $($p.Name): not in place after writing"
    [void]$failed.Add($p.Name)
  }
}
if ($failed.Count) { Done 1 "failed $($failed -join ', ')" }
if ($missing.Count) { Done 4 "missing $($missing -join ', ')" }
Done 0 "ok $total patches in place"
