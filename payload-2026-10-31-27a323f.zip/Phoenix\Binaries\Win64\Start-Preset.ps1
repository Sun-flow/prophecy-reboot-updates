# Launches the Prophecy dev copy from a named game-mode preset (presets\<name>.json).
# Writes the dev copy's Saved\Config\WindowsNoEditor\Engine.ini and Game.ini from the preset,
# then starts Phoenix.exe. Every setting a preset can hold is listed in presets\README.md.
#
#   Start-Preset.ps1 -Preset test-solo                      # TESTING: solo, you + bots, accelerated rounds
#   Start-Preset.ps1 -Preset test-host -Role host           # TESTING: listen server on -Port (default 7777)
#   Start-Preset.ps1 -Preset test-join -Role client -Connect 192.168.1.20:7777 -Dev ...\local\dev\join
#   Start-Preset.ps1 -Preset play -Role host                # real game: original timers, 30 s intro
#   Start-Preset.ps1 -Preset play -Role host -HoldForHost   # host waits for your OK (Start match)
#   Start-Preset.ps1 -Preset standard -Map dragon           # preset with another map
#   Start-Preset.ps1 -Role client -Connect ... -Leader 3596  # pick your leader (needs the host's leader-pick patch)
#   Start-Preset.ps1 -Role client -Connect ... -Name morgo   # your in-game name (needs the host's player-name patch)
#   Start-Preset.ps1 -List                                  # show presets
#   Start-Preset.ps1 -Preset test-solo -DryRun              # print the ini sections, don't launch
#
# A preset's "overrides" (intro, lightning) live in the override pak, not in the ini files. When the
# host or solo copy's pak doesn't match, this rebuilds it with overrides\Build-OverridePak.ps1
# (needs <repo>\local\tools; the game must be closed). Every run prints the preset's timers.
param(
  [string]$Preset = 'standard',
  [ValidateSet('solo', 'host', 'client')] [string]$Role = 'solo',
  [string]$Connect = '127.0.0.1:7777',
  [int]$Port = 7777,
  [string]$Map = '',  # overrides the preset's "map" (streamed8, dragon, greek, themis, preview)
  [int]$Humans = 0,   # host only: overrides the preset's "humans" (players to wait for, host included)
  [int]$Leader = 0,   # your leader's UnitId (launcher\data\leaders.json), sent as ?Leader=; 0 = random
  [string]$Name = '',  # your in-game name, sent as ?Nick=; letters, digits, _ - . only, up to 20; '' = Player<N>
  [string]$Dev = '',   # default: the copy this script sits in, else <repo>\local\dev\host
  [string]$ExtraArgs = '',
  [switch]$HoldForHost,  # host only: hold the match until HoldMatch.flag is deleted (patch host-start)
  [switch]$NoOverrides,  # don't rebuild the override pak; launch with whatever intro/lightning it has
  [switch]$List,
  [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
# Copied next to Phoenix.exe (Phoenix\Binaries\Win64) it drives that copy; run from the repo it drives local\dev\host.
if (-not $Dev) { $Dev = if ($PSScriptRoot -match '\\Phoenix\\Binaries\\Win64$') { (Resolve-Path "$PSScriptRoot\..\..\..").Path } else { "$PSScriptRoot\..\..\..\local\dev\host" } }
$Dev = [IO.Path]::GetFullPath($Dev)
$presetDir = Join-Path $PSScriptRoot 'presets'

if ($List) {
  Get-ChildItem $presetDir -Filter *.json | ForEach-Object {
    $p = Get-Content $_.FullName -Raw | ConvertFrom-Json
    '{0,-14} {1}' -f $_.BaseName, $p.description
  }
  return
}

# Old names, kept so saved launcher/friend settings still work.
$renamed = @{ 'fast-test' = 'test-solo'; 'lan-host' = 'test-host' }
if ($renamed.ContainsKey($Preset)) {
  "Preset '$Preset' is now '$($renamed[$Preset])'."
  $Preset = $renamed[$Preset]
}

$modes = @{
  match    = '/Game/Game/GameMode/BP_TacticsGameMode.BP_TacticsGameMode_C'   # full 8-player autobattler
  practice = '/Game/Game/GameMode/BP_TacGame_Practice.BP_TacGame_Practice_C' # "Team Builder" sandbox
  testing  = '/Game/Game/GameMode/BP_TacticsTestingMode.BP_TacticsTestingMode_C'
}
# Native class behind each mode; config lands in its [/Script/Phoenix.<class>] section.
$nativeClass = @{ match = 'TacGameMode'; practice = 'TacGameMode_Practice'; testing = 'TacGameMode' }
$maps = @{
  streamed8 = '/Game/Maps/TestMaps/Map_Streamed8_P.Map_Streamed8_P'
  dragon    = '/Game/Maps/Tactics_Maps/Map_Dragon_Streamed.Map_Dragon_Streamed'
  greek     = '/Game/Maps/Tactics_Maps/Map_Greek_T1_Streamed.Map_Greek_T1_Streamed'
  themis    = '/Game/Maps/Tactics_Maps/Map_Themis_Streamed.Map_Themis_Streamed'
  preview   = '/Game/Maps/Tactics_Maps/Map_Preview_S.Map_Preview_S'
}
# Config-backed phase timers on TacGameMode (CPF_Config in the exe's reflection data).
$timerNames = 'InitialDuration', 'LeaderSpawnDelay', 'PrepareTransitionDuration', 'PrepareDuration',
  'StandbyDuration', 'CombatDuration', 'ResultDuration'
# GlobalGameRules in packaged DefaultGame.ini order: name, enabled, value (match / practice).
$ruleDefaults = [ordered]@{
  StartGold              = @($true, 1, 1)
  VictoryGold            = @($false, 1, 1)
  MinRoundGold           = @($true, 1, 1)
  MaxRoundGold           = @($true, 5, 5)
  EnableReroll           = @($true, 1, 1)
  ItemTypes              = @($true, 40, 9999)
  ItemCount              = @($true, 4, 4)
  TraitTypes             = @($true, 16, 9999)
  TraitCount             = @($true, 10, 10)
  AILevelUpCostThreshold = @($true, 100, 100)
}

$p = Get-Content (Join-Path $presetDir "$Preset.json") -Raw | ConvertFrom-Json
$mode = if ($p.mode) { $p.mode } else { 'match' }
$map = if ($Map) { $Map } elseif ($p.map) { $p.map } else { 'streamed8' }
if (-not $modes.ContainsKey($mode)) { throw "Unknown mode '$mode' (match, practice, testing)" }
if (-not $maps.ContainsKey($map)) { throw "Unknown map '$map' ($($maps.Keys -join ', '))" }
if ($p.role -and $p.role -ne $Role) { throw "Preset '$Preset' is for -Role $($p.role), not $Role" }

# Game.ini body: bots, one-on-one, timers, leader, rules.
$game = New-Object System.Collections.Generic.List[string]
if ($null -ne $p.bots) {
  $game.Add("MaxAIPlayers=$($p.bots)")
  $one = if ($null -ne $p.oneOnOne) { $p.oneOnOne } else { $p.bots -le 1 }
  $game.Add("bIsOneOnOne=$(if ($one) { 'True' } else { 'False' })")
}
if ($p.timers) {
  foreach ($t in $p.timers.PSObject.Properties) {
    if ($timerNames -notcontains $t.Name) { throw "Timer '$($t.Name)' is not config-backed; allowed: $($timerNames -join ', ')" }
    $game.Add("$($t.Name)=$($t.Value)")
  }
}
if ($null -ne $p.defaultLeaderId) { $game.Add("DefaultLeaderId=$($p.defaultLeaderId)") }
if ($p.rules) {
  $known = @($p.rules.PSObject.Properties.Name)
  foreach ($k in $known) { if (-not $ruleDefaults.Contains($k)) { throw "Unknown rule '$k'; allowed: $($ruleDefaults.Keys -join ', ')" } }
  # Arrays are written whole so indices stay aligned with the packaged order.
  $col = if ($mode -eq 'practice') { 2 } else { 1 }
  $i = 0
  foreach ($name in $ruleDefaults.Keys) {
    $on = $ruleDefaults[$name][0]; $val = $ruleDefaults[$name][$col]
    if ($known -contains $name) {
      $r = $p.rules.$name
      if ($r -is [bool]) { $on = $r } elseif ($r -is [System.Management.Automation.PSCustomObject] -and $null -ne $r.enabled) {
        $on = $r.enabled; if ($null -ne $r.value) { $val = $r.value }
      } else { $on = $true; $val = $r }
    }
    $game.Add("GlobalGameRules[$i]=(fnDisplayName=`"$name`", bDefaultIsEnabled=$($on.ToString().ToLower()), nDefaultValue=$val, nDefaultCharges=0)")
    $i++
  }
}

# Engine.ini: boot URL. Clients put the address in LocalMapOptions with an empty GameDefaultMap.
# ?Leader=<UnitId> rides in this player's URL; a host with the leader-pick patch (P2) reads it at login.
$playerOpt = if ($Leader -gt 0) { "?Leader=$Leader" } else { '' }
# ?Nick=<name> likewise, read by the player-name patch (P9). Only URL-safe characters survive.
$Name = ($Name -replace '[^A-Za-z0-9_.-]', '')
if ($Name.Length -gt 20) { $Name = $Name.Substring(0, 20) }
if ($Name) { $playerOpt += "?Nick=$Name" }
$opts = "?game=$($modes[$mode])?DevOpen"
if ($Role -eq 'host') { $opts += '?listen' }
$engine = if ($Role -eq 'client') { @('GameDefaultMap=', "LocalMapOptions=${Connect}?DevOpen$playerOpt") }
          else { @("GameDefaultMap=$($maps[$map])", "LocalMapOptions=$opts$playerOpt") }

$cfg = "$Dev\Phoenix\Saved\Config\WindowsNoEditor"

# Network rates, written for every role. The engine's stock caps are tiny: a client asks for 10 KB/s
# (ConfiguredInternetSpeed), the host allows 10-15 KB/s per client (MaxInternetClientRate /
# MaxClientRate) and splits 32 KB/s between all players at 4-7 KB/s each (GameNetworkManager). Our
# all-relevant patch sends every board's units to every player, several times what the game sent,
# so at those caps updates queue up: lag, late shop/UI updates. The host log shows the rate a client
# got ("Client netspeed is N"). Both sides need it: the client asks, the host caps.
$netRate = 100000
$net = [ordered]@{
  '/Script/Engine.Player' = @("ConfiguredInternetSpeed=$netRate", "ConfiguredLanSpeed=$netRate")
  '/Script/OnlineSubsystemUtils.IpNetDriver' = @("MaxClientRate=$netRate", "MaxInternetClientRate=$netRate")
  '/Script/Engine.GameNetworkManager' = @("TotalNetBandwidth=$($netRate * 8)", "MaxDynamicBandwidth=$netRate", 'MinDynamicBandwidth=20000')
}
$bpSection = $modes[$mode]
$nativeSection = "/Script/Phoenix.$($nativeClass[$mode])"

# What this run plays with, printed on every launch (and -DryRun) so a test log shows its settings.
# A joiner's phases, intro and combat all come from the host, so a client only reports the label.
$original = [ordered]@{ InitialDuration = 30; LeaderSpawnDelay = 3.75; PrepareTransitionDuration = 2.5
  PrepareDuration = 30; StandbyDuration = 3.5; CombatDuration = 'native'; ResultDuration = 1 }
$label = if ($p.testing) { 'TESTING' } else { 'normal' }
if ($Role -eq 'client') {
  $summary = @("Preset $Preset ($label, join): rounds, intro and combat follow the host." +
    $(if ($p.testing) { ' The host must run a test-* preset (test-host) for a fast run.' } else { '' }))
} else {
  $set = @{}
  if ($p.timers) { foreach ($t in $p.timers.PSObject.Properties) { $set[$t.Name] = $t.Value } }
  $parts = foreach ($n in $original.Keys) {
    if ($set.ContainsKey($n)) { "$($n -replace 'Duration$', '') $($set[$n]) s" } else { "$($n -replace 'Duration$', '') $($original[$n])$(if ($original[$n] -is [string]) { '' } else { ' s' }) (original)" }
  }
  $summary = @("Preset $Preset ($label, $Role, mode=$mode map=$map)", "  Timers: $($parts -join ', ')")
}

# Override pak (host and solo): intro length and when sudden death starts. Blueprint defaults, so
# Game.ini can't set them; overrides\Build-OverridePak.ps1 bakes them into a _P pak. A record of the
# values (.json next to the pak) says what the copy has now. No pak = the original 45 s and 20 s.
# The pak edits BP_TacticsGameMode only, so practice (its own game mode) doesn't use it.
$paks = "$Dev\Phoenix\Content\Paks"
$pakFile = "$paks\Phoenix-WindowsNoEditor_Overrides_P.pak"
function Get-Overrides {
  if (-not (Test-Path $pakFile)) { return @{ intro = 45; lightning = 20; how = 'no override pak' } }
  $rec = [IO.Path]::ChangeExtension($pakFile, '.json')
  if (-not (Test-Path $rec)) { return @{ intro = $null; lightning = $null; how = 'override pak without a record' } }
  $r = Get-Content $rec -Raw | ConvertFrom-Json
  @{ intro = [double]$r.intro; lightning = [double]$r.lightning; how = 'override pak' }
}
if ($Role -ne 'client' -and $mode -ne 'practice') {
  $have = Get-Overrides
  $want = $p.overrides
  if ($want -and ($want.intro -ne $have.intro -or $want.lightning -ne $have.lightning)) {
    $intro = if ($null -ne $want.intro) { [double]$want.intro } elseif ($null -ne $have.intro) { $have.intro } else { 45 }
    $light = if ($null -ne $want.lightning) { [double]$want.lightning } elseif ($null -ne $have.lightning) { $have.lightning } else { 20 }
    $builder = Join-Path $PSScriptRoot 'overrides\Build-OverridePak.ps1'
    if ($DryRun -or $NoOverrides) {
      $summary += "  Would set the override pak to intro $intro s, sudden death at $light s (now: $($have.how), intro $($have.intro), sudden death $($have.lightning))."
    } elseif ($intro -eq 45 -and $light -eq 20) {
      # Original values: switch the pak off rather than rebuild it (same as the launcher's 45 s intro).
      Remove-Item "$pakFile.off" -ErrorAction SilentlyContinue
      Move-Item $pakFile "$pakFile.off"
      $have = Get-Overrides
    } elseif (Test-Path $builder) {
      "Setting the override pak: intro $intro s, sudden death at $light s ..."
      & $builder -IntroFailSafe $intro -CombatLightning $light -Install -Dev $Dev | ForEach-Object { "  $_" }
      Remove-Item "$pakFile.off" -ErrorAction SilentlyContinue
      $have = Get-Overrides
    } else {
      $summary += "  Can't set intro $intro s here (no overrides\Build-OverridePak.ps1 next to this script); playing with what the copy has."
    }
  }
  $introText = if ($null -ne $have.intro) { "$($have.intro) s" } else { 'unknown' }
  $lightText = if ($null -ne $have.lightning) { "$($have.lightning) s" } else { 'unknown' }
  $summary += "  Intro $introText, sudden death at $lightText ($($have.how))"
}

if ($DryRun) {
  $summary; ""
  "[Engine.ini]"; "[/Script/EngineSettings.GameMapsSettings]"; $engine
  foreach ($k in $net.Keys) { "[$k]"; $net[$k] }
  if ($Role -ne 'client') { ""; "[Game.ini]"; "[$nativeSection]"; $game; ""; "[$bpSection]"; $game }
  return
}

# Replace (or add) one [section] in an ini file, keeping everything else the game wrote there.
function Set-IniSection($path, $section, [string[]]$body) {
  $lines = if (Test-Path $path) { @(Get-Content $path) } else { @() }
  $out = New-Object System.Collections.Generic.List[string]
  $skip = $false
  foreach ($l in $lines) {
    if ($l -match '^\[.*\]$') { $skip = ($l -eq "[$section]") }
    if (-not $skip) { $out.Add($l) }
  }
  $out.Add(''); $out.Add("[$section]"); $body | ForEach-Object { $out.Add($_) }
  Set-Content $path $out -Encoding ascii
}

New-Item -ItemType Directory -Force $cfg | Out-Null
Set-IniSection "$cfg\Engine.ini" '/Script/EngineSettings.GameMapsSettings' $engine
foreach ($k in $net.Keys) { Set-IniSection "$cfg\Engine.ini" $k $net[$k] }
# The RTS camera (patch rts-cam) reads F itself. Earlier builds mapped F to FlipCamera here;
# clear that line from copies that still have it.
Set-IniSection "$cfg\Input.ini" '/Script/Engine.InputSettings' @()
if ($Role -ne 'client') {
  # Written under both the native class and the Blueprint class, since either may be the one read.
  # Written even when empty, so a preset without game settings clears the last preset's values.
  Set-IniSection "$cfg\Game.ini" $nativeSection $game
  Set-IniSection "$cfg\Game.ini" $bpSection $game
}

$bin = "$Dev\Phoenix\Binaries\Win64"
$portArg = if ($Role -eq 'host') { "-port=$Port" } else { '' }
# -Humans=N makes a patched host (patches\phoenix_patches.py humans-arg) hold WaitingToStart until
# N humans, host included, have joined. A stock exe ignores the argument.
if ($Humans -le 0) { $Humans = if ($null -ne $p.humans) { [int]$p.humans } else { 1 } }
$humansArg = if ($Role -eq 'host' -and $Humans -gt 1) { "-Humans=$Humans" } else { '' }
# -HoldForHost: a patched host (host-start) holds WaitingToStart while HoldMatch.flag exists next to
# Phoenix.exe, and ignores the ~60 s wait-for-players timeout. Deleting the file starts the match
# with whoever is in, so -Humans is left out. Any other launch removes a stale flag.
$holdFlag = "$bin\HoldMatch.flag"
if ($Role -eq 'host' -and $HoldForHost) {
  Set-Content $holdFlag "Delete this file (or press Start match in the launcher) to start the match." -Encoding ascii
  $humansArg = ''
} elseif (Test-Path $holdFlag) {
  Remove-Item $holdFlag
}
$argLine = "-NotInstalled -game -windowed -ResX=1280 -ResY=720 -nomovie -nosplash -log $portArg $humansArg $ExtraArgs" -replace '\s+', ' '
Start-Process -FilePath "$bin\Phoenix.exe" -ArgumentList $argLine.Trim() -WorkingDirectory $bin
$waitNote = if ($Role -eq 'host' -and $HoldForHost) { ", holding until $holdFlag is deleted" } elseif ($humansArg) { ", waiting for $Humans humans" } else { '' }
$summary
"Launched preset '$Preset' as $Role (mode=$mode map=$map$waitNote$(if ($Leader -gt 0) { ", leader $Leader" })$(if ($Name) { ", name $Name" })). Log: $Dev\Phoenix\Saved\Logs\Phoenix.log"
