# The Prophecy launcher: one window for everyone, with Join, Host, Leaders and Traits tabs.
# Friends open it with "Play Prophecy.bat" in their Prophecy-Online folder; the host PC opens it
# with launcher\Prophecy_Launcher.bat, and then it also has a Developer tab (Launcher-Developer.ps1:
# Live/Dev builds, host patches, intro, friend update and setup package). The file keeps its old
# name (it was the join window) because every friend's Play Prophecy.bat and the updater start it.
#
# Two places it runs from:
#   friend copy   <bundle>\Phoenix\Binaries\Win64\ next to Start-Preset.ps1 and Phoenix.exe.
#                 Settings: <bundle>\friend.json (every field in friend\README.md). Before each
#                 Join or Open lobby it installs the newest update from the feed, builds the shop
#                 and boards paks from the friend's own game files and patches the exe.
#   repo          <repo>\friend\ (the host PC). Settings: <repo>\local\launcher-settings.json
#                 (launcher\README.md). It plays the build picked on the Developer tab (Live:
#                 local\live\host, Dev: the host copy), which Update live build already patched.
#
# Friend settings in friend.json:
#   address  the host's address, e.g. a playit.gg address "name.gl.ply.gg:12345". Port 7777 if left out.
#   title    window title
#   leader   the leader picked here (UnitId; 0 or missing = random). Saved when it changes.
#   name     the in-game name (letters, digits, _ - . up to 20). Missing or empty = a made-up one
#            (New-RandomName), saved at once so it stays the same.
#   update_url  where the host publishes updates (raw URL of the public feed repo). Missing = no check.
#   solo     the solo game picked here (a preset name, see $soloGames; default standard).
#   host_address, host_port, host_open_port, host_preset, humans, hold_for_host  the Host tab.
#
# Needs only Windows PowerShell 5.1, which every Windows 10/11 PC has. Nothing is installed.
param(
  [switch]$AutoJoin,  # set when the window restarts itself after an update from Join: join right away
  [switch]$Updated    # set when it restarts after an update from the Update button: just say so
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

$bin = $PSScriptRoot
# Run from <repo>\friend: the host PC's launcher (Developer tab). Anywhere else: a friend's copy.
$script:devMode = ($bin -notmatch '\\Phoenix\\Binaries\\Win64$') -and (Test-Path (Join-Path $bin '..\research\prophecy\dev-copy\Start-Preset.ps1'))
if ($script:devMode) {
  $repo = (Resolve-Path "$bin\..").Path
  $bundle = $null
  $cfgPath = Join-Path $repo 'local\launcher-settings.json'
} else {
  $repo = $null
  $bundle = (Resolve-Path "$bin\..\..\..").Path
  $cfgPath = Join-Path $bundle 'friend.json'
}

# ---- settings -----------------------------------------------------------------------------------
# One name per setting in the code; on the host PC some are stored under the names the launcher
# settings had before the launchers were merged (Build-FriendBundle.ps1 and Update-Live.ps1 read them).
$cfgAlias = if ($script:devMode) { @{ address = 'join_address'; name = 'player_name'; host_port = 'port'; host_address = 'public_address'; host_preset = 'preset' } } else { @{} }
$cfgDefaults = if ($script:devMode) {
  @{ build = 'live'; host_copy = 'local/dev/host'; join_copy = 'local/dev/join'; host_port = 7777; host_preset = 'play'; humans = 2
     address = '127.0.0.1'; leader = 3587; name = 'gromb'; update_address = 'github.com/Sun-flow/prophecy-reboot-updates'
     hold_for_host = $true; hold_max_minutes = 10; intro_seconds = 30; testing = $false; solo = 'standard' }
} else { @{ host_port = 7777; host_preset = 'play'; humans = 2; hold_for_host = $true; solo = 'standard' } }

# Files extracted with Explorer from a downloaded zip carry the "from the web" mark
# (Zone.Identifier), and Smart App Control then blocks Play Prophecy.bat. Clear it from the small
# files this window and Start-Preset use, so a hand-extracted update doesn't block the next start.
function Clear-WebMark {
  if ($script:devMode) { return }
  $files = @(Get-ChildItem $bundle -File -ErrorAction SilentlyContinue) +
    @(Get-ChildItem $bin -Recurse -File -Include *.ps1, *.json, *.md -ErrorAction SilentlyContinue)
  $files | Where-Object { $_.Extension -in '.bat', '.ps1', '.json', '.txt', '.md' } | Unblock-File -ErrorAction SilentlyContinue
}
Clear-WebMark
$cfg = [pscustomobject]@{}
if (Test-Path $cfgPath) { try { $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json } catch { } }
function Get-CfgKey($name) { if ($cfgAlias.ContainsKey($name)) { $cfgAlias[$name] } else { $name } }
# A saved value, or the default when it is missing or an empty string ($false and 0 count as set).
function Get-Cfg($name, $default = $null) {
  $k = Get-CfgKey $name
  $p = $cfg.PSObject.Properties[$k]
  if ($p -and $null -ne $p.Value -and -not ($p.Value -is [string] -and $p.Value -eq '')) { return $p.Value }
  if ($null -ne $default) { return $default }
  return $cfgDefaults[$name]
}
function Set-Cfg($name, $value) { $cfg | Add-Member -NotePropertyName (Get-CfgKey $name) -NotePropertyValue $value -Force }
function Save-Cfg {
  try {
    New-Item -ItemType Directory -Force (Split-Path $cfgPath) | Out-Null
    [IO.File]::WriteAllText($cfgPath, ($cfg | ConvertTo-Json), (New-Object Text.UTF8Encoding($false)))
  } catch { }
}
# An update zip brings friend-update.json (new address/title). Merge it in, keeping fields such as
# the leader pick, then remove it so it applies once.
if (-not $script:devMode) {
  $updPath = Join-Path $bundle 'friend-update.json'
  if (Test-Path $updPath) {
    try {
      $upd = Get-Content $updPath -Raw | ConvertFrom-Json
      foreach ($prop in $upd.PSObject.Properties) { $cfg | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force }
      Save-Cfg
      Remove-Item $updPath -ErrorAction SilentlyContinue
    } catch { }
  }
}
# A made-up player name, adjective + noun ("AshenOracle"), so nobody joins as "Player N". Every pair
# fits the 20-character name limit and the [A-Za-z0-9_.-] rule.
$nameAdjectives = @('Ashen', 'Amber', 'Bold', 'Brazen', 'Bright', 'Cinder', 'Crimson', 'Dusk', 'Ember', 'Fabled',
  'Fallen', 'Gilded', 'Grim', 'Hallowed', 'Hidden', 'Iron', 'Ivory', 'Jade', 'Lone', 'Lucky', 'Lunar',
  'Mighty', 'Misty', 'Molten', 'Noble', 'Obsidian', 'Pale', 'Quiet', 'Restless', 'Rune', 'Sable',
  'Silver', 'Solar', 'Starlit', 'Stone', 'Storm', 'Swift', 'Thorned', 'Twilight', 'Wild')
$nameNouns = @('Augur', 'Bard', 'Champion', 'Comet', 'Crow', 'Drake', 'Envoy', 'Falcon', 'Fox', 'Golem',
  'Griffin', 'Harbinger', 'Herald', 'Hound', 'Hydra', 'Lantern', 'Lion', 'Mystic', 'Nomad', 'Omen',
  'Oracle', 'Owl', 'Pilgrim', 'Prophet', 'Raven', 'Sage', 'Seer', 'Sentinel', 'Serpent', 'Spark',
  'Sphinx', 'Stag', 'Titan', 'Viper', 'Wanderer', 'Warden', 'Whisper', 'Wolf', 'Wraith', 'Wyrm')
function New-RandomName { (Get-Random -InputObject $nameAdjectives) + (Get-Random -InputObject $nameNouns) }
# First run (or a cleared name): make one up and keep it, so the same name comes back next time.
if (-not (Get-Cfg 'name' '')) { Set-Cfg 'name' (New-RandomName); Save-Cfg }
$title = if ($script:devMode) { 'Prophecy Launcher' } else { [string](Get-Cfg 'title' 'Prophecy') }

# ---- the game copy this launcher plays ------------------------------------------------------------
$devNotes = @()
if ($script:devMode) {
  . (Join-Path $bin 'Launcher-Developer.ps1')
  $devNotes = @(Move-OldDevCopies)
}
function Get-GameDir { if ($script:devMode) { (Get-DevBuild).hostCopy } else { $bundle } }
function Get-GameBin { Join-Path (Get-GameDir) 'Phoenix\Binaries\Win64' }
function Get-GameExe { Join-Path (Get-GameBin) 'Phoenix.exe' }
function Get-LogFile { Join-Path (Get-GameDir) 'Phoenix\Saved\Logs\Phoenix.log' }
function Get-StartPreset { if ($script:devMode) { (Get-DevBuild).startPreset } else { Join-Path $bin 'Start-Preset.ps1' } }
function Get-PresetDir { if ($script:devMode) { (Get-DevBuild).presets } else { Join-Path $bin 'presets' } }
function Get-OurGame { $d = Get-GameDir; Get-Process Phoenix -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$d\*" } }
function Get-AnyGame { Get-Process Phoenix -ErrorAction SilentlyContinue }

# Presets (presets\<name>.json next to Start-Preset.ps1): name -> description.
function Get-Presets {
  $out = [ordered]@{}
  foreach ($f in @(Get-ChildItem (Get-PresetDir) -Filter *.json -ErrorAction SilentlyContinue | Sort-Object Name)) {
    try { $out[$f.BaseName] = Get-Content $f.FullName -Raw | ConvertFrom-Json } catch { $out[$f.BaseName] = [pscustomobject]@{ description = '(unreadable)' } }
  }
  return $out
}
function Get-PresetDescription($name) { $p = (Get-Presets)[$name]; if ($p -and $p.description) { [string]$p.description } else { '' } }
# Developer copy only: the presets to host or play solo with. Join-only presets (role client) are
# never offered; Testing switches between the test-* presets and the rest.
function Get-PresetChoices([switch]$ForHost, [switch]$Testing) {
  $all = Get-Presets
  @($all.Keys | Where-Object { $all[$_].role -ne 'client' -and [bool]$all[$_].testing -eq [bool]$Testing })
}
# Same keys as $maps in Start-Preset.ps1, which owns the asset paths.

# Solo games against bots on a friend's copy. Bots always fill all 7 seats (MaxAIPlayers in a
# preset is ignored by the game), so a 1-bot duel isn't offered. test-solo is the testing preset
# (8 s shop); the intro still plays there, since skipping it needs the override pak, which only the
# host's tools build.
function Get-SoloGames {
  if (-not $script:devMode) {
    return [ordered]@{ 'standard' = 'Normal match vs 7 bots'; 'test-solo' = 'Quick match vs 7 bots (8 s shop)'; 'practice' = 'Team Builder practice' }
  }
  $out = [ordered]@{}
  $all = Get-Presets
  foreach ($k in $all.Keys) {
    if ($all[$k].role -eq 'client' -or $k -in 'play', 'test-host') { continue }
    $d = [string]$all[$k].description
    if ($d.Length -gt 60) { $d = $d.Substring(0, 57) + '...' }
    $out[$k] = "${k}: $d"
  }
  return $out
}

# ---- leader and trait info ---------------------------------------------------------------------
# Friends: read from their own game files into <bundle>\gamedata by Extract-GameData.ps1
# (GameData.cs); it only does work the first time and after the paks change. Game text and art
# never ship in public updates (mae, 2026-10-30). Copies next to this script are the fallback.
# Host PC: launcher\data (the export tools there write it).
$gameDataNote = ''
if ($script:devMode) { $gameData = Join-Path $repo 'launcher\data' }
else {
  $gameData = Join-Path $bundle 'gamedata'
  $extractor = Join-Path $bin 'Extract-GameData.ps1'
  # A bootstrap update (docs/server/friend-updates.md) has the script but not GameData.cs yet.
  # No game here yet (a setup package before its first-time copy from Steam): nothing to read.
  if ((Test-Path $extractor) -and (Test-Path (Join-Path $bin 'GameData.cs')) -and (Test-Path (Join-Path $bin 'Phoenix.exe'))) {
    try { [void](& $extractor -Game $bundle -Out $gameData) }
    catch {
      $gameDataNote = "Couldn't read leader and trait info from your game files ($($_.Exception.Message)). Send the host gamedata-error.txt from your Prophecy folder."
      try { Set-Content (Join-Path $bundle 'gamedata-error.txt') ($_ | Out-String) -Encoding ascii } catch { }
    }
  }
}
function Get-DataPath($name) { $p = Join-Path $gameData $name; if (Test-Path $p) { $p } else { Join-Path $bin $name } }
# Leaders the host can give you (enabled ones).
$leaderFile = Get-DataPath 'leaders.json'
$leaders = @()
if (Test-Path $leaderFile) { $leaders = @((Get-Content $leaderFile -Raw -Encoding UTF8 | ConvertFrom-Json).leaders | Where-Object { $_.enabled }) }
$traitFile = Get-DataPath 'traits.json'
$traits = @()
if (Test-Path $traitFile) { $traits = @((Get-Content $traitFile -Raw -Encoding UTF8 | ConvertFrom-Json).traits) }
$iconDir = Get-DataPath 'trait-icons'

function Get-LeaderName($id) {
  if (-not $id) { return 'random' }
  $l = $leaders | Where-Object { [int]$_.id -eq [int]$id } | Select-Object -First 1
  if ($l) { $l.name } else { "#$id" }
}
# Skill / passive text as the game has it; a passive named just "<Leader> Passive" shows its text only.
function Get-LeaderText($l, $part) {
  $p = $l.$part
  if (-not $p -or -not $p.description) { return 'not exported yet.' }
  $name = if ($p.name -and $p.name -ne "$($l.name) Passive") { "$($p.name): " } else { '' }
  return "$name$($p.description)"
}

# ---- helpers ------------------------------------------------------------------------------------

# "host[:port]" -> "ip:port". A playit.gg address is a host name whose IP can change, so it is
# looked up on every join and the game always gets a plain IP.
function Get-JoinAddress($text) {
  $text = $text.Trim()
  if (-not $text) { throw 'Type the address the host gave you.' }
  $m = [regex]::Match($text, '^([A-Za-z0-9.\-]+)(?::(\d{1,5}))?$')
  if (-not $m.Success) { throw "'$text' is not an address like name.gl.ply.gg:12345 or 26.1.2.3:7777" }
  $hostName = $m.Groups[1].Value
  $port = if ($m.Groups[2].Success) { $m.Groups[2].Value } else { '7777' }
  $ip = $null
  if (-not [Net.IPAddress]::TryParse($hostName, [ref]$ip)) {
    # The first lookup of a playit name can fail for a few seconds (seen in the 2026-10-30 test),
    # so retry. If it never resolves, hand the name to the game, which resolves it itself.
    $a = $null
    for ($i = 1; $i -le 5 -and -not $a; $i++) {
      try {
        $a = [Net.Dns]::GetHostAddresses($hostName) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1
      } catch { $a = $null }
      if (-not $a -and $i -lt 5) { Say "Looking up $hostName (try $i of 5) ..."; Start-Sleep -Seconds 2 }
    }
    if ($a) { $hostName = $a.IPAddressToString }
  }
  return "${hostName}:$port"
}

# UE4 needs the Visual C++ 2015+ runtime and parts of the DirectX 9 runtime; the game ships
# Microsoft's installer for both.
function Test-Prereqs {
  $sys = "$env:windir\System32"
  return (Test-Path "$sys\vcruntime140.dll") -and (Test-Path "$sys\msvcp140.dll") -and (Test-Path "$sys\xinput1_3.dll")
}

# Command-line quoting for ProcessStartInfo.Arguments (the rules CommandLineToArgvW reads back).
function Join-ArgLine([string[]]$list) {
  ($list | ForEach-Object {
    $a = [string]$_
    if ($a -ne '' -and $a -notmatch '[\s"]') { $a }
    else { '"' + ($a -replace '(\\*)"', '$1$1\"' -replace '(\\+)$', '$1$1') + '"' }
  }) -join ' '
}

# Runs a program without a window and calls $done with (exit code, output, $state) on the UI
# thread when it ends, so slow work (Update live build, friend builds, patching) never freezes
# the window. The output is read by .NET tasks that a timer polls: no PowerShell runs elsewhere.
$script:tasks = New-Object System.Collections.ArrayList
$taskTimer = New-Object Windows.Forms.Timer
$taskTimer.Interval = 400
$taskTimer.Add_Tick({
  foreach ($t in @($script:tasks)) {
    if (-not ($t.p.HasExited -and $t.out.IsCompleted -and $t.err.IsCompleted)) { continue }
    $script:tasks.Remove($t)
    $text = ([string]$t.out.Result + "`n" + [string]$t.err.Result).Trim()
    try { & $t.done $t.p.ExitCode $text $t.state } catch { Say "Error after $(Split-Path $t.file -Leaf): $($_.Exception.Message)" $bad }
  }
  if (-not $script:tasks.Count) { $taskTimer.Stop() }
})
function Start-Task([string]$file, [string[]]$arguments, [scriptblock]$done, $state = $null) {
  $psi = New-Object Diagnostics.ProcessStartInfo
  $psi.FileName = $file
  $psi.Arguments = Join-ArgLine $arguments
  $psi.UseShellExecute = $false
  $psi.CreateNoWindow = $true
  $psi.RedirectStandardOutput = $true
  $psi.RedirectStandardError = $true
  $p = [Diagnostics.Process]::Start($psi)
  [void]$script:tasks.Add(@{ p = $p; file = $file; out = $p.StandardOutput.ReadToEndAsync(); err = $p.StandardError.ReadToEndAsync(); done = $done; state = $state })
  $taskTimer.Start()
}
# Start-Preset.ps1 for this copy (it writes the ini files and starts Phoenix.exe), in the background.
function Invoke-StartPreset([string[]]$arguments, [scriptblock]$done) {
  Start-Task 'powershell' (@('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', (Get-StartPreset), '-Dev', (Get-GameDir)) + $arguments) $done
}

# ---- window -------------------------------------------------------------------------------------

$fg = [Drawing.Color]::FromArgb(230, 232, 238)
$dim = [Drawing.Color]::FromArgb(154, 160, 171)
$good = [Drawing.Color]::FromArgb(124, 199, 127)
$warn = [Drawing.Color]::FromArgb(227, 178, 91)
$bad = [Drawing.Color]::FromArgb(229, 115, 115)
$gold = [Drawing.Color]::FromArgb(217, 164, 65)
$back = [Drawing.Color]::FromArgb(29, 32, 39)
$panel = [Drawing.Color]::FromArgb(37, 41, 50)
$navBack = [Drawing.Color]::FromArgb(21, 23, 28)
$fieldColor = [Drawing.Color]::FromArgb(42, 46, 56)    # text boxes and lists
$lineColor = [Drawing.Color]::FromArgb(58, 63, 76)     # borders and dividers
$hoverColor = [Drawing.Color]::FromArgb(52, 57, 70)

function New-Label([string]$text, [switch]$Dim, [switch]$Section, [int]$Wrap = 0) {
  $l = New-Object Windows.Forms.Label
  $l.Text = $text
  $l.AutoSize = $true
  $l.Margin = New-Object Windows.Forms.Padding(0, 4, 8, 2)
  if ($Wrap) { $l.MaximumSize = New-Object Drawing.Size($Wrap, 0) }
  if ($Dim) { $l.ForeColor = $script:dim }   # the -Dim switch hides the $dim colour here (names ignore case)
  if ($Section) { $l.ForeColor = $gold; $l.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold); $l.Margin = New-Object Windows.Forms.Padding(0, 12, 0, 4) }
  return $l
}
function New-Button([string]$text, [switch]$Primary, [switch]$Link) {
  $b = New-Object Windows.Forms.Button
  $b.Text = $text
  $b.FlatStyle = 'Flat'
  $b.AutoSize = $true
  $b.Margin = New-Object Windows.Forms.Padding(0, 0, 8, 0)
  $b.Cursor = 'Hand'
  $b.FlatAppearance.BorderColor = $lineColor
  $b.FlatAppearance.MouseOverBackColor = $hoverColor
  if ($Primary) {
    $b.Font = New-Object Drawing.Font('Segoe UI', 11, [Drawing.FontStyle]::Bold)
    $b.BackColor = $gold; $b.ForeColor = [Drawing.Color]::FromArgb(26, 26, 26)
    $b.FlatAppearance.BorderSize = 0
    $b.FlatAppearance.MouseOverBackColor = [Drawing.Color]::FromArgb(232, 184, 92)
    $b.Padding = New-Object Windows.Forms.Padding(14, 2, 14, 2)
  } elseif ($Link) {
    # A small outlined button with gold text, for actions beside a line of text.
    $b.ForeColor = $gold; $b.BackColor = $back
    $b.Font = New-Object Drawing.Font('Segoe UI', 9)
    $b.Margin = New-Object Windows.Forms.Padding(6, 0, 0, 0)
    $b.Padding = New-Object Windows.Forms.Padding(4, 0, 4, 0)
  } else { $b.BackColor = $panel }
  return $b
}
# A form: label column + a flow of controls per row.
function New-FormGrid([int]$cols = 2, [int]$labelWidth = 120) {
  $g = New-Object Windows.Forms.TableLayoutPanel
  $g.AutoSize = $true
  $g.Dock = 'Fill'
  $g.ColumnCount = 2
  [void]$g.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Absolute', $labelWidth)))
  [void]$g.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent', 100)))
  return $g
}
function Add-FormRow($grid, [string]$label, $controls) {
  $r = $grid.RowCount
  $grid.RowCount = $r + 1
  [void]$grid.RowStyles.Add((New-Object Windows.Forms.RowStyle('AutoSize')))
  $grid.Controls.Add((New-Label $label), 0, $r)
  $flow = New-Object Windows.Forms.FlowLayoutPanel
  $flow.AutoSize = $true
  $flow.WrapContents = $false
  $flow.Margin = New-Object Windows.Forms.Padding(0, 1, 0, 1)
  foreach ($c in @($controls)) { $flow.Controls.Add($c) }
  $grid.Controls.Add($flow, 1, $r)
}

# One control per row of a one-column TableLayoutPanel: sized to fit, or $pct percent of the room left.
function Add-Stack($panel, $control, [float]$pct = 0) {
  $r = $panel.RowCount
  $panel.RowCount = $r + 1
  $style = if ($pct -gt 0) { New-Object Windows.Forms.RowStyle('Percent', $pct) } else { New-Object Windows.Forms.RowStyle('AutoSize') }
  [void]$panel.RowStyles.Add($style)
  $panel.Controls.Add($control, 0, $r)
}

# Dark look for the stock controls, applied once the window is built. Colours a control was given
# on purpose (the events list, the Developer output) are kept: only system defaults are replaced.
function Set-DarkTheme($parent) {
  foreach ($x in $parent.Controls) {
    $sys = $x.BackColor -eq [Drawing.SystemColors]::Window
    switch ($x.GetType().Name) {
      'TextBox' { if ($sys) { $x.BackColor = $fieldColor; $x.ForeColor = $fg }; $x.BorderStyle = 'FixedSingle' }
      'ComboBox' { $x.FlatStyle = 'Flat'; $x.BackColor = $fieldColor; $x.ForeColor = $fg }
      'ProphecyDarkCombo' { $x.BackColor = $fieldColor; $x.ForeColor = $fg; $x.Cursor = 'Hand' }
      'NumericUpDown' { $x.BackColor = $fieldColor; $x.ForeColor = $fg; $x.BorderStyle = 'FixedSingle' }
      'CheckBox' { $x.FlatStyle = 'Flat'; $x.FlatAppearance.BorderColor = $lineColor; $x.Cursor = 'Hand' }
      'RadioButton' { $x.FlatStyle = 'Flat'; $x.FlatAppearance.BorderColor = $lineColor; $x.Cursor = 'Hand' }
      'ListBox' { if ($sys) { $x.BackColor = $fieldColor; $x.ForeColor = $fg }; $x.BorderStyle = 'None' }
      'ListView' {
        $x.BorderStyle = 'None'
        if ($sys) { $x.BackColor = $fieldColor; $x.ForeColor = $fg }
        # Stock column headers are always light grey; draw them in the window's colours.
        $x.OwnerDraw = $true
        $x.Add_DrawColumnHeader({
          param($s, $e)
          $e.Graphics.FillRectangle((New-Object Drawing.SolidBrush($navBack)), $e.Bounds)
          $r = New-Object Drawing.Rectangle(($e.Bounds.X + 4), $e.Bounds.Y, ($e.Bounds.Width - 4), $e.Bounds.Height)
          $hf = New-Object Drawing.Font($s.Font, [Drawing.FontStyle]::Bold)
          [Windows.Forms.TextRenderer]::DrawText($e.Graphics, $e.Header.Text, $hf, $r, $fg, 'Left, VerticalCenter, EndEllipsis')
          $hf.Dispose()
        })
        $x.Add_DrawItem({ param($s, $e) $e.DrawDefault = $true })
        $x.Add_DrawSubItem({ param($s, $e) $e.DrawDefault = $true })
        # The last column takes the room left, so no undrawn header strip shows on the right.
        if ($x.Columns.Count) {
          $x.Columns[$x.Columns.Count - 1].Width = -2
          $x.Add_Resize({ if ($this.Columns.Count) { $this.Columns[$this.Columns.Count - 1].Width = -2 } })
        }
      }
      'DataGridView' {
        $x.GridColor = $lineColor
        $x.CellBorderStyle = 'SingleHorizontal'
        $x.ColumnHeadersBorderStyle = 'None'
        $x.ColumnHeadersHeightSizeMode = 'DisableResizing'
        $x.ColumnHeadersHeight = 30
        $x.DefaultCellStyle.Padding = New-Object Windows.Forms.Padding(4, 3, 4, 3)
        $x.ColumnHeadersDefaultCellStyle.Padding = New-Object Windows.Forms.Padding(4, 0, 4, 0)
        $x.ColumnHeadersDefaultCellStyle.SelectionBackColor = $navBack
        $x.DefaultCellStyle.SelectionForeColor = $fg
      }
      'SplitContainer' { $x.BackColor = $lineColor; $x.Panel1.BackColor = $back; $x.Panel2.BackColor = $back; $x.SplitterWidth = 1 }
    }
    if ($x.Controls.Count) { Set-DarkTheme $x }
  }
}
# A drop-down drawn in the window's colours: the stock one keeps a light border and a grey arrow
# button even when flat. Compiled once per start (a second or so); the plain ComboBox stands in if
# that fails.
if (-not ('ProphecyDarkCombo' -as [type])) {
  try {
    Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System.Drawing;
using System.Windows.Forms;
public class ProphecyDarkCombo : ComboBox {
  public Color BorderColor = Color.FromArgb(58, 63, 76);
  public Color HoverColor = Color.FromArgb(52, 57, 70);
  public Color ArrowColor = Color.FromArgb(154, 160, 171);
  public ProphecyDarkCombo() {
    DrawMode = DrawMode.OwnerDrawFixed;
    DropDownStyle = ComboBoxStyle.DropDownList;
    FlatStyle = FlatStyle.Flat;
    ItemHeight = 20;
  }
  protected override void OnDrawItem(DrawItemEventArgs e) {
    if (e.Index < 0) return;
    bool inList = (e.State & DrawItemState.ComboBoxEdit) == 0;
    bool sel = inList && (e.State & DrawItemState.Selected) != 0;
    using (SolidBrush b = new SolidBrush(sel ? HoverColor : BackColor)) e.Graphics.FillRectangle(b, e.Bounds);
    Rectangle r = new Rectangle(e.Bounds.X + 4, e.Bounds.Y, e.Bounds.Width - 6, e.Bounds.Height);
    TextRenderer.DrawText(e.Graphics, GetItemText(Items[e.Index]), Font, r, ForeColor,
      TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix);
  }
  protected override void WndProc(ref Message m) {
    base.WndProc(ref m);
    if (m.Msg != 0x000F) return;   // WM_PAINT: paint over the stock border and arrow button
    using (Graphics g = Graphics.FromHwnd(Handle)) {
      Rectangle c = ClientRectangle;
      int bw = SystemInformation.VerticalScrollBarWidth;
      Rectangle btn = new Rectangle(c.Right - bw - 1, 1, bw, c.Height - 2);
      using (SolidBrush b = new SolidBrush(BackColor)) g.FillRectangle(b, btn);
      using (Pen p = new Pen(BackColor)) g.DrawRectangle(p, 1, 1, c.Width - 3, c.Height - 3);
      using (Pen p = new Pen(BorderColor)) g.DrawRectangle(p, 0, 0, c.Width - 1, c.Height - 1);
      int cx = btn.Left + btn.Width / 2, cy = c.Height / 2;
      using (Pen p = new Pen(ArrowColor, 1.6f)) {
        g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
        g.DrawLines(p, new Point[] { new Point(cx - 4, cy - 2), new Point(cx, cy + 2), new Point(cx + 4, cy - 2) });
      }
    }
  }
}
'@
  } catch { }
}
function New-Combo {
  $c = if ('ProphecyDarkCombo' -as [type]) { New-Object ProphecyDarkCombo } else { New-Object Windows.Forms.ComboBox }
  $c.DropDownStyle = 'DropDownList'
  return $c
}
# A 1 px divider line.
function New-Divider {
  $d = New-Object Windows.Forms.Panel
  $d.Dock = 'Top'; $d.Height = 1; $d.BackColor = $lineColor
  return $d
}

# ---- drawn scroll bars --------------------------------------------------------------------------
# Stock scroll bars are always light grey. These are drawn in the old Host screen's style: a dark
# track, a light thumb and small arrow boxes. A bar keeps its state in .Tag: value (0..max), page
# (what one screen shows, for the thumb's size), step (one arrow click or wheel notch), target (the
# control it moves) and on (scriptblock run with ($bar, $value) when the value changes).
$sbTrack = [Drawing.Color]::FromArgb(24, 26, 32)
$sbThumb = [Drawing.Color]::FromArgb(190, 186, 174)
$sbWidth = 15
function New-DarkScrollBar($target, [scriptblock]$onScroll) {
  $b = New-Object Windows.Forms.PictureBox   # double-buffered, so dragging doesn't flicker
  $b.Width = $sbWidth; $b.Dock = 'Right'; $b.BackColor = $sbTrack; $b.Visible = $false
  $b.Tag = @{ value = 0; max = 0; page = 1; step = 1; target = $target; on = $onScroll; drag = $null; hold = $null }
  $b.Add_Paint({
    param($s, $e)
    $t = $s.Tag; $g = $e.Graphics; $w = $s.Width; $h = $s.Height
    $pen = New-Object Drawing.Pen($dim)
    $tri = New-Object Drawing.SolidBrush($fg)
    foreach ($up in $true, $false) {
      $y = if ($up) { 0 } else { $h - $w }
      $g.DrawRectangle($pen, 1, ($y + 1), ($w - 3), ($w - 3))
      $c = [int]($w / 2); $m = $y + [int]($w / 2)
      $pts = if ($up) { @((New-Object Drawing.Point(($c - 4), ($m + 2))), (New-Object Drawing.Point(($c + 4), ($m + 2))), (New-Object Drawing.Point($c, ($m - 2)))) }
             else { @((New-Object Drawing.Point(($c - 4), ($m - 2))), (New-Object Drawing.Point(($c + 4), ($m - 2))), (New-Object Drawing.Point($c, ($m + 2)))) }
      $g.FillPolygon($tri, [Drawing.Point[]]$pts)
    }
    $r = Get-ScrollThumb $s
    if ($r) {
      $g.FillRectangle((New-Object Drawing.SolidBrush($sbThumb)), $r)
      # Grip lines in the middle of the thumb, as on the old screens.
      $grip = New-Object Drawing.Pen([Drawing.Color]::FromArgb(120, 116, 106))
      $my = $r.Top + [int]($r.Height / 2)
      foreach ($d in -3, 0, 3) { $g.DrawLine($grip, ($r.Left + 3), ($my + $d), ($r.Right - 4), ($my + $d)) }
      $grip.Dispose()
    }
    $g.DrawRectangle($pen, 0, 0, ($w - 1), ($h - 1))   # a thin frame round the whole bar
    $pen.Dispose(); $tri.Dispose()
  })
  $b.Add_MouseDown({
    param($s, $e)
    $t = $s.Tag; $w = $s.Width
    $r = Get-ScrollThumb $s
    if ($e.Y -lt $w) { Set-ScrollValue $s ($t.value - $t.step) }
    elseif ($e.Y -ge $s.Height - $w) { Set-ScrollValue $s ($t.value + $t.step) }
    elseif ($r -and $e.Y -ge $r.Top -and $e.Y -lt $r.Bottom) { $t.drag = @($e.Y, $t.value) }
    elseif ($r -and $e.Y -lt $r.Top) { Set-ScrollValue $s ($t.value - $t.page) }
    else { Set-ScrollValue $s ($t.value + $t.page) }
  })
  $b.Add_MouseMove({
    param($s, $e)
    $t = $s.Tag
    if (-not $t.drag) { return }
    $r = Get-ScrollThumb $s
    $room = $s.Height - 2 * $s.Width - $r.Height
    if ($room -gt 0) { Set-ScrollValue $s ($t.drag[1] + ($e.Y - $t.drag[0]) * $t.max / $room) }
  })
  $b.Add_MouseUp({ $this.Tag.drag = $null })
  return $b
}
function Get-ScrollThumb($b) {
  $t = $b.Tag; $w = $b.Width
  $track = $b.Height - 2 * $w
  if ($t.max -le 0 -or $track -le 8) { return $null }
  $len = [Math]::Max(24, [int]($track * $t.page / ($t.max + $t.page)))
  $len = [Math]::Min($len, $track)
  $top = $w + [int](($track - $len) * $t.value / $t.max)
  return (New-Object Drawing.Rectangle(2, $top, ($w - 4), $len))
}
function Set-ScrollValue($b, $v, [switch]$Quiet) {
  $t = $b.Tag
  $v = [int][Math]::Max(0, [Math]::Min($t.max, [double]$v))
  if ($v -eq $t.value) { return }
  $t.value = $v
  $b.Invalidate()
  if (-not $Quiet -and $t.on) { & $t.on $b $v }
}
function Set-ScrollRange($b, [int]$max, [int]$page, [int]$step) {
  $t = $b.Tag
  $t.max = [Math]::Max(0, $max); $t.page = [Math]::Max(1, $page); $t.step = [Math]::Max(1, $step)
  if ($t.value -gt $t.max) { $t.value = $t.max; if ($t.on) { & $t.on $b $t.value } }
  $b.Visible = $t.max -gt 0
  $b.Invalidate()
}
# The wheel moves the bar of whatever it is over (Windows sends it to the control under the mouse);
# Handled stops it bubbling up to the page as well.
function Add-WheelScroll($control, $bar) {
  $script:wheelBars[$control] = $bar
  $control.Add_MouseWheel({
    param($s, $e)
    $b = $script:wheelBars[$s]
    if (-not $b -or -not $b.Visible) { return }
    Set-ScrollValue $b ($b.Tag.value - [Math]::Sign($e.Delta) * $b.Tag.step * 3)
    if ($e -is [Windows.Forms.HandledMouseEventArgs]) { $e.Handled = $true }
  })
}
$script:wheelBars = @{}
# Every control under $root that has no scrolling of its own scrolls the page with the wheel.
function Add-PageWheel($root, $bar) {
  foreach ($x in $root.Controls) {
    if ($x -is [Windows.Forms.ComboBox] -or $x -is [Windows.Forms.DataGridView] -or $x -is [Windows.Forms.ListBox] -or
        $x -is [Windows.Forms.ListView] -or ($x -is [Windows.Forms.TextBox] -and $x.Multiline) -or $x -is [Windows.Forms.PictureBox]) { continue }
    Add-WheelScroll $x $bar
    if ($x.Controls.Count) { Add-PageWheel $x $bar }
  }
}
# A grid with a drawn bar: the grid's own bars are off and the bar moves its first shown row.
function Add-GridScroll($grid) {
  $grid.ScrollBars = 'None'
  $box = New-Object Windows.Forms.Panel
  $box.Dock = 'Fill'; $box.Margin = $grid.Margin
  $bar = New-DarkScrollBar $grid { param($b, $v) $g = $b.Tag.target; if ($g.Rows.Count) { try { $g.FirstDisplayedScrollingRowIndex = [Math]::Min($v, $g.Rows.Count - 1) } catch { } } }
  $box.Controls.Add($grid)
  $box.Controls.Add($bar)
  $grid.BringToFront()
  $script:gridBars[$grid] = $bar
  $grid.Add_Resize({ Update-GridScroll $this })
  $grid.Add_RowHeightChanged({ Update-GridScroll $this })
  $grid.Add_Scroll({ $b = $script:gridBars[$this]; if ($b) { Set-ScrollValue $b $this.FirstDisplayedScrollingRowIndex -Quiet } })
  Add-WheelScroll $grid $bar
  return $box
}
$script:gridBars = @{}
function Update-GridScroll($grid) {
  $bar = $script:gridBars[$grid]
  if (-not $bar) { return }
  # The last first-row that still fills the view: rows have their own heights (wrapped text).
  $room = $grid.ClientSize.Height - $(if ($grid.ColumnHeadersVisible) { $grid.ColumnHeadersHeight } else { 0 })
  $sum = 0; $maxFirst = 0
  for ($i = $grid.Rows.Count - 1; $i -ge 0; $i--) { $sum += $grid.Rows[$i].Height; if ($sum -gt $room) { $maxFirst = $i + 1; break } }
  $shown = [Math]::Max(1, $grid.DisplayedRowCount($false))
  Set-ScrollRange $bar $maxFirst $shown 1
  if ($grid.Rows.Count -and $grid.FirstDisplayedScrollingRowIndex -ge 0) { Set-ScrollValue $bar $grid.FirstDisplayedScrollingRowIndex -Quiet }
}
# A list box with a drawn bar: the box is made wider than its frame so its own bar is cut off.
function Add-ListScroll($list) {
  $box = New-Object Windows.Forms.Panel
  $box.Dock = 'Fill'; $box.Margin = $list.Margin; $box.BackColor = $list.BackColor
  $clip = New-Object Windows.Forms.Panel
  $clip.Dock = 'Fill'; $clip.BackColor = $list.BackColor
  $list.Dock = 'None'; $list.Location = New-Object Drawing.Point(0, 0)
  $clip.Controls.Add($list)
  $bar = New-DarkScrollBar $list { param($b, $v) $b.Tag.target.TopIndex = $v }
  $box.Controls.Add($clip)
  $box.Controls.Add($bar)
  $clip.BringToFront()
  $script:listBars[$list] = $bar
  $clip.Tag = $list
  $clip.Add_Resize({ $l = $this.Tag; $l.Size = New-Object Drawing.Size(($this.Width + [Windows.Forms.SystemInformation]::VerticalScrollBarWidth), $this.Height); Update-ListScroll $l })
  Add-WheelScroll $list $bar
  return $box
}
$script:listBars = @{}
function Update-ListScroll($list) {
  $bar = $script:listBars[$list]
  if (-not $bar) { return }
  $shown = [Math]::Max(1, [int][Math]::Floor($list.ClientSize.Height / [Math]::Max(1, $list.ItemHeight)))
  Set-ScrollRange $bar ($list.Items.Count - $shown) $shown 1
  Set-ScrollValue $bar $list.TopIndex -Quiet
}

$form = New-Object Windows.Forms.Form
$form.Text = $title
$form.ClientSize = New-Object Drawing.Size(1040, 860)
$form.MinimumSize = New-Object Drawing.Size(960, 660)
$form.StartPosition = 'CenterScreen'
$form.BackColor = $back
$form.ForeColor = $fg
$form.Font = New-Object Drawing.Font('Segoe UI', 10)

# ---- top: who you are, used by Join, Host and solo games ----
# Header: the title across the top (the tabs are in the sidebar below it).
$header = New-Object Windows.Forms.TableLayoutPanel
$header.Dock = 'Top'; $header.AutoSize = $true; $header.ColumnCount = 2; $header.RowCount = 1
$header.Padding = New-Object Windows.Forms.Padding(18, 12, 18, 6)
[void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('AutoSize')))
[void]$header.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent', 100)))
$head = New-Label $(if ($script:devMode) { 'Prophecy' } else { $title })
$head.Font = New-Object Drawing.Font('Segoe UI', 15, [Drawing.FontStyle]::Bold)
$head.ForeColor = $gold
$head.Margin = New-Object Windows.Forms.Padding(0, 0, 28, 6)
$header.Controls.Add($head, 0, 0)
# The tabs: a column of boxed buttons in a sidebar on the left, as on the old Python launcher.
$sidebar = New-Object Windows.Forms.Panel
$sidebar.Dock = 'Left'; $sidebar.Width = 150
$sidebar.BackColor = $navBack
$sidebar.Padding = New-Object Windows.Forms.Padding(14, 14, 14, 14)
$nav = New-Object Windows.Forms.FlowLayoutPanel
$nav.Dock = 'Fill'; $nav.FlowDirection = 'TopDown'; $nav.WrapContents = $false
$nav.BackColor = $navBack
$sidebar.Controls.Add($nav)
$navBorder = [Drawing.Color]::FromArgb(150, 155, 166)

# Who you are, used by Join, Host and solo games: a quiet band under the header.
$top = New-Object Windows.Forms.TableLayoutPanel
$top.Dock = 'Top'; $top.AutoSize = $true; $top.ColumnCount = 1
$top.BackColor = $panel
$top.Padding = New-Object Windows.Forms.Padding(18, 10, 18, 8)
$who = New-Object Windows.Forms.FlowLayoutPanel
$who.AutoSize = $true; $who.WrapContents = $false
$who.Controls.Add((New-Label 'Name'))
$nameBox = New-Object Windows.Forms.TextBox
$nameBox.Font = New-Object Drawing.Font('Consolas', 11)
$nameBox.Width = 190
$nameBox.MaxLength = 20
$nameBox.Text = [string](Get-Cfg 'name' '')
$who.Controls.Add($nameBox)
# Rolls a new random name into the box; it is saved like a typed one.
$reroll = New-Button 'New'
$reroll.Add_Click({ $nameBox.Text = New-RandomName; Save-Name })
(New-Object Windows.Forms.ToolTip).SetToolTip($reroll, 'Pick a new random name')
$who.Controls.Add($reroll)
(New-Object Windows.Forms.ToolTip).SetToolTip($nameBox, 'Letters, digits, _ - . (up to 20)')
$leaderLbl = New-Label 'Leader'
$leaderLbl.Margin = New-Object Windows.Forms.Padding(24, 4, 8, 2)
$who.Controls.Add($leaderLbl)
$pick = New-Combo
$pick.DropDownStyle = 'DropDownList'
$pick.Width = 200
[void]$pick.Items.Add('Random')
foreach ($l in $leaders) { [void]$pick.Items.Add(('{0} ({1})' -f $l.name, $l.class)) }
$savedLeader = [int](Get-Cfg 'leader' 0)
$pick.SelectedIndex = 0
for ($i = 0; $i -lt $leaders.Count; $i++) { if ([int]$leaders[$i].id -eq $savedLeader) { $pick.SelectedIndex = $i + 1 } }
$who.Controls.Add($pick)
$details = New-Button 'Details' -Link
$who.Controls.Add($details)
Add-Stack $top $who
# Two lines, always: a longer leader text is cut with ... rather than pushing the tabs down.
$passive = New-Label '' -Dim
$passive.AutoSize = $false
$passive.AutoEllipsis = $true
$passive.Size = New-Object Drawing.Size(840, 38)
$passive.Anchor = 'Left, Right'
Add-Stack $top $passive

function Get-LeaderId { if ($pick.SelectedIndex -gt 0) { [int]$leaders[$pick.SelectedIndex - 1].id } else { 0 } }
function Show-Passive {
  $passive.Text = if ($pick.SelectedIndex -gt 0) {
    $l = $leaders[$pick.SelectedIndex - 1]
    "Skill: $(Get-LeaderText $l 'skill')`nPassive: $(Get-LeaderText $l 'passive')"
  } else { 'The host deals you a random leader. If someone already has your pick, you get a random one too.' }
  if ($script:leaderCurrent) { $script:leaderCurrent.Text = 'Your leader: ' + [string]$pick.SelectedItem }
}
# The name as the game takes it: only characters that can ride in the join URL (the same rule as
# Start-Preset.ps1 -Name). An empty box gets a random name rather than the game's "Player N".
function Get-PlayerName {
  $nameBox.Text = ($nameBox.Text -replace '[^A-Za-z0-9_.-]', '')
  if (-not $nameBox.Text) { $nameBox.Text = New-RandomName }
  return $nameBox.Text
}
function Save-Name { Set-Cfg 'name' (Get-PlayerName); Save-Cfg }
$nameBox.Add_Leave({ Save-Name })
$pick.Add_SelectedIndexChanged({ Show-Passive; Set-Cfg 'leader' (Get-LeaderId); Save-Cfg; if ($script:leaderGrid) { Select-LeaderRow } })
Show-Passive

# ---- bottom: the status line, versions and updates ----
$bottom = New-Object Windows.Forms.Panel
$bottom.Dock = 'Bottom'
$bottom.Size = New-Object Drawing.Size(1040, 96)   # the form's width, so the anchored labels below keep their sizes
$bottom.Padding = New-Object Windows.Forms.Padding(18, 6, 18, 4)
$bottom.Controls.Add((New-Divider))
$status = New-Object Windows.Forms.Label
$status.SetBounds(18, 10, 700, 40)
$status.Anchor = 'Top, Left, Right'
$status.ForeColor = $dim
$status.AutoEllipsis = $true   # a long message ends in ...; hover shows all of it
$bottom.Controls.Add($status)
$updBtn = New-Button 'Update'
$updBtn.AutoSize = $false
$updBtn.SetBounds(18, 56, 90, 28)
$updState = New-Object Windows.Forms.Label
$updState.Font = New-Object Drawing.Font('Segoe UI', 8.5)
$updState.SetBounds(118, 55, 560, 17)
$ver = New-Object Windows.Forms.Label
$ver.ForeColor = $dim
$ver.Font = New-Object Drawing.Font('Segoe UI', 8.5)
$ver.AutoEllipsis = $true
$ver.SetBounds(118, 72, 560, 19)
$ver.Anchor = 'Top, Left, Right'
$bottom.Controls.AddRange(@($updBtn, $updState, $ver))
# A sleepy sloth in the lower right corner (plain ASCII: this file has no BOM, so PS 5.1 reads it as ANSI).
$sloth = New-Object Windows.Forms.Label
$sloth.Text = @'
==========/====
    ( -.- ) zZ
    /)   (\
'@
$sloth.Font = New-Object Drawing.Font('Consolas', 8)
$sloth.ForeColor = $gold
$sloth.TextAlign = 'TopLeft'   # per-line right alignment would skew the drawing
$sloth.SetBounds(914, 48, 112, 42)
$sloth.Anchor = 'Top, Right'
$bottom.Controls.Add($sloth)

$statusTip = New-Object Windows.Forms.ToolTip
function Say($text, $color) {
  $status.Text = $text
  $statusTip.SetToolTip($status, $text)
  $status.ForeColor = if ($color) { $color } else { $dim }
  $form.Refresh()
}

# ---- tabs: plain panels, one shown at a time (a stock TabControl can't be drawn dark) ----
$pagesHost = New-Object Windows.Forms.Panel
$pagesHost.Dock = 'Fill'
$pagesHost.BackColor = $back
$pagesHost.Padding = New-Object Windows.Forms.Padding(6, 8, 6, 0)
$script:pages = [ordered]@{}
$script:tabHooks = @{}
$script:currentTab = ''
# $minHeight: the page scrolls when the window is shorter than that (its contents fill the rest).
# The page is a panel inside a clipping view; the drawn bar moves it up and down.
function New-TabPage($text, [int]$minHeight = 0) {
  $outer = New-Object Windows.Forms.Panel
  $outer.Dock = 'Fill'; $outer.BackColor = $back; $outer.Visible = $false
  $view = New-Object Windows.Forms.Panel
  $view.Dock = 'Fill'; $view.BackColor = $back
  $p = New-Object Windows.Forms.Panel
  $p.BackColor = $back; $p.ForeColor = $fg
  $p.Location = New-Object Drawing.Point(0, 0)
  $view.Controls.Add($p)
  $bar = New-DarkScrollBar $p { param($b, $v) $b.Tag.target.Top = -$v }
  $outer.Controls.Add($view)
  $outer.Controls.Add($bar)
  $view.BringToFront()
  $view.Tag = @{ page = $p; bar = $bar; min = $minHeight }
  $view.Add_Resize({
    $t = $this.Tag
    $h = [Math]::Max($this.Height, $t.min)
    $t.page.Size = New-Object Drawing.Size($this.Width, $h)
    Set-ScrollRange $t.bar ($h - $this.Height) $this.Height 40
    $t.page.Top = -$t.bar.Tag.value
  })
  $pagesHost.Controls.Add($outer)
  $n = New-Object Windows.Forms.Label
  $n.Text = $text; $n.Tag = $text; $n.UseMnemonic = $false   # a & in a name shows as itself
  $n.AutoSize = $false; $n.Size = New-Object Drawing.Size(122, 36); $n.Cursor = 'Hand'
  $n.TextAlign = 'MiddleLeft'
  $n.Font = New-Object Drawing.Font('Segoe UI', 10)
  $n.ForeColor = $fg; $n.BackColor = $navBack
  $n.Padding = New-Object Windows.Forms.Padding(10, 0, 0, 0)
  $n.Margin = New-Object Windows.Forms.Padding(0, 0, 0, 7)
  $n.Add_Click({ Show-Tab $this.Tag })
  $n.Add_MouseEnter({ if ($this.Tag -ne $script:currentTab) { $this.BackColor = $hoverColor } })
  $n.Add_MouseLeave({ if ($this.Tag -ne $script:currentTab) { $this.BackColor = $navBack } })
  $n.Add_Paint({
    param($s, $e)
    $c = if ($s.Tag -eq $script:currentTab) { $lineColor } else { $navBorder }
    $pen = New-Object Drawing.Pen($c)
    $e.Graphics.DrawRectangle($pen, 0, 0, ($s.Width - 1), ($s.Height - 1))
    $pen.Dispose()
  })
  $nav.Controls.Add($n)
  $script:pages[$text] = @{ page = $outer; nav = $n; bar = $bar; content = $p }
  return $p
}
function Show-Tab($text) {
  if (-not $script:pages.Contains($text)) { return }
  $script:currentTab = $text
  foreach ($k in @($script:pages.Keys)) {
    $t = $script:pages[$k]; $on = $k -eq $text
    $t.page.Visible = $on
    $t.nav.ForeColor = if ($on) { $gold } else { $fg }
    $t.nav.BackColor = if ($on) { $panel } else { $navBack }
    $t.nav.Invalidate()
  }
  if ($script:tabHooks.ContainsKey($text)) { & $script:tabHooks[$text] }
}
$joinPage = New-TabPage 'Join' 260
$hostPage = New-TabPage 'Host' 1060   # room for the players table and events below the set-up rows
$leadersPage = New-TabPage 'Leaders' 300
$traitsPage = New-TabPage 'Traits' 300
$devPage = if ($script:devMode) { New-TabPage 'Developer' 1100 } else { $null }
# Docking runs from the last added: footer, header and its line across the whole width, then the
# sidebar down the left, then the name/leader band and the pages to its right.
$form.Controls.Add($pagesHost)
$form.Controls.Add($top)
$form.Controls.Add($sidebar)
$form.Controls.Add((New-Divider))
$form.Controls.Add($header)
$form.Controls.Add($bottom)
$pagesHost.BringToFront()
Show-Tab 'Join'
$details.Add_Click({ Show-Tab 'Leaders' })

# ---- Join tab ----------------------------------------------------------------------------------
$jg = New-Object Windows.Forms.TableLayoutPanel
$jg.Dock = 'Fill'; $jg.ColumnCount = 1
$jg.Padding = New-Object Windows.Forms.Padding(12, 8, 12, 8)
$joinPage.Controls.Add($jg)
$joinForm = New-FormGrid
$box = New-Object Windows.Forms.TextBox
$box.Font = New-Object Drawing.Font('Consolas', 12)
$box.Width = 320
$box.Text = [string](Get-Cfg 'address' '')
$join = New-Button 'Join' -Primary
Add-FormRow $joinForm 'Host address' @($box, $join)
Add-FormRow $joinForm '' @((New-Label $(if ($script:devMode) { "A LAN address or the host's playit address. Port 7777 if left out." } else { 'Already filled in. Change it only if the host gives you a new one.' }) -Dim -Wrap 560))
$soloGames = Get-SoloGames
$soloKeys = @($soloGames.Keys)
$soloPick = New-Combo
$soloPick.DropDownStyle = 'DropDownList'
$soloPick.Width = 320
foreach ($k in $soloKeys) { [void]$soloPick.Items.Add($soloGames[$k]) }
$savedSolo = [string](Get-Cfg 'solo' 'standard')
if ($savedSolo -eq 'fast-test') { $savedSolo = 'test-solo' }  # renamed 2026-10-30
$soloPick.SelectedIndex = [Math]::Max(0, [array]::IndexOf($soloKeys, $savedSolo))
$solo = New-Button 'Play solo'
Add-FormRow $joinForm 'Play alone' @($soloPick, $solo)
$close = New-Button 'Close game'
$logBtn = New-Button 'Open game log'
Add-FormRow $joinForm '' @($close, $logBtn)
Add-Stack $jg $joinForm
$form.AcceptButton = $join

# ---- Leaders and Traits tabs -------------------------------------------------------------------
# Read-only grids. $columns: @(heading, width[, 'image']); rows: arrays of strings or Images.
function New-Grid($columns, $rows) {
  $grid = New-Object Windows.Forms.DataGridView
  $grid.Dock = 'Fill'
  $grid.ReadOnly = $true
  $grid.AllowUserToAddRows = $false
  $grid.AllowUserToResizeRows = $false
  $grid.RowHeadersVisible = $false
  $grid.SelectionMode = 'FullRowSelect'
  $grid.MultiSelect = $false
  $grid.AutoSizeRowsMode = 'AllCells'
  $grid.BackgroundColor = $back
  $grid.BorderStyle = 'None'
  $grid.DefaultCellStyle.WrapMode = 'True'
  $grid.DefaultCellStyle.BackColor = $back
  $grid.DefaultCellStyle.ForeColor = $fg
  $grid.DefaultCellStyle.SelectionBackColor = [Drawing.Color]::FromArgb(50, 55, 68)
  $grid.EnableHeadersVisualStyles = $false
  $grid.ColumnHeadersDefaultCellStyle.BackColor = $navBack
  $grid.ColumnHeadersDefaultCellStyle.ForeColor = $dim
  $grid.ColumnHeadersDefaultCellStyle.Font = New-Object Drawing.Font('Segoe UI', 10.5, [Drawing.FontStyle]::Bold)
  foreach ($c in $columns) {
    if ($c.Count -gt 2 -and $c[2] -eq 'image') {
      $col = New-Object Windows.Forms.DataGridViewImageColumn
      $col.HeaderText = $c[0]
      $col.ImageLayout = 'Zoom'
      $col.DefaultCellStyle.NullValue = $null   # no red "missing image" cross for rows without an icon
      $i = $grid.Columns.Add($col)
    } else { $i = $grid.Columns.Add($c[0], $c[0]) }
    $grid.Columns[$i].Width = $c[1]
    if ($c.Count -gt 2 -and $c[2] -eq 'fill') { $grid.Columns[$i].AutoSizeMode = 'Fill' }
  }
  # A cell value the grid can't draw (e.g. an icon PowerShell handed over still wrapped as a
  # PSObject) makes DataGridView show its default error box on every repaint, which never stops.
  # Handle the event so it can't loop: note the first error and carry on with a blank cell.
  $grid.Add_DataError({
    param($s, $e)
    $e.ThrowException = $false
    if (-not $script:gridErrorNoted) {
      $script:gridErrorNoted = $true
      try { Set-Content (Join-Path $(if ($bundle) { $bundle } else { "$repo\local" }) 'table-error.txt') ("row $($e.RowIndex) column $($e.ColumnIndex): " + ($e.Exception | Out-String)) -Encoding ascii } catch { }
    }
  })
  Set-GridRows $grid $rows
  return $grid
}
function Set-GridRows($grid, $rows) {
  $grid.Rows.Clear()
  foreach ($r in $rows) {
    # Hand the grid plain .NET objects: values from New-Object and function output arrive wrapped
    # in PSObject, and an image cell can't format a wrapped Bitmap.
    $vals = New-Object object[] $r.Count
    for ($k = 0; $k -lt $r.Count; $k++) { $v = $r[$k]; if ($null -ne $v) { $v = $v.psobject.BaseObject }; $vals[$k] = $v }
    [void]$grid.Rows.Add($vals)
  }
  Update-GridScroll $grid
}
# A trait's icon scaled to 32 px, or $null when its PNG isn't in this copy. Read from bytes so the
# file isn't locked (an update can replace it while the window is open).
function Get-TraitIcon($t) {
  $png = Join-Path $iconDir "$($t.icon).png"
  if (-not $t.icon -or -not (Test-Path $png)) { return $null }
  try {
    $img = [Drawing.Image]::FromStream((New-Object IO.MemoryStream(, [IO.File]::ReadAllBytes($png))))
    return (New-Object Drawing.Bitmap($img, 32, 32))
  } catch { return $null }
}
function Select-LeaderRow {
  $g = $script:leaderGrid
  if (-not $g -or $g.Rows.Count -le $pick.SelectedIndex) { return }
  $script:selectingLeader = $true
  $g.ClearSelection(); $g.Rows[$pick.SelectedIndex].Selected = $true
  $script:selectingLeader = $false
}
$lp = New-Object Windows.Forms.TableLayoutPanel
$lp.Dock = 'Fill'; $lp.ColumnCount = 1; $lp.Padding = New-Object Windows.Forms.Padding(10, 4, 10, 4)
Add-Stack $lp (New-Label 'Pick the leader you play. Your leader stands on your board, gets every trait that is active for your team, and has a skill and a passive of their own. If someone else already has your pick, you get a random leader.' -Dim -Wrap 700)
$script:leaderCurrent = New-Label ''
$script:leaderCurrent.Font = New-Object Drawing.Font('Consolas', 14, [Drawing.FontStyle]::Bold)
$script:leaderCurrent.ForeColor = $gold
$script:leaderCurrent.Margin = New-Object Windows.Forms.Padding(0, 8, 0, 8)
Add-Stack $lp $script:leaderCurrent
Show-Passive   # fills the line above with the current pick
$leaderRows = @(, @('Random', '', '', 'The host deals you a random free leader.')) + @($leaders | ForEach-Object { , @($_.name, $_.class, (Get-LeaderText $_ 'skill'), (Get-LeaderText $_ 'passive')) })
$script:leaderGrid = New-Grid @(@('Leader', 100), @('Class', 80), @('Skill', 340, 'fill'), @('Passive', 340, 'fill')) $leaderRows
$script:leaderGrid.Add_SelectionChanged({
  $g = $script:leaderGrid
  if ($script:selectingLeader -or -not $g.SelectedRows.Count) { return }
  $i = $g.SelectedRows[0].Index
  if ($i -ne $pick.SelectedIndex -and $i -lt $pick.Items.Count) { $pick.SelectedIndex = $i }
})
Add-Stack $lp (Add-GridScroll $script:leaderGrid) 100
$leadersPage.Controls.Add($lp)
$tp = New-Object Windows.Forms.TableLayoutPanel
$tp.Dock = 'Fill'; $tp.ColumnCount = 1; $tp.Padding = New-Object Windows.Forms.Padding(10, 4, 10, 4)
$findRow = New-Object Windows.Forms.FlowLayoutPanel
$findRow.AutoSize = $true; $findRow.WrapContents = $false
$findLbl = New-Label 'Find'; $findLbl.Margin = New-Object Windows.Forms.Padding(0, 6, 8, 0)
$findRow.Controls.Add($findLbl)
$find = New-Object Windows.Forms.TextBox
$find.Width = 240; $find.Margin = New-Object Windows.Forms.Padding(0, 3, 0, 6)
$findRow.Controls.Add($find)
Add-Stack $tp $findRow
# Every trait: icon, name, bonus, holders needed per tier, effect (tier values filled in, as the game words it).
$traitRows = @($traits | ForEach-Object { , @((Get-TraitIcon $_), $_.name, $_.bonus, (@($_.tiers | ForEach-Object { $_.holders }) -join '/'), $_.effect) })
$traitGrid = New-Grid @(@('', 40, 'image'), @('Trait', 110), @('Bonus', 140), @('Holders', 70), @('Effect', 500, 'fill')) $traitRows
$traitGrid.Columns[1].DefaultCellStyle.ForeColor = $warn   # trait names in gold, as on the old Traits screen
$traitGrid.Columns[2].DefaultCellStyle.ForeColor = $dim
if (-not $traits) { Set-GridRows $traitGrid @(, @($null, 'No trait list in this copy (traits.json missing).', '', '', 'Press Update, or ask the host for the latest update.')) }
$find.Add_TextChanged({
  $q = $find.Text.Trim()
  Set-GridRows $traitGrid @($traitRows | Where-Object { -not $q -or (($_[1], $_[2], $_[4]) -join ' ') -like "*$q*" })
})
Add-Stack $tp (Add-GridScroll $traitGrid) 100
$traitsPage.Controls.Add($tp)

# ---- updates from the feed (friend copies) ------------------------------------------------------
# Updates come from the feed at update_url. Update-Prophecy.ps1 does the work (it updates itself
# first, then installs the payload; docs/server/friend-updates.md), and this window restarts into
# the new version.
function Get-Version {
  if ($script:devMode) { return (Get-DevBuild).label }
  $f = Join-Path $bundle 'version.txt'
  if (Test-Path $f) { (Get-Content $f -TotalCount 1).Trim() } else { '' }
}
# What this launcher hosts, for the Host tab's comparison with the feed.
function Get-HostedVersion {
  if ($script:devMode) { $b = Get-DevBuild; return @{ label = $b.label; commit = $b.commit; version = ''; live = $b.live } }
  return @{ label = Get-Version; commit = ''; version = Get-Version; live = $true }
}
$updater = Join-Path $bin 'Update-Prophecy.ps1'

# update_url (friends) or the patch address (host PC) as a full URL without a trailing slash.
function Get-UpdateUrl {
  $url = if ($script:devMode) { [string](Get-Cfg 'update_address' '') } else { [string](Get-Cfg 'update_url' '') }
  if (-not $url) { return '' }
  $m = [regex]::Match($url, '^(?:https?://)?(?:www\.)?github\.com/([\w.-]+)/([\w.-]+?)(?:\.git)?/?$')
  if ($m.Success) { $url = "https://raw.githubusercontent.com/$($m.Groups[1].Value)/$($m.Groups[2].Value)/main" }
  if ($url -notmatch '^https?://') { $url = "http://$url" }
  # GitHub only speaks TLS 1.2+, which Windows PowerShell 5.1 doesn't enable by default.
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  return $url.TrimEnd('/')
}

# The line next to the Update button: result of the last check.
function Set-UpdateState($text, $color) {
  $updState.Text = $text
  $updState.ForeColor = if ($color) { $color } else { $dim }
}
function Show-CheckResult($latestVersion) {
  $when = Get-Date -Format 'HH:mm'
  if (-not $latestVersion -or $latestVersion -eq (Get-Version)) { Set-UpdateState "Up to date (checked $when)" $good }
  else { Set-UpdateState "Update available: $latestVersion. Press Update or Join." $gold }
}

# 'current', 'unreachable', 'none' (no update_url), 'failed', or 'restarting'.
function Update-FromHost([switch]$ThenJoin) {
  if ($script:devMode) { return 'none' }   # the host PC's builds come from Update live build
  $url = Get-UpdateUrl
  if (-not $url) { Set-UpdateState 'No update address set.'; return 'none' }
  if (-not (Test-Path $updater)) { Set-UpdateState 'Update-Prophecy.ps1 is missing; ask the host for an update zip.' $bad; return 'failed' }
  Say 'Checking for updates ...'
  $out = @(& powershell -NoProfile -ExecutionPolicy Bypass -File $updater -Bundle $bundle -Url $url 2>&1 | ForEach-Object { "$_" })
  $code = $LASTEXITCODE
  $result = [string]($out | Where-Object { $_ -like 'RESULT *' } | Select-Object -Last 1)
  switch ($code) {
    0 { Show-CheckResult ''; return 'current' }
    2 { Set-UpdateState "Couldn't check for updates ($(Get-Date -Format 'HH:mm'))." $bad; return 'unreachable' }
    3 { }
    default {
      $why = if ($result) { $result -replace '^RESULT failed ', '' } else { ($out -join ' ').Trim() }
      Say "Update failed: $why Press Join to try again." $bad
      Set-UpdateState 'Update failed to install.' $bad
      return 'failed'
    }
  }
  Clear-WebMark
  # This script is already in memory, so start the new one and close this window.
  Start-Process powershell -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$PSCommandPath`"", $(if ($ThenJoin) { '-AutoJoin' } else { '-Updated' })
  $script:restarting = $true
  $form.Close()
  return 'restarting'
}

# ---- first-time setup from the friend's own Steam install --------------------------------------
# The setup package (Build-FriendBundle.ps1 -Setup) holds only these scripts. Unzipped into an empty
# folder, the window finds Prophecy in Steam and copies it here once (robocopy, ~1.7 GB). Files that
# are already here (these scripts, friend.json) are never overwritten, and the Steam install is
# only read.

# True when this folder is inside a Steam library: never patch the Steam install itself.
function Test-SteamFolder { return (-not $script:devMode) -and ("$bundle\" -match '\\steamapps\\common\\') }

# The Steam install of Prophecy (folder with Phoenix\Binaries\Win64\Phoenix.exe), or $null.
function Find-SteamProphecy {
  $roots = New-Object System.Collections.ArrayList
  foreach ($key in 'HKCU:\Software\Valve\Steam', 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam', 'HKLM:\SOFTWARE\Valve\Steam') {
    try {
      $k = Get-ItemProperty $key -ErrorAction Stop
      foreach ($v in $k.SteamPath, $k.InstallPath) { if ($v) { [void]$roots.Add(($v -replace '/', '\')) } }
    } catch { }
  }
  [void]$roots.Add("${env:ProgramFiles(x86)}\Steam")
  # Other Steam libraries (other drives) are listed in libraryfolders.vdf as "path" "D:\\SteamLibrary".
  $libs = New-Object System.Collections.ArrayList
  foreach ($r in $roots) {
    [void]$libs.Add($r)
    $vdf = Join-Path $r 'steamapps\libraryfolders.vdf'
    if (Test-Path $vdf) {
      foreach ($m in [regex]::Matches((Get-Content $vdf -Raw), '"path"\s+"([^"]+)"')) { [void]$libs.Add(($m.Groups[1].Value -replace '\\\\', '\')) }
    }
  }
  foreach ($l in $libs) {
    $p = Join-Path $l 'steamapps\common\Prophecy'
    if (Test-Path (Join-Path $p 'Phoenix\Binaries\Win64\Phoenix.exe')) { return $p }
  }
  return $null
}

$script:copying = $null
$copyTimer = New-Object Windows.Forms.Timer
$copyTimer.Interval = 1000
$copyTimer.Add_Tick({
  $p = $script:copying
  if (-not $p.HasExited) {
    Say ("Copying the game from Steam into this folder ... {0:N0} s (about 1.7 GB; a few minutes)" -f ((Get-Date) - $script:copyStart).TotalSeconds) $gold
    return
  }
  $copyTimer.Stop()
  $script:copying = $null
  # robocopy: 0-7 = copied (or nothing to copy), 8+ = errors.
  if ($p.ExitCode -ge 8 -or -not (Test-Path (Get-GameExe))) {
    Say "Copying the game failed (robocopy code $($p.ExitCode)). Check there is 2 GB free here, then reopen this window." $bad
    return
  }
  Say 'Game copied. Restarting the window ...' $good
  Start-Process powershell -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$PSCommandPath`""
  $script:restarting = $true
  $form.Close()
})

# Offers the copy when this folder has no game yet. Returns $true when a copy started.
function Start-FirstSetup {
  if ($script:devMode -or (Test-Path (Get-GameExe)) -or (Test-SteamFolder)) { return $false }
  $steam = Find-SteamProphecy
  if (-not $steam) {
    Say "No game here yet, and Prophecy isn't installed in Steam on this PC. Install it from Steam (free), then reopen this window." $bad
    return $false
  }
  $ans = [Windows.Forms.MessageBox]::Show("This folder doesn't have the game yet. Copy Prophecy from your Steam install into it now?`n`nFrom: $steam`nTo: $bundle`n`nAbout 1.7 GB, a few minutes. Your Steam install is only read, never changed.", $title, 'YesNo', 'Question')
  if ($ans -ne 'Yes') { Say 'Join needs the game in this folder. Reopen this window to copy it from Steam.' $bad; return $false }
  # /E all folders, /XC /XN /XO skip every file that already exists here (these scripts).
  $script:copying = Start-Process robocopy -ArgumentList "`"$steam`"", "`"$bundle`"", '/E', '/XC', '/XN', '/XO', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP' -WindowStyle Hidden -PassThru
  $script:copyStart = Get-Date
  $copyTimer.Start()
  return $true
}

# Checks shared by Join, Play solo and Open lobby; throws with a message for the status line.
function Assert-CanStart {
  if (Test-SteamFolder) { throw "This folder is your Steam install of Prophecy, which must stay as it is. Copy the scripts into an empty folder instead (START-HERE.txt), and the launcher copies the game for you." }
  if (-not (Test-Path (Get-GameExe))) {
    if ($script:copying) { throw 'Still copying the game from Steam; this works once that is done.' }
    if ($script:devMode) { throw "No game copy at $(Get-GameDir). Pick the build or the host copy on the Developer tab." }
    throw "Phoenix.exe is missing from $bin. Install Prophecy from Steam, then close and reopen this window: it offers to copy the game here."
  }
  # One game per PC: two Phoenix.exe on one PC fight over the same ports and settings.
  $running = @(Get-AnyGame)
  if ($running.Count) {
    $where = if ($running[0].Path) { Split-Path (Split-Path (Split-Path (Split-Path $running[0].Path))) } else { 'another folder' }
    throw "A game is already running ($where). Close it first (Close game, or Stop server on the Host tab)."
  }
  if ($script:devMode) { return }   # the host PC's copies are patched by Update live build / Apply host patches
  # The 6-card shop screen and the board layout are built here from this copy's own game files.
  # Fast when already built; on failure Patch-Phoenix leaves shop-six / board-layout off below.
  $shopBuild = Join-Path $bin 'Build-ShopScreen.ps1'
  if (Test-Path $shopBuild) {
    Say 'Checking the shop screen ...'
    $script:shopOut = & powershell -NoProfile -ExecutionPolicy Bypass -File $shopBuild 2>&1 | Out-String
    if (Test-Path (Join-Path $bin 'board-layout-delta.json')) {
      Say 'Checking the board layout ...'
      $script:shopOut += & powershell -NoProfile -ExecutionPolicy Bypass -File $shopBuild -Recipe board-layout-delta.json -Label 'board layout' 2>&1 | Out-String
    }
  }
  # Exe patches (the whole host set: RTS camera, all boards visible, hosting ...). Safe to run every time.
  $patcher = Join-Path $bin 'Patch-Phoenix.ps1'
  if (Test-Path $patcher) {
    # Last line "RESULT ok|missing|failed ...", exit 0 / 4 / 1 (it reads the exe back to check).
    $out = @(& powershell -NoProfile -ExecutionPolicy Bypass -File $patcher 2>&1 | ForEach-Object { "$_" })
    $code = $LASTEXITCODE
    if ($code -ne 0 -and $code -ne 4) {
      # A copy that isn't fully patched is refused by the host, so stop here and say what to do.
      $report = Join-Path $bundle 'patch-report.txt'
      try { Set-Content $report (@("Patch-Phoenix.ps1 on $(Get-Date -Format s), version $(Get-Version)") + $out) -Encoding ascii } catch { }
      $failedLine = [string]($out | Where-Object { $_ -like 'RESULT *' } | Select-Object -Last 1)
      $why = if ($failedLine) { $failedLine -replace '^RESULT failed ', '' } else { 'see patch-report.txt' }
      throw "The game patch didn't apply ($why). Press Update, then try again. If it still fails, send the host patch-report.txt from your Prophecy-Online folder."
    }
    # A patch that needs a file this copy doesn't have yet (the 6-card shop screen, the board
    # layout) stays off; the host refuses a copy without it ("incompatible version"), so say why
    # once per window.
    $missing = @($out | Where-Object { $_ -like 'MISSING *' })
    if ($missing.Count -and -not $script:toldMissing) {
      $script:toldMissing = $true
      [void][Windows.Forms.MessageBox]::Show("This copy is missing a game file it builds for itself (the 6-card shop screen or the board layout), so that part is off and the host will refuse this copy. Click Update and try again (or ask the host for a new bundle).`n`n" + ($missing -join "`n") + $(if ($script:shopOut) { "`n`n" + $script:shopOut.Trim() } else { '' }), $title, 'OK', 'Warning')
    }
  }
  if (-not (Test-Prereqs)) {
    $setup = Join-Path $bundle 'Engine\Extras\Redist\en-us\UE4PrereqSetup_x64.exe'
    $ans = [Windows.Forms.MessageBox]::Show("This PC is missing Visual C++ / DirectX parts the game needs. Install them now? This runs Microsoft's installer that ships with the game. You can say No and try anyway.", $title, 'YesNo', 'Question')
    if ($ans -eq 'Yes' -and (Test-Path $setup)) { Start-Process $setup -Wait }
  }
}

# Start-Preset.ps1 right away (Join and Play solo: it only writes two ini files and starts the game).
function Invoke-StartPresetNow([string[]]$arguments) {
  $out = & powershell -NoProfile -ExecutionPolicy Bypass -File (Get-StartPreset) -Dev (Get-GameDir) @arguments 2>&1
  if ($LASTEXITCODE) { throw ($out | Out-String) }
}

$join.Add_Click({
  try {
    Assert-CanStart
    # After a restart from an update the check already ran; skipping it also rules out a loop.
    if (-not $AutoJoin -and (Update-FromHost -ThenJoin) -in 'failed', 'restarting') { return }
    $script:AutoJoin = $false
    Say 'Finding the host...'
    $addr = Get-JoinAddress $box.Text
    Set-Cfg 'address' $box.Text.Trim()
    Save-Name
    Say "Starting the game and connecting to $addr ..."
    # Keep the last run's log for diagnosis; a fresh log lets the watcher below read from the start.
    $logFile = Get-LogFile
    if (Test-Path $logFile) { Move-Item $logFile ($logFile -replace '\.log$', '-previous.log') -Force -ErrorAction SilentlyContinue }
    Invoke-StartPresetNow @('-Role', 'client', '-Connect', $addr, '-Leader', (Get-LeaderId), '-Name', (Get-PlayerName))
    $script:runRole = 'client'
    Say "Game started, connecting to $addr. It loads straight into the match. Keep this window open: it tells you if the connection drops." $good
    Start-Watch
  } catch {
    Say $_.Exception.Message $bad
  }
})
# A game of your own against bots on this PC, no host needed. Start-Preset writes this copy's
# Engine.ini/Game.ini for the preset; the next Join rewrites the boot settings for joining, and the
# Game.ini rules only apply to games this PC runs itself, so nothing needs restoring. Your name and
# leader pick ride along (every copy has the leader-pick and player-name patches).
$solo.Add_Click({
  try {
    Assert-CanStart
    $preset = $soloKeys[$soloPick.SelectedIndex]
    Set-Cfg 'solo' $preset
    Save-Name
    $watch.Stop()
    Say "Starting a solo game ($($soloGames[$preset])) ..."
    Invoke-StartPresetNow @('-Role', 'solo', '-Preset', $preset, '-Leader', (Get-LeaderId), '-Name', (Get-PlayerName))
    $script:runRole = 'solo'
    Say 'Solo game started: you against bots, after the intro. Close the game window (or press Close game) when you are done.' $good
  } catch {
    Say $_.Exception.Message $bad
  }
})

# ---- connection watcher ---------------------------------------------------------------------
# When the host closes or the connection drops, the game times out (~25 s) and falls back to its
# empty default map, which ends in "Failed to load package ''". The engine does that fallback on
# its own, so instead this follows the game log: on the first sign of a lost connection it closes
# the game before the fallback and says what happened in plain words.
$joinedRx = 'Welcomed by server|Join succeeded'
$lostRx = 'Network Failure|NetworkFailure|TravelFailure|Connection TIMED OUT|Connection timed out|ConnectionLost|PendingConnectionFailure|Failed to load package '''''
$outdatedRx = 'OutdatedClient|OutdatedServer|incompatible version of the game'
$script:logPos = 0
$script:joined = $false
$script:mismatchTried = $false
$script:runRole = ''
$watch = New-Object Windows.Forms.Timer
$watch.Interval = 500

function Start-Watch {
  $script:logPos = 0
  $script:joined = $false
  $watch.Start()
}

# latest.json from the feed right now ($null when unreachable), for the version-mismatch message.
function Get-FeedLatest {
  $url = Get-UpdateUrl
  if (-not $url) { return $null }
  try { return (Invoke-WebRequest "$url/latest.json?t=$([DateTime]::UtcNow.Ticks)" -TimeoutSec 8 -UseBasicParsing).Content | ConvertFrom-Json }
  catch { return $null }
}

# The host said this copy's version is not its own. If the feed has a newer version, install it
# and join again (once per window, so it can't loop). Otherwise the host runs a build that isn't
# published yet, or it was published a moment ago and hasn't reached this PC: say which.
function Resolve-VersionMismatch {
  if ($script:devMode) { Say "The host runs another build than $(Get-Version). Switch build on the Developer tab, or ask the host to update." $bad; return }
  $mine = Get-Version
  Say 'The host is running a different version. Checking for an update ...' $gold
  $latest = Get-FeedLatest
  if ($latest -and $latest.version -and $latest.version -ne $mine -and -not $script:mismatchTried) {
    $script:mismatchTried = $true
    Say "The host is on a newer version. Updating to $($latest.version), then joining again ..." $gold
    if ((Update-FromHost -ThenJoin) -in 'restarting', 'failed') { return }
    $mine = Get-Version
  }
  $fresh = ''
  if ($latest -and $latest.published) {
    try {
      $mins = [int]((Get-Date).ToUniversalTime() - [DateTime]::Parse([string]$latest.published).ToUniversalTime()).TotalMinutes
      if ($mins -ge 0 -and $mins -lt 15) { $fresh = " The newest update came out $mins min ago and can take up to 10 minutes to reach you, so press Join again in a few minutes." }
    } catch { }
  }
  if (-not $latest) {
    Say "The host is running a different version than yours ($mine), and the update address can't be reached right now. Check your internet connection and press Join again." $bad
  } else {
    Say "The host is running a different version than yours. You have the latest published one ($mine).$fresh Otherwise ask the host to send out their version (Make friend update)." $bad
  }
}

function Read-NewLog {
  $logFile = Get-LogFile
  if (-not (Test-Path $logFile)) { return '' }
  try {
    $fs = [IO.File]::Open($logFile, 'Open', 'Read', 'ReadWrite')
    try {
      if ($fs.Length -lt $script:logPos) { $script:logPos = 0 }
      [void]$fs.Seek($script:logPos, 'Begin')
      $text = (New-Object IO.StreamReader($fs)).ReadToEnd()
      $script:logPos = $fs.Length
      return $text
    } finally { $fs.Close() }
  } catch { return '' }
}

$watch.Add_Tick({
  $text = Read-NewLog
  if (-not $script:joined -and $text -match $joinedRx) {
    $script:joined = $true
    Say 'In the match. Keep this window open: it tells you if the connection drops.' $good
  }
  # The host refused this copy's version ("OutdatedClient"; the host logs "Client connecting with
  # invalid version"). Before the timeout fallback, so it isn't reported as "couldn't reach".
  if ($text -match $outdatedRx) {
    $watch.Stop()
    Get-OurGame | Stop-Process -Force -ErrorAction SilentlyContinue
    Resolve-VersionMismatch
    return
  }
  if ($text -match $lostRx) {
    $watch.Stop()
    Get-OurGame | Stop-Process -Force -ErrorAction SilentlyContinue
    if ($script:joined) {
      Say 'The host closed the match, or the connection dropped. The game was closed. Press Join to reconnect when the host is hosting again.' $bad
    } else {
      Say "Couldn't reach the host. Check that they're hosting right now and the address is right, then press Join again." $bad
    }
    return
  }
  if (-not (Get-OurGame)) {
    $watch.Stop()
    if ($script:joined) { Say 'Game closed.' }
  }
})

$close.Add_Click({
  $p = Get-OurGame
  $watch.Stop()
  if ($p -and $script:runRole -eq 'host') { Show-Tab 'Host'; Say 'You are hosting: use Stop server on the Host tab.'; return }
  if ($p) { $p | Stop-Process -Force; Say 'Game closed.' } else { Say 'No game running from this copy.' }
})
$logBtn.Add_Click({ $f = Get-LogFile; if (Test-Path $f) { Start-Process notepad.exe $f } else { Say 'No log yet; start the game first.' } })

if ($script:devMode) {
  $updBtn.Visible = $false
  $updState.Visible = $false
} else {
  $updBtn.Add_Click({
    if (Get-OurGame) { Say 'Close the game first, then press Update.'; return }
    switch (Update-FromHost) {
      'none' { Say 'No update address is set; ask the host for an update zip.' }
      'unreachable' { Say "Couldn't reach the update address. Check your internet connection, or ask the host for an update zip." $bad }
      'current' { Say 'You have the latest version.' $good }
    }
  })
}
# The version (friends) or the build (host PC) under the status line.
function Update-BuildViews {
  if ($script:devMode) {
    $b = Get-DevBuild
    $ver.Text = "Plays $($b.label): $($b.hostCopy)" + $(if ($b.note) { "  $([char]0x00B7)  $($b.note)" } else { '' })
    $ver.ForeColor = if ($b.note) { $warn } else { $dim }
    if ($script:hostUi) { Update-HostPresets }
    if ($script:devUi) { Update-DevTab }
  } else {
    $v = Get-Version
    $ver.Text = if ($v) { "Your version: $v" } else { 'Your version: unknown' }
  }
}

# On open, check for a newer version in the background (nothing is installed until Update or
# Join), so the window doesn't hang while offline. The download runs as a .NET task and a timer on
# this window's thread polls it, so no PowerShell code runs on another thread.
$checkTimer = New-Object Windows.Forms.Timer
$checkTimer.Interval = 250
$checkTimer.Add_Tick({
  $t = $script:checkTask
  if (-not $t.IsCompleted) {
    if (((Get-Date) - $script:checkStart).TotalSeconds -gt 15) { $checkTimer.Stop(); Set-UpdateState "Couldn't check for updates ($(Get-Date -Format 'HH:mm'))." $bad }
    return
  }
  $checkTimer.Stop()
  if ($t.IsFaulted -or $t.IsCanceled) { Set-UpdateState "Couldn't check for updates ($(Get-Date -Format 'HH:mm'))." $bad; return }
  try { Show-CheckResult ($t.Result | ConvertFrom-Json).version } catch { Set-UpdateState "Couldn't read the update info." $bad }
})
function Start-UpdateCheck {
  if ($script:devMode) { return }
  $url = Get-UpdateUrl
  if (-not $url) { Set-UpdateState 'No update address set.'; return }
  Set-UpdateState 'Checking for updates ...'
  try {
    $script:checkTask = (New-Object Net.WebClient).DownloadStringTaskAsync([Uri]"$url/latest.json?t=$([DateTime]::UtcNow.Ticks)")
    $script:checkStart = Get-Date
    $checkTimer.Start()
  } catch { Set-UpdateState 'Press Update to check for a newer version.' }
}

# ---- Host and Developer tabs ---------------------------------------------------------------------
# Host-Prophecy.ps1 (lobby, players, start, stop): every copy has it, except a bootstrap update
# that is about to install the rest.
$hostScript = Join-Path $bin 'Host-Prophecy.ps1'
$script:hostUi = $null
$script:devUi = $null
if (Test-Path $hostScript) {
  . $hostScript
  New-HostTab $hostPage
  $hostTimer = New-Object Windows.Forms.Timer
  $hostTimer.Interval = 1000
  $hostTimer.Add_Tick({ try { Update-HostTab } catch { Set-HostMsg "Host tab: $($_.Exception.Message)" $bad } })
  $hostTimer.Start()
} else {
  $hostPage.Controls.Add((New-Label 'Hosting arrives with the next update: press Update.' -Dim))
}
if ($script:devMode) {
  New-DevTab $devPage
  $script:tabHooks['Developer'] = { Update-DevTab }
}
Update-BuildViews
Set-DarkTheme $form
foreach ($k in @($script:pages.Keys)) { $t = $script:pages[$k]; Add-WheelScroll $t.content $t.bar; Add-PageWheel $t.content $t.bar }
if ($script:devMode -and $script:devUi) { foreach ($n in $devNotes) { Add-DevOutput $n } }

$status.Text = if ($script:devMode) { 'Join a host, play solo, or host on the Host tab.' } else { 'Press Join when the host says they are hosting. You have about a minute; the match starts when everyone is in.' }
if ($gameDataNote) { $status.Text = $gameDataNote; $status.ForeColor = $bad }

$form.Add_FormClosing({
  param($s, $e)
  if ($script:restarting) { return }
  if ($script:hostUi -and -not (Confirm-HostClose)) { $e.Cancel = $true; return }
  Save-Name
})

$form.Add_Shown({
  if ($script:devMode) {
    # Open on the Host tab when this copy's game already hosts (started before the launcher).
    if (Get-OurGame) { Show-Tab 'Host' }
    return
  }
  if (Test-SteamFolder) { Say 'This folder is your Steam install of Prophecy. Put these scripts in an empty folder instead (START-HERE.txt); the launcher then copies the game there for you.' $bad; return }
  if (Start-FirstSetup) { return }
  # An older join window installed the bootstrap (update.zip) and restarted into this one: run the
  # updater now for the full update (it restarts the window again), then carry on as asked.
  $v = Get-Version
  if ($v -like '*-bootstrap') {
    Say 'Finishing the update ...'
    if ((Update-FromHost -ThenJoin:$AutoJoin) -eq 'restarting') { return }
  }
  if ($AutoJoin) { Set-UpdateState "Updated to $v." $good; Say "Updated to version $v. Joining ..." $good; $join.PerformClick() }
  elseif ($Updated) { Set-UpdateState "Updated to $v." $good; Say "Updated to version $v. Press Join when the host is hosting." $good }
  else { Start-UpdateCheck }
})

[void]$form.ShowDialog()
