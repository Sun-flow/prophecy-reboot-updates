PROPHECY - JOINING A FRIEND'S MATCH
===================================

Nothing to install. You need Windows 10 or 11.

1. Unzip this whole folder anywhere (Desktop is fine). Don't run it from inside the zip.
   Tip: before unzipping, right-click the zip > Properties > tick "Unblock" > OK.
   That stops Windows from warning about every file.

2. When the host says they're hosting, double-click "Play Prophecy.bat".
   If Windows says "Windows protected your PC", click "More info" > "Run anyway".
   If it says "An Application Control policy has blocked this file", right-click
   "Play Prophecy.bat" > Properties > tick "Unblock" > OK, then try again.

3. The launcher opens on the Join tab. Your name and leader are at the top; the
   host's address is already filled in. Press Join.
   The game opens and loads straight into the match. Start within about a minute
   of the host; the match begins when everyone is in. If the host holds the lobby
   ("Wait for my OK"), there's no rush: the host starts the match once you're in.

Want to try the game on your own first? Pick a game under "Play alone" and press
Play solo: you play against bots, no host needed. The "Leaders" and
"Traits" tabs explain what each leader and trait does; click a leader to play it.

Scouting: press F in the match for an overview camera. Move it with W/A/S/D, the
arrow keys or by pushing the mouse against the window edge; mouse wheel zooms;
hold the middle mouse button and drag to turn it. Press F again to get your
normal camera back. Every player's board and bench is visible.

Hosting your own match: open the Host tab, then press Open lobby. Your game opens and
waits in the lobby. Give your friends the address the Host tab shows, watch them join
in the Players list, and press Start match once everyone is in; bots fill the empty
seats. Stop server ends it.
- Friends in your house use the LAN address.
- For friends elsewhere, run a tunnel such as playit.gg (UDP to port 7777 on your PC),
  paste its address into Join address on the Host tab and give friends that address. The
  "Experimental" box asks your router to open the port instead; it often doesn't work.
- The first time, Windows Firewall asks about Phoenix.exe: click Allow.
- Everyone needs the same version, so the launcher updates before it opens the lobby.

If the game asks to install Visual C++ / DirectX parts, say Yes (Microsoft's installer,
shipped with the game). If Windows Firewall asks about Phoenix.exe, click Allow.

Join first checks for a newer version and updates itself if there is one.
You can also press Update at any time. If the host turns out to be on a different
version, the launcher says so, updates and joins again by itself.

Keep the launcher open while you play. If the host closes the match or the
connection drops, it closes the game for you and says what happened. Press Join
again once the host is hosting.

If it doesn't connect:
- Check the host is hosting right now, and ask whether their address changed.
  You can type a new address in the box.
- Press "Open game log" on the Join tab and send the host the file
  (Phoenix\Saved\Logs\Phoenix.log in this folder).
