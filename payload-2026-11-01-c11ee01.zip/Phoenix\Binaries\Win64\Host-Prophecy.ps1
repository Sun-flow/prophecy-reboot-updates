# The Host tab of the launcher (Join-Prophecy.ps1): open a lobby on this PC, watch players connect
# (and see why one couldn't), start the held match, follow the match, stop the server.
# Dot-sourced by Join-Prophecy.ps1, which owns the window, the name/leader row, the settings, the
# update check and the patcher; this file defines the log reader, the router helper and the tab.
#
# Every copy carries the whole host patch set (client-patches.json for friends, Update live build
# for the host PC), so hosting works the same everywhere: the match holds while HoldMatch.flag sits
# next to Phoenix.exe, and Start match deletes it. Joiners need the host's version, so on a
# friend's copy Open lobby first installs the newest version from the update feed.
#
# Reaching the host:
#   Tunnel    playit.gg (or Tailscale, Radmin VPN) set up by the host: the supported route. The
#             host pastes its address into Join address, which is shown with Copy.
#   LAN       other PCs in the same house join this PC's LAN address directly.
#   Router    experimental (off by default): ask the router to forward the game port (UDP) to
#             this PC: UPnP first (Windows' built-in HNetCfg.NATUPnP), then NAT-PMP. Removed again
#             by Stop server. Can't work with both off, or behind carrier-grade / double NAT.
#   Windows Firewall asks once, the first time the game listens; the host clicks Allow.
#
# Needs only Windows PowerShell 5.1. Nothing is installed.

# ---- the host's game log --------------------------------------------------------------------
# Follows each connection from first packet to leaving, plus the match state, the round, who
# fights on which board and seats bots took over. Pure functions over a hashtable, so it can be
# checked without Windows (launcher\tools\test_host_prophecy.ps1). The lines it reads (UE 4.22
# LogNet plus our patches' lines):
#
#   LogNet: GameNetDriver IpNetDriver_0 IpNetDriver listening on port 7777
#   LogNet: NotifyAcceptingConnection accepted from: 127.246.196.185:17343      (handshake, repeats)
#   LogNet: AddClientConnection: Added client connection: [UNetConnection] RemoteAddr: <addr>, ...
#   LogNet: NotifyControlMessage: Client connecting with invalid version. ...  (other build: refused)
#   LogNet: Login request: ?Name=<PC>-<hex>?DevOpen?Leader=3596?Nick=zoob ...
#   LogFPGame_GameMode: LeaderPick: player 257 asked 3596, got 3596              (patch leader-pick)
#   LogFPGame_GameMode: PlayerName: player 257 is zoob                          (patch player-name)
#   LogNet: Join succeeded: zoob
#   LogNet: Warning: UNetConnection::Tick: Connection TIMED OUT. ... RemoteAddr: <addr>, ...
#   LogNet: UNetConnection::Close: [UNetConnection] RemoteAddr: <addr>, ...
#   LogGameState: Match State Changed from Prepare to Standby
#   Phoenix:  ## Unit composition for board 2, round 5, player zoob against opponent Qazzikk ##
#   LogFPGame_GameMode: Initializing AI takeover player
#   LogExit: Game engine shut down
#
# The host's own login has no AddClientConnection line before it. Playit joiners show 127.x
# addresses (the tunnel's local end), one per joiner.

$HostLogRx = [ordered]@{
  listen   = 'IpNetDriver listening on port (\d+)'
  accept   = 'NotifyAcceptingConnection accepted from: ([\d.]+:\d+)'
  conn     = 'AddClientConnection: Added client connection: .*?RemoteAddr: ([^,\s]+)'
  version  = 'Client connecting with invalid version'
  login    = 'Login request: \?Name=([^?\s]+)(\S*)'
  leader   = 'LeaderPick: player (\d+) asked (-?\d+), got (\d+)'
  pname    = 'PlayerName: player (\d+) is (\S+)'
  join     = 'Join succeeded: (.+)'
  timeout  = 'Connection TIMED OUT.*?RemoteAddr: ([^,\s]+)'
  close    = 'UNetConnection::Close: .*?RemoteAddr: ([^,\s]+)'
  state    = 'Match State Changed from \w+ to (\w+)'
  fight    = 'Unit composition for board (\d+), round (\d+), player (\S+) against opponent (\S+?) ##'
  takeover = 'Initializing AI takeover player'
  exit     = 'LogExit: (Game engine shut down|Preparing to exit)'
}
$HostNameMax = 20
$HostGone = @('wrong version', 'timed out', 'left')
$HostPreMatch = @('', 'EnteringMap', 'WaitingToStart')
$HostPhases = @{ Introductions = 'intro'; Prepare = 'shopping'; Standby = 'about to fight'; Combat = 'fighting'
  Result = 'results'; Transition = 'next round'; InProgress = 'starting'; WaitingToStart = 'waiting in the lobby'
  EnteringMap = 'loading'; WaitingPostMatch = 'match over'; LeavingMap = 'closing' }

function New-HostLog {
  param([datetime]$After = [datetime]::MinValue)  # skip lines stamped before this (UTC): an older game's log
  @{ players = [ordered]@{}; port = 0; state = ''; round = 0; events = New-Object System.Collections.ArrayList
     fights = @{}; home = @{}; takeovers = 0; exiting = $false
     conn = $null; login = $null; ids = [ordered]@{}; after = $After; now = $null }
}

function New-HostPlayer($log, $key, $status) {
  [pscustomobject]@{ key = $key; status = $status; pc = ''; name = ''; leader = 0; asked = 0; ghost = $false
    note = ''; since = (Get-HostNow $log) }
}

# The log's own time (UTC) of the line being read, else now.
function Get-HostNow($log) { if ($log.now) { $log.now } else { [DateTime]::UtcNow } }

function Get-HostPlayerLabel($p) { if ($p.name) { $p.name } elseif ($p.pc) { $p.pc } else { $p.key } }

function Set-HostPlayerStatus($log, $p, $status, $note = '') {
  if ($p.status -ne $status) { $p.status = $status; $p.since = Get-HostNow $log }
  if ($note) { $p.note = $note }
}

function Add-HostEvent($log, $text) {
  [void]$log.events.Add([pscustomobject]@{ time = (Get-HostNow $log); text = $text })
  while ($log.events.Count -gt 200) { $log.events.RemoveAt(0) }
}

function Get-HostShortName([string]$n) { if ($n.Length -gt $HostNameMax) { $n.Substring(0, $HostNameMax) } else { $n } }

# One log line into $log.
function Update-HostLog($log, [string]$line) {
  # "[2026.10.31-11.38.50:625][...]": the game stamps its log in UTC.
  $ts = [regex]::Match($line, '^\[(\d{4})\.(\d\d)\.(\d\d)-(\d\d)\.(\d\d)\.(\d\d)')
  if ($ts.Success) {
    $v = @(1..6 | ForEach-Object { [int]$ts.Groups[$_].Value })
    $log.now = New-Object DateTime($v[0], $v[1], $v[2], $v[3], $v[4], $v[5], [DateTimeKind]::Utc)
  }
  if ($log.now -and $log.now -lt $log.after) { return }
  foreach ($kind in $HostLogRx.Keys) {
    $m = [regex]::Match($line, $HostLogRx[$kind])
    if (-not $m.Success) { continue }
    $g = @($m.Groups | Select-Object -Skip 1 | ForEach-Object { $_.Value })
    switch ($kind) {
      'listen' { $log.port = [int]$g[0]; Add-HostEvent $log "Server listening on port $($g[0])" }
      'accept' {
        $p = $log.players[$g[0]]
        if (-not $p -or $HostGone -contains $p.status) {
          if ($p) { $log.players.Remove($g[0]) }
          $log.players[$g[0]] = New-HostPlayer $log $g[0] 'connecting'
          Add-HostEvent $log "Someone is connecting from $($g[0])"
        }
      }
      'conn' {
        $p = $log.players[$g[0]]
        if (-not $p) { $p = New-HostPlayer $log $g[0] 'connecting'; $log.players[$g[0]] = $p }
        Set-HostPlayerStatus $log $p 'logging in'
        $log.conn = $g[0]
      }
      'version' {
        $p = if ($log.conn) { $log.players[$log.conn] } else { $null }
        if ($p) {
          Set-HostPlayerStatus $log $p 'wrong version' 'their game is another version: they press Update, then Join'
          Add-HostEvent $log "Refused $(Get-HostPlayerLabel $p): different game version (they press Update, then Join)"
        } else { Add-HostEvent $log 'Refused a player: different game version (they press Update, then Join)' }
      }
      'login' {
        $key = if ($log.conn) { $log.conn } else { 'host' }
        $log.conn = $null
        $p = $log.players[$key]
        if (-not $p) { $p = New-HostPlayer $log $key 'logging in'; $log.players[$key] = $p }
        Set-HostPlayerStatus $log $p 'logging in'
        $p.pc = $g[0] -replace '-[0-9A-Fa-f]{16,}$', ''
        $nick = [regex]::Match($g[1], '\?Nick=([^?\s]+)', 'IgnoreCase')
        $p.name = if ($nick.Success) { Get-HostShortName $nick.Groups[1].Value } else { $p.pc }
        $log.login = $key
      }
      'leader' { $log.ids[$g[0]] = @([int]$g[1], [int]$g[2]) }
      'pname' {
        # LeaderPick and PlayerName for the same player id come together, just before Join succeeded.
        $p = if ($log.login) { $log.players[$log.login] } else { $null }
        if (-not $p -and -not $log.players.Contains('host')) {
          # The host's own player has no Login request line; its name line is its join.
          $st = if ($HostPreMatch -contains $log.state) { 'in lobby' } else { 'playing' }
          $p = New-HostPlayer $log 'host' $st
          $log.players['host'] = $p
        }
        if ($p) {
          if ($log.ids.Contains($g[0])) { $p.asked = $log.ids[$g[0]][0]; $p.leader = $log.ids[$g[0]][1]; $log.ids.Remove($g[0]) }
          $p.name = Get-HostShortName $g[1]
        }
      }
      'join' {
        $p = if ($log.login) { $log.players[$log.login] } else { $null }
        if (-not $p) { break }
        $n = $g[0].Trim()
        if ($n -and $n -notmatch '^Player \d+$') { $p.name = Get-HostShortName $n }
        if ($p.leader -eq 0 -and $log.ids.Count) {
          # A leader line without a name line (no player-name patch).
          $first = @($log.ids.Keys)[0]
          $p.asked = $log.ids[$first][0]; $p.leader = $log.ids[$first][1]; $log.ids.Remove($first)
        }
        $st = if ($HostPreMatch -contains $log.state) { 'in lobby' } else { 'playing' }
        Set-HostPlayerStatus $log $p $st
        $log.login = $null
        # The same PC joining again (it restarted its game) leaves its old connection open until it
        # times out 25 s later, and the old seat stays in the lobby meanwhile.
        foreach ($o in @($log.players.Values)) {
          if ($o -ne $p -and $o.key -ne 'host' -and $o.pc -eq $p.pc -and $HostGone -notcontains $o.status) {
            $o.ghost = $true
            $o.note = 'old connection left behind when they rejoined; it times out on its own within 25 s, but if the match starts first it keeps a seat (and its leader)'
          }
        }
        if ($p.key -ne 'host') {
          $from = if ($p.pc -and $p.pc -ne (Get-HostPlayerLabel $p)) { " from $($p.pc)" } else { '' }
          Add-HostEvent $log "$(Get-HostPlayerLabel $p) joined$from"
        }
      }
      'timeout' {
        $p = $log.players[$g[0]]
        if ($p -and $HostGone -notcontains $p.status) { Set-HostPlayerStatus $log $p 'timed out'; Add-HostEvent $log "$(Get-HostPlayerLabel $p) timed out (no packets for 25 s)" }
      }
      'close' {
        $p = $log.players[$g[0]]
        if ($p -and $HostGone -notcontains $p.status) {
          Set-HostPlayerStatus $log $p 'left'
          Add-HostEvent $log $(if ($p.name) { "$($p.name) left" } else { "Connection from $($g[0]) closed" })
        }
      }
      'state' {
        if ($g[0] -eq $log.state) { break }  # GameMode and GameState both log each change
        $before = $log.state
        $log.state = $g[0]
        if ($HostPreMatch -contains $before -and $HostPreMatch -notcontains $g[0]) {
          foreach ($p in @($log.players.Values)) { if ($p.status -eq 'in lobby') { Set-HostPlayerStatus $log $p 'playing' } }
          Add-HostEvent $log 'Match started'
        } elseif ($g[0] -eq 'Prepare' -and $log.round) { $log.fights = @{} }
      }
      'fight' {
        $r = [int]$g[1]
        if ($r -ne $log.round) { $log.round = $r; $log.fights = @{}; Add-HostEvent $log "Round ${r}: fights begin" }
        # The first name is the board's owner: that board is their own seat.
        $log.home[$g[2]] = [int]$g[0]
        $log.fights[$g[2]] = @([int]$g[0], $g[3])
        $log.fights[$g[3]] = @([int]$g[0], $g[2])
      }
      'takeover' { $log.takeovers++ }
      'exit' { if (-not $log.exiting) { $log.exiting = $true; Add-HostEvent $log 'Game is shutting down' } }
    }
    return
  }
}

function Test-HostStarted($log) { $HostPreMatch -notcontains $log.state }

# Players connected now, the host first.
function Get-HostPresent($log) {
  $rows = @($log.players.Values | Where-Object { $HostGone -notcontains $_.status })
  @($rows | Where-Object { $_.key -eq 'host' }) + @($rows | Where-Object { $_.key -ne 'host' })
}

# Every player to show: present ones first (host on top), then those who left in the last
# $KeepGone seconds, newest first. $Now: UTC (default: the clock).
function Get-HostRows($log, [int]$KeepGone = 600, $Now = $null) {
  if (-not $Now) { $Now = [DateTime]::UtcNow }
  $gone = @($log.players.Values | Where-Object { $HostGone -contains $_.status -and ($Now - $_.since).TotalSeconds -le $KeepGone } |
    Sort-Object since -Descending)
  @(Get-HostPresent $log) + $gone
}

function Get-HostPhase($log) {
  if ($HostPhases.ContainsKey($log.state)) { $HostPhases[$log.state] } elseif ($log.state) { $log.state } else { 'not started' }
}

# (board, opponent) a player fights this round, or $null before the first fight.
function Get-HostFight($log, $name) { if ($name -and $log.fights.ContainsKey($name)) { $log.fights[$name] } else { $null } }
# Their own board (1-8), known from the first round they fight on it.
function Get-HostHome($log, $name) { if ($name -and $log.home.ContainsKey($name)) { $log.home[$name] } else { $null } }

# ---- addresses and the router ---------------------------------------------------------------

# This PC's LAN address: the one Windows uses for its default route.
function Get-LanIp {
  try {
    $s = New-Object Net.Sockets.Socket([Net.Sockets.AddressFamily]::InterNetwork, [Net.Sockets.SocketType]::Dgram, [Net.Sockets.ProtocolType]::Udp)
    $s.Connect('192.0.2.1', 9)  # UDP connect sends nothing; it only picks a route
    $ip = $s.LocalEndPoint.Address.IPAddressToString
    $s.Close()
    return $ip
  } catch { return '' }
}

# True for addresses nobody outside can reach: private ranges and carrier-grade NAT (100.64/10).
function Test-PrivateIp([string]$ip) {
  $b = @($ip -split '\.' | ForEach-Object { [int]$_ })
  if ($b.Count -ne 4) { return $true }
  return ($b[0] -eq 10) -or ($b[0] -eq 127) -or ($b[0] -eq 0) -or ($b[0] -eq 192 -and $b[1] -eq 168) -or
    ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or ($b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127) -or
    ($b[0] -eq 169 -and $b[1] -eq 254)
}

# Runs in a background job (Start-Job), so the window stays responsive while the router answers.
# Action 'open' forwards UDP $Port to $LanIp, 'close' removes the forward. Prints lines:
#   OK <upnp|natpmp> <outside address>      forward in place
#   PRIVATE <upnp|natpmp> <outside address> forward made, but the router's outside address is
#                                           private (carrier-grade or double NAT): useless
#   FAIL <why>                              no router answered, or it refused
#   CLOSED <upnp|natpmp|none>
$RouterScript = {
  param([string]$Action, [int]$Port, [string]$LanIp, [string]$Label = 'Prophecy Rewritten', [string]$Gateway = '', [switch]$NoUpnp)
  function Test-Private([string]$ip) {
    $b = @($ip -split '\.' | ForEach-Object { [int]$_ })
    if ($b.Count -ne 4) { return $true }
    return ($b[0] -eq 10) -or ($b[0] -eq 192 -and $b[1] -eq 168) -or ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) -or
      ($b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127) -or ($b[0] -eq 0)
  }
  function Get-Gateway {
    if ($Gateway) { return $Gateway }
    try {
      $r = Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled = true' -ErrorAction Stop |
        Where-Object { $_.DefaultIPGateway } | Select-Object -First 1
      return @($r.DefaultIPGateway | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' })[0]
    } catch { return $null }
  }
  # NAT-PMP (RFC 6886): one UDP request to the gateway's port 5351, answer within 2 s.
  function Send-NatPmp([string]$gw, [byte[]]$req) {
    $u = New-Object Net.Sockets.UdpClient
    try {
      $u.Client.ReceiveTimeout = 2000
      $u.Connect($gw, 5351)
      [void]$u.Send($req, $req.Length)
      $ep = New-Object Net.IPEndPoint([Net.IPAddress]::Any, 0)
      return $u.Receive([ref]$ep)
    } catch { return $null } finally { $u.Close() }
  }
  function Get-PortBytes([int]$v) { $hi = ($v -shr 8) -band 255; $lo = $v -band 255; return [byte[]]@($hi, $lo) }
  function Invoke-NatPmpMap([string]$gw, [int]$lifetime) {
    $life = [BitConverter]::GetBytes([uint32]$lifetime); [Array]::Reverse($life)
    $req = [byte[]](@(0, 1, 0, 0) + (Get-PortBytes $Port) + (Get-PortBytes $Port) + $life)
    $r = Send-NatPmp $gw $req
    return ($r -and $r.Length -ge 16 -and $r[1] -eq 129 -and $r[2] -eq 0 -and $r[3] -eq 0)
  }

  $why = @()
  if ($Action -eq 'open') {
    # UPnP through Windows' own NAT traversal object. StaticPortMappingCollection is $null when no
    # UPnP router answered (UPnP off, or Windows' discovery service off).
    try {
      if ($NoUpnp) { throw 'skipped' }
      $nat = New-Object -ComObject HNetCfg.NATUPnP
      $maps = $nat.StaticPortMappingCollection
      if ($maps) {
        try { $maps.Remove($Port, 'UDP') } catch { }
        $m = $maps.Add($Port, 'UDP', $Port, $LanIp, $true, $Label)
        $ext = [string]$m.ExternalIPAddress
        if ($ext) { if (Test-Private $ext) { "PRIVATE upnp $ext" } else { "OK upnp $ext" }; return }
        $why += 'the router took the UPnP forward but gave no outside address'
      } else { $why += 'no router answered UPnP' }
    } catch { $why += "UPnP failed ($($_.Exception.Message.Trim()))" }
    $gw = Get-Gateway
    if ($gw) {
      $r = Send-NatPmp $gw ([byte[]]@(0, 0))
      if ($r -and $r.Length -ge 12 -and $r[1] -eq 128 -and $r[2] -eq 0 -and $r[3] -eq 0) {
        $ext = '{0}.{1}.{2}.{3}' -f $r[8], $r[9], $r[10], $r[11]
        if (Invoke-NatPmpMap $gw 7200) { if (Test-Private $ext) { "PRIVATE natpmp $ext" } else { "OK natpmp $ext" }; return }
        $why += 'the router refused the NAT-PMP forward'
      } else { $why += 'no router answered NAT-PMP' }
    } else { $why += 'no gateway found' }
    "FAIL $($why -join '; ')"
    return
  }
  if ($Action -eq 'close') {
    $done = 'none'
    try {
      $maps = (New-Object -ComObject HNetCfg.NATUPnP).StaticPortMappingCollection
      if ($maps) { $maps.Remove($Port, 'UDP'); $done = 'upnp' }
    } catch { }
    $gw = Get-Gateway
    if ($gw -and (Invoke-NatPmpMap $gw 0)) { $done = 'natpmp' }
    "CLOSED $done"
  }
}


# ---- the Host tab -----------------------------------------------------------------------------
# Uses from Join-Prophecy.ps1: $form, the colours ($fg $dim $good $bad $gold $warn $panel), the UI
# helpers (New-Label, New-Button, New-FormGrid, Add-FormRow), Get-Cfg, Set-Cfg, Save-Cfg,
# $script:devMode, Get-GameDir, Get-GameBin, Get-LogFile, Get-OurGame, Get-LeaderId,
# Get-PlayerName, Get-LeaderName, Say, Assert-CanStart, Update-FromHost, Get-Version,
# Get-HostedVersion, Get-UpdateUrl, Start-Task, Get-PresetChoices, Show-Tab and (developer copy only)
# Test-DevCanHost. Everything lives in script scope ($script:hostUi holds the controls), because the
# event handlers run after New-HostTab has returned.

$HostStatusColour = @{ 'connecting' = 'warn'; 'logging in' = 'warn'; 'in lobby' = 'good'; 'playing' = 'good'
  'wrong version' = 'bad'; 'timed out' = 'bad'; 'left' = 'gone' }
$HostStallSeconds = 30   # a connection stuck before its login this long is shown as stuck
$HoldMaxMinutes = 30     # cap on the automatic start of a held match, whatever the settings say
$TunnelAgents = [ordered]@{ playit = 'playit.gg agent'; RvRvpnGui = 'Radmin VPN' }
$PlayitPaths = @("$env:ProgramFiles\playit_gg\bin\playit.exe", "$env:LOCALAPPDATA\playit_gg\bin\playit.exe",
  "$env:ProgramFiles\playit\playit.exe", "$env:USERPROFILE\playit\playit.exe")

function Get-HostColour($key) {
  switch ($key) { 'good' { $good } 'warn' { $warn } 'bad' { $bad } 'gone' { [Drawing.Color]::FromArgb(122, 128, 139) } default { $fg } }
}

function Get-Ago([datetime]$utc) {
  $s = [int][Math]::Max(0, ([DateTime]::UtcNow - $utc).TotalSeconds)
  if ($s -lt 90) { "$s s ago" } elseif ($s -lt 5400) { "$([int]($s / 60)) min ago" } else { "$([int]($s / 3600)) h ago" }
}

function Get-TunnelAgents { @($TunnelAgents.Keys | Where-Object { Get-Process $_ -ErrorAction SilentlyContinue } | ForEach-Object { $TunnelAgents[$_] }) }

function Find-Playit {
  $set = [string](Get-Cfg 'playit_path' '')
  foreach ($p in @($set) + $PlayitPaths) { if ($p -and (Test-Path $p)) { return $p } }
  return ''
}

function Get-HoldFlag { Join-Path (Get-GameBin) 'HoldMatch.flag' }
function Get-HoldMinutes { $m = 10; try { $m = [int](Get-Cfg 'hold_max_minutes' 10) } catch { }; [Math]::Max(1, [Math]::Min($HoldMaxMinutes, $m)) }

function Set-HostMsg($text, $color, [switch]$Lobby) {
  $u = $script:hostUi
  $script:hostMsgLobby = [bool]$Lobby   # a how-to-join hint, cleared once the match starts
  $u.msg.Text = $text
  $u.msg.ForeColor = if ($color) { $color } else { $dim }
}

function Set-HostLine($key, $text, $colour) {
  $l = $script:hostUi.lines[$key]
  $c = Get-HostColour $colour
  if ($l.Text -ne $text) { $l.Text = $text }
  if ($l.ForeColor -ne $c) { $l.ForeColor = $c }
}

# The router job's answer, shown in the note under the address box.
function Show-RouterResult([string]$line) {
  $u = $script:hostUi
  $port = Get-HostPort
  $script:routerState = $line
  $parts = $line -split ' ', 3
  switch ($parts[0]) {
    'OK' {
      $u.netBox.Text = "$($parts[2]):$port"
      $how = if ($parts[1] -eq 'upnp') { 'UPnP' } else { 'NAT-PMP' }
      $u.netNote.Text = "Your router forwards port $port to this PC ($how) until you press Stop server. If friends still can't get in, your internet provider may block it: use a tunnel (playit.gg, Tailscale or Radmin VPN) and give them that address instead."
      $u.netNote.ForeColor = $good
    }
    'PRIVATE' {
      # 100.64/10 is the provider's shared range; any other private address means a second router
      # (usually the provider's modem) sits in front of this one.
      $cg = $parts[2] -match '^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\.'
      $u.netNote.Text = if ($cg) { "Your router opened the port, but its outside address ($($parts[2])) is shared: your internet provider puts many homes behind one address, so friends can't reach you this way. Use a tunnel (playit.gg, Tailscale or Radmin VPN), or let someone else host." }
        else { "Your router opened the port, but there is a second router in front of it (its outside address $($parts[2]) is private), usually the internet provider's modem. Put the modem in bridge mode, or forward UDP $port on it to your router, or use a tunnel (playit.gg, Tailscale or Radmin VPN)." }
      $u.netNote.ForeColor = $bad
    }
    default {
      $u.netNote.Text = "Your router didn't open the port ($((@($parts) | Select-Object -Skip 1) -join ' ')). Turn on UPnP in your router's settings, or use a tunnel (playit.gg, Tailscale or Radmin VPN). Friends in your house can still use the LAN address."
      $u.netNote.ForeColor = $bad
    }
  }
}

function Start-Router([string]$action) {
  if ($script:routerJob) { Remove-Job $script:routerJob -Force -ErrorAction SilentlyContinue }
  $script:routerJob = Start-Job -ScriptBlock $RouterScript -ArgumentList $action, (Get-HostPort), $script:hostLanIp
  $script:routerAction = $action
  $script:routerStart = Get-Date
}

# Removes the router forward this window made (waits up to 10 s for the router).
function Close-Router {
  if ($script:routerState -notmatch '^(OK|PRIVATE) ') { return }
  Start-Router 'close'
  Wait-Job $script:routerJob -Timeout 10 | Out-Null
  Remove-Job $script:routerJob -Force -ErrorAction SilentlyContinue
  $script:routerJob = $null
  $script:routerState = ''
}

function Get-HostPort { [int](Get-Cfg 'host_port' 7777) }

# Ends the game from this copy: asks its window to close (the game says goodbye to the joiners and
# finishes its log), forces it after 8 s (a host closed late in a match can otherwise hang for 60 s
# and end in an empty fatal error), and ends a crash reporter from this copy.
function Stop-HostGame {
  foreach ($p in @(Get-OurGame)) { try { [void]$p.CloseMainWindow() } catch { } }
  $end = (Get-Date).AddSeconds(8)
  while (@(Get-OurGame).Count -and (Get-Date) -lt $end) { Start-Sleep -Milliseconds 300; [Windows.Forms.Application]::DoEvents() }
  $forced = @(Get-OurGame)
  $forced | Stop-Process -Force -ErrorAction SilentlyContinue
  $dir = Get-GameDir
  Get-Process AutoReporter -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$dir\*" } | Stop-Process -Force -ErrorAction SilentlyContinue
  Remove-Item (Get-HoldFlag) -ErrorAction SilentlyContinue
  if ($forced.Count) { 'The game did not close in 8 s, so it was ended.' } else { 'Server stopped.' }
}

# Reads the new lines of the game's log. A game this launcher did not start as host (started by
# hand, or before the launcher opened) is read from the top of its log.
function Read-HostLog {
  $logFile = Get-LogFile
  if ($script:hostLogFile -ne $logFile) { $script:hostLogFile = $logFile; $script:hostPos = 0; $script:hostLog = New-HostLog }
  if (-not (Test-Path $logFile)) { return }
  try {
    $fs = [IO.File]::Open($logFile, 'Open', 'Read', 'ReadWrite')
    try {
      if ($fs.Length -lt $script:hostPos) { $script:hostPos = 0; $script:hostLog = New-HostLog -After $script:hostLog.after }
      if ($fs.Length -eq $script:hostPos) { return }
      [void]$fs.Seek($script:hostPos, 'Begin')
      $text = (New-Object IO.StreamReader($fs)).ReadToEnd()
      $script:hostPos = $fs.Length
    } finally { $fs.Close() }
    foreach ($l in ($text -split "`r?`n")) { if ($l) { Update-HostLog $script:hostLog $l } }
  } catch { }
}

# The feed's latest.json (what friends update to), fetched in the background every 5 minutes.
function Start-FeedCheck {
  $url = Get-UpdateUrl
  $script:feedAt = Get-Date
  if (-not $url) { $script:feed = @{ error = 'no update address set' }; return }
  try {
    $script:feedTask = (New-Object Net.WebClient).DownloadStringTaskAsync([Uri]"$url/latest.json?t=$([DateTime]::UtcNow.Ticks)")
  } catch { $script:feed = @{ error = $_.Exception.Message } }
}

function Update-FeedLine {
  if (((Get-Date) - $script:feedAt).TotalSeconds -gt 300) { Start-FeedCheck }
  $t = $script:feedTask
  if ($t -and $t.IsCompleted) {
    $script:feedTask = $null
    $script:feed = if ($t.IsFaulted -or $t.IsCanceled) { @{ error = "$($t.Exception.InnerException.Message)" } }
      else { try { $j = $t.Result | ConvertFrom-Json; @{ version = [string]$j.version; published = [string]$j.published } } catch { @{ error = "couldn't read latest.json" } } }
  }
  $f = $script:feed
  # Two lines: the build this launcher hosts, and the one published to friends (the feed, which
  # changes only when you publish). Both amber when they differ.
  $mine = Get-HostedVersion   # @{ label; commit; version; live }
  $sel = if ($mine.label) { $mine.label } elseif ($mine.version) { $mine.version } else { 'unknown' }
  if (-not $f) { Set-HostLine 'build' $sel 'fg'; Set-HostLine 'feed' 'checking ...' 'dim'; return }
  if ($f.error) { Set-HostLine 'build' $sel 'fg'; Set-HostLine 'feed' "can't reach the update feed" 'warn'; return }
  $same = if ($mine.commit) { $f.version.EndsWith('-' + $mine.commit) } else { $f.version -eq $mine.version }
  $c = if ($same) { 'fg' } else { 'warn' }
  Set-HostLine 'build' $sel $c
  Set-HostLine 'feed' $f.version $c
}

function Update-HostTab {
  $u = $script:hostUi
  # The router's answer to Open lobby.
  $j = $script:routerJob
  if ($j -and $script:routerAction -eq 'open') {
    if ($j.State -in 'Completed', 'Failed', 'Stopped') {
      $out = @(Receive-Job $j -ErrorAction SilentlyContinue | ForEach-Object { "$_" })
      Remove-Job $j -Force -ErrorAction SilentlyContinue
      $script:routerJob = $null
      $line = [string]($out | Where-Object { $_ -match '^(OK|PRIVATE|FAIL) ' } | Select-Object -Last 1)
      if (-not $line) { $line = 'FAIL the router check ended without an answer' }
      Show-RouterResult $line
    } elseif (((Get-Date) - $script:routerStart).TotalSeconds -gt 30) {
      Stop-Job $j -ErrorAction SilentlyContinue
      Remove-Job $j -Force -ErrorAction SilentlyContinue
      $script:routerJob = $null
      Show-RouterResult 'FAIL no router answered within 30 s'
    }
  }

  $running = @(Get-OurGame).Count -gt 0
  if ($running) { Read-HostLog }
  $hl = $script:hostLog
  # Only a game that hosts: a joined or solo game from this copy writes the same log.
  $server = if ($running -and ($script:runRole -eq 'host' -or ($script:runRole -eq '' -and $hl.port))) { $hl } else { $null }
  $flag = Get-HoldFlag
  $holding = $server -and (Test-Path $flag)
  if (-not $running) { $script:runRole = ''; if ($script:hostOpened) { $script:hostOpened = $false; Close-Router } }

  # A held match starts on its own after hold_max_minutes (counted from Open lobby, or from when
  # the hold file was made for a game started elsewhere).
  $left = $null
  if ($holding) {
    $since = if ($script:holdSince) { $script:holdSince } else { try { (Get-Item $flag).LastWriteTime } catch { Get-Date } }
    $left = (Get-HoldMinutes) * 60 - ((Get-Date) - $since).TotalSeconds
    if ($left -le 0) {
      Remove-Item $flag -ErrorAction SilentlyContinue
      Set-HostMsg "Starting the match: $(Get-HoldMinutes) min passed without Start match (setting hold_max_minutes)." $good
      $holding = $false; $left = $null
    }
  }

  if ($script:hostMsgLobby -and (-not $running -or (Test-HostStarted $hl))) { Set-HostMsg '' }

  # Status lines
  if ($script:hostStopping) { Set-HostLine 'server' 'Stopping ...' 'warn' }
  elseif ($server -and $hl.exiting) { Set-HostLine 'server' 'Shutting down. If it hangs, press Stop server to end it.' 'warn' }
  elseif ($server -and $hl.port) { Set-HostLine 'server' "Running, listening on port $($hl.port)" 'good' }
  elseif ($server -or ($running -and $script:runRole -eq 'host')) { Set-HostLine 'server' "Starting (port $(Get-HostPort)) ..." 'warn' }
  elseif ($running) { Set-HostLine 'server' 'Not hosting: the game running from this copy joined a match or plays solo.' 'dim' }
  else { Set-HostLine 'server' 'Not running' 'dim' }

  $want = [int]$u.humans.SelectedItem
  if (-not $server) { Set-HostLine 'match' '' 'dim' }
  elseif (-not (Test-HostStarted $hl)) {
    $here = @(Get-HostPresent $hl | Where-Object { $_.status -eq 'in lobby' }).Count
    $text = "Lobby: $here of $want players in"
    if ($holding -and $null -ne $left) { $text += ('. Waiting for you to press Start match (starts on its own in {0}:{1:00})' -f [int][Math]::Floor($left / 60), [int]($left % 60)) }
    elseif ($script:heldLaunch) { $text += '. Starting ...' }
    else { $text += '. Starts when all are in, or after about 60 s' }
    Set-HostLine 'match' $text $(if ($here -ge $want) { 'good' } else { 'warn' })
  } else {
    $text = if ($hl.round) { "Round $($hl.round), $(Get-HostPhase $hl)" } else { $p = Get-HostPhase $hl; $p.Substring(0, 1).ToUpper() + $p.Substring(1) }
    $humans = @(Get-HostPresent $hl | Where-Object { $_.status -eq 'playing' }).Count
    $text += "  $([char]0x00B7)  $humans human(s) connected"
    if ($hl.takeovers) { $text += "  $([char]0x00B7)  bots took over $($hl.takeovers) seat(s)" }
    Set-HostLine 'match' $text 'good'
  }
  $me = if ($server) { $hl.players['host'] } else { $null }
  $fight = if ($me) { Get-HostFight $hl $me.name } else { $null }
  if ($fight -and $hl.state -in 'Standby', 'Combat', 'Result') { Set-HostLine 'you' "Fighting on board $($fight[0]) against $($fight[1]) (round $($hl.round))" 'good' }
  elseif ($server -and (Test-HostStarted $hl) -and $hl.state -eq 'Prepare') { Set-HostLine 'you' 'On your own board (shopping)' 'dim' }
  else { Set-HostLine 'you' '' 'dim' }

  $public = $u.netBox.Text.Trim()
  $agents = @(Get-TunnelAgents)
  $lanText = if ($script:hostLanIp) { "LAN $($script:hostLanIp):$(Get-HostPort)" } else { 'no LAN address' }
  $dot = "  $([char]0x00B7)  "
  if ($public) {
    $tunnel = if ($agents.Count) { "tunnel up ($($agents -join ', '))" } elseif ($script:routerState -match '^OK ') { 'router forward' } else { 'no playit agent running, so internet players cannot reach you' }
    Set-HostLine 'net' "$public$dot$tunnel$dot$lanText" $(if ($agents.Count -or $script:routerState -match '^OK ') { 'fg' } else { 'warn' })
  } else { Set-HostLine 'net' "$lanText${dot}no internet address yet (paste your playit.gg address below)" 'dim' }
  $u.copy.Enabled = [bool]$public
  $u.tunnel.Visible = [bool]($public -and -not $agents.Count -and (Find-Playit))
  Update-FeedLine

  # Set-up rows only while no server runs; buttons by state.
  $u.setup.Visible = -not $running
  $u.open.Visible = -not $running
  $u.open.Enabled = -not $script:hostLaunching
  $u.start.Visible = [bool]$holding
  $u.stop.Enabled = $running -and -not $script:hostStopping
  $u.hint.Text = if ($script:hostLaunching) { 'Launching ...' }
    elseif (-not $running) { 'Opens the lobby with your name and leader. Friends join with the address above.' }
    elseif ($holding) { 'Start match begins with whoever is in; bots fill the other seats.' }
    else { 'Stop server closes the game for everyone.' }

  Show-HostPlayers $server
  Show-HostEvents $server
}

function Show-HostPlayers($server) {
  $u = $script:hostUi
  $rows = New-Object System.Collections.ArrayList
  $notes = @()
  if ($server) {
    foreach ($p in @(Get-HostRows $server)) {
      $status = $p.status; $colour = $HostStatusColour[$p.status]
      if ($p.status -in 'connecting', 'logging in' -and ([DateTime]::UtcNow - $p.since).TotalSeconds -gt $HostStallSeconds) { $status = "stuck $($p.status)"; $colour = 'bad' }
      elseif ($p.ghost -and $HostGone -notcontains $p.status) { $status = 'ghost (old)'; $colour = 'bad' }
      $leader = if ($p.leader) { Get-LeaderName $p.leader } elseif ($p.asked -and $p.status -in 'in lobby', 'playing') { "random ($(Get-LeaderName $p.asked) taken)" } else { '' }
      $f = Get-HostFight $server $p.name
      $fight = if ($f -and $p.status -eq 'playing') { "board $($f[0]) vs $($f[1])" } else { '' }
      $seat = Get-HostHome $server $p.name
      # Learnt the first round they fight on their own board (the log names the owner first).
      if ($null -eq $seat) { $seat = if ($p.status -eq 'playing' -and $server.round) { '?' } else { '' } }
      $name = $(if ($p.key -eq 'host') { 'you: ' } else { '' }) + $(if ($p.name) { $p.name } else { 'unknown' })
      $addr = if ($p.key -eq 'host') { '' } else { $p.key }
      [void]$rows.Add(@(@($name, $status, $leader, "$seat", $fight, $p.pc, $addr, (Get-Ago $p.since)), $colour))
      if ($p.note -and ($HostGone -notcontains $p.status -or $p.status -eq 'wrong version')) { $notes += "$(Get-HostPlayerLabel $p): $($p.note)" }
    }
  }
  $key = ($rows | ForEach-Object { ($_[0] -join '|') + '#' + $_[1] }) -join "`n"
  if ($key -ne $script:hostRowsKey) {
    $script:hostRowsKey = $key
    $u.list.BeginUpdate()
    $u.list.Items.Clear()
    foreach ($r in $rows) {
      $it = New-Object Windows.Forms.ListViewItem([string]$r[0][0])
      foreach ($v in ($r[0] | Select-Object -Skip 1)) { [void]$it.SubItems.Add([string]$v) }
      $it.ForeColor = Get-HostColour $r[1]
      [void]$u.list.Items.Add($it)
    }
    $u.list.EndUpdate()
  }
  $text = if ($notes) { $notes -join "  $([char]0x00B7)  " } elseif ($server) { 'Playit joiners show 127.x addresses. Players who leave stay listed for 10 minutes.' } else { '' }
  if ($u.note.Text -ne $text) { $u.note.Text = $text; $u.note.ForeColor = if ($notes) { $warn } else { $dim } }
}

function Show-HostEvents($server) {
  $u = $script:hostUi
  $lines = @()
  if ($server) { $lines = @($server.events | Select-Object -Last 50 | ForEach-Object { '{0:HH:mm:ss}  {1}' -f $_.time.ToLocalTime(), $_.text }) }
  [array]::Reverse($lines)
  $key = $lines -join "`n"
  if ($key -eq $script:hostEventsKey) { return }
  $script:hostEventsKey = $key
  $u.events.BeginUpdate()
  $u.events.Items.Clear()
  foreach ($l in $lines) { [void]$u.events.Items.Add($l) }
  $u.events.EndUpdate()
  Update-ListScroll $u.events
}

function Open-HostLobby {
  $u = $script:hostUi
  try {
    Assert-CanStart
    if ($script:devMode) { $why = Test-DevCanHost $u.hold.Checked; if ($why) { throw $why } }
    else {
      # Joiners must have this copy's version, so host the newest published one.
      $r = Update-FromHost
      if ($r -eq 'restarting') { return }
      if ($r -eq 'failed') { throw 'The update failed, so this copy may not match your friends. Press Update and try again.' }
      $script:hostUpdateNote = if ($r -eq 'unreachable') { " Couldn't check for updates, so make sure friends have version $(Get-Version)." } else { '' }
    }
    $name = Get-PlayerName
    $leaderId = Get-LeaderId
    $preset = Get-HostPreset
    Set-Cfg 'host_open_port' $u.upnp.Checked
    Set-Cfg 'host_address' $u.netBox.Text.Trim()
    Set-Cfg 'humans' ([int]$u.humans.SelectedItem)
    Set-Cfg 'hold_for_host' $u.hold.Checked
    Set-Cfg 'host_preset' $preset
    Save-Cfg
    $logFile = Get-LogFile
    if (Test-Path $logFile) { Move-Item $logFile ($logFile -replace '\.log$', '-previous.log') -Force -ErrorAction SilentlyContinue }
    $script:hostLogFile = $logFile
    $script:hostPos = 0
    $script:hostLog = New-HostLog -After ([DateTime]::UtcNow.AddSeconds(-5))
    $script:hostRowsKey = $null; $script:hostEventsKey = $null
    $script:routerState = ''
    if ($u.upnp.Checked -and $script:hostLanIp) {
      $u.netNote.Text = 'Asking your router to open the port ...'
      $u.netNote.ForeColor = $dim
      Start-Router 'open'
    } else {
      $addr = $u.netBox.Text.Trim()
      $u.netNote.Text = if ($addr) { "Friends outside your house join $addr. Keep your tunnel running while you host; it must forward to UDP $(Get-HostPort) on this PC." }
        else { 'No tunnel address set, so only friends in your house can join (LAN address above). Paste your playit.gg address here for others.' }
      $u.netNote.ForeColor = $dim
    }
    $a = @('-Role', 'host', '-Preset', $preset, '-Port', (Get-HostPort), '-Humans', ([int]$u.humans.SelectedItem), '-Leader', $leaderId)
    if ($name) { $a += @('-Name', $name) }
    if ($u.hold.Checked) { $a += '-HoldForHost' }
    if (-not $script:devMode) { $a += '-NoOverrides' }   # friends lack the override pak tools
    $script:hostLaunching = $true
    $script:heldLaunch = $u.hold.Checked
    $script:holdSince = if ($u.hold.Checked) { Get-Date } else { $null }
    $what = "Hosting `"$preset`" for $([int]$u.humans.SelectedItem) player(s)$(if ($u.hold.Checked) { ', holding until you press Start match' })"
    Set-HostMsg "$what ..."
    Invoke-StartPreset $a {
      param($code, $text)
      $script:hostLaunching = $false
      if ($code) { $script:holdSince = $null; Set-HostMsg "Launch failed: $((($text -split "`r?`n") | Where-Object { $_ } | Select-Object -Last 3) -join ' ')" $bad; return }
      $script:runRole = 'host'
      $script:hostOpened = $true
      $where = if ($script:hostLanIp) { "$($script:hostLanIp):$(Get-HostPort) (LAN)" } else { 'your LAN address' }
      $pub = $script:hostUi.netBox.Text.Trim()
      if ($pub) { $where += " or $pub (internet)" }
      $first = 'The first time, Windows asks whether Prophecy may use the network: click Allow.'
      $msg = if ($script:heldLaunch) { "Players join $where. The match waits until you press Start match (or $(Get-HoldMinutes) min pass). $first" }
        else { "Players have about 60 s to join $where; then the match starts with whoever is in. $first" }
      Set-HostMsg "$msg$($script:hostUpdateNote)" $good -Lobby
    }
  } catch {
    $script:hostLaunching = $false
    Set-HostMsg $_.Exception.Message $bad
  }
}

function Get-HostPreset {
  $c = $script:hostUi.preset
  if ($c -and $c.SelectedItem) { return [string]$c.SelectedItem }
  return [string](Get-Cfg 'host_preset' 'play')
}

# Developer copy: the preset list follows the Testing switch (testing presets only when it is on).
function Update-HostPresets {
  $u = $script:hostUi
  if (-not $u.preset) { return }
  $want = if ($u.testing.Checked) { 'test-host' } else { [string](Get-Cfg 'host_preset' 'play') }
  $names = @(Get-PresetChoices -ForHost -Testing:$u.testing.Checked)
  $u.preset.Items.Clear()
  foreach ($n in $names) { [void]$u.preset.Items.Add($n) }
  $i = [array]::IndexOf($names, $want)
  if ($i -lt 0) { $i = [array]::IndexOf($names, $(if ($u.testing.Checked) { 'test-host' } else { 'play' })) }
  if ($names.Count) { $u.preset.SelectedIndex = [Math]::Max(0, $i) }
}

function New-HostTab($page) {
  $script:hostLanIp = Get-LanIp
  $script:hostLog = New-HostLog
  $script:hostPos = 0
  $script:hostLogFile = ''
  $script:routerJob = $null
  $script:routerState = ''
  $script:hostOpened = @(Get-OurGame).Count -gt 0
  $script:hostStopping = $false
  $script:hostLaunching = $false
  $script:heldLaunch = $false
  $script:holdSince = $null
  $script:hostUpdateNote = ''
  $script:feed = $null; $script:feedTask = $null; $script:feedAt = [datetime]::MinValue
  $script:hostUi = @{ lines = @{} }
  $u = $script:hostUi

  $root = New-Object Windows.Forms.TableLayoutPanel
  $root.Dock = 'Fill'
  $root.ColumnCount = 1
  $root.Padding = New-Object Windows.Forms.Padding(12, 8, 12, 8)
  [void]$root.ColumnStyles.Add((New-Object Windows.Forms.ColumnStyle('Percent', 100)))
  $page.Controls.Add($root)

  # ---- server status: one line each ----
  $st = New-FormGrid 4 180
  foreach ($k in @(@('server', 'Server'), @('match', 'Match'), @('you', 'Your units'), @('net', 'Players join'), @('build', 'Currently selected build'), @('feed', 'Currently published build'))) {
    $v = New-Label '' -Wrap 600
    $u.lines[$k[0]] = $v
    $extra = @()
    if ($k[0] -eq 'net') {
      $u.copy = New-Button 'Copy' -Link
      $u.copy.Add_Click({ $a = $script:hostUi.netBox.Text.Trim(); if ($a) { [Windows.Forms.Clipboard]::SetText($a); Set-HostMsg "Copied $a" } })
      $u.tunnel = New-Button 'Start tunnel' -Link
      $u.tunnel.Add_Click({
        $p = Find-Playit
        try { if (-not $p) { throw 'playit.gg agent not found (setting playit_path)' }; Start-Process $p -WorkingDirectory (Split-Path $p); Set-HostMsg 'Started the playit.gg agent.' $good }
        catch { Set-HostMsg "Could not start the tunnel: $($_.Exception.Message)" $bad }
      })
      $extra = @($u.copy, $u.tunnel)
    }
    if ($k[0] -eq 'feed') {
      $b = New-Button 'Check now' -Link
      $b.Add_Click({ Start-FeedCheck; Set-HostLine 'feed' 'checking ...' 'dim' })
      $extra = @($b)
    }
    Add-FormRow $st $k[1] (@($v) + $extra)
  }
  Add-Stack $root $st

  # ---- set-up rows, shown while no server runs ----
  $u.setup = New-FormGrid 4
  $u.setup.Margin = New-Object Windows.Forms.Padding(0, 8, 0, 0)
  $u.netBox = New-Object Windows.Forms.TextBox
  $u.netBox.Font = New-Object Drawing.Font('Consolas', 11)
  $u.netBox.Width = 300
  $u.netBox.Text = [string](Get-Cfg 'host_address' '')
  $u.netBox.Add_Leave({ Set-Cfg 'host_address' $script:hostUi.netBox.Text.Trim(); Save-Cfg })
  Add-FormRow $u.setup 'Join address' @($u.netBox)
  $u.netNote = New-Label 'What friends outside your house type: your playit.gg or VPN address.' -Dim -Wrap 620
  Add-FormRow $u.setup '' @($u.netNote)
  # A drop-down rather than a spinner: its arrows can't be drawn dark.
  $u.humans = New-Combo
  $u.humans.DropDownStyle = 'DropDownList'; $u.humans.Width = 56
  foreach ($n in 1..8) { [void]$u.humans.Items.Add($n) }
  $u.humans.SelectedItem = [Math]::Max(1, [Math]::Min(8, [int](Get-Cfg 'humans' 2)))
  Add-FormRow $u.setup 'Players' @($u.humans, (New-Label 'humans, you included; bots fill the rest' -Dim))
  if ($script:devMode) {
    $u.preset = New-Combo
    $u.preset.DropDownStyle = 'DropDownList'; $u.preset.Width = 160
    $u.testing = New-Object Windows.Forms.CheckBox
    $u.testing.Text = 'Testing (fast rounds, no intro)'; $u.testing.AutoSize = $true
    $u.testing.Checked = [bool](Get-Cfg 'testing' $false)
    $u.testing.Add_CheckedChanged({ Set-Cfg 'testing' $script:hostUi.testing.Checked; Save-Cfg; Update-HostPresets })
    $u.presetDesc = New-Label '' -Dim -Wrap 620
    $u.preset.Add_SelectedIndexChanged({ $script:hostUi.presetDesc.Text = Get-PresetDescription (Get-HostPreset) })
    Add-FormRow $u.setup 'Preset' @($u.preset, $u.testing)
    Add-FormRow $u.setup '' @($u.presetDesc)
    Update-HostPresets
  } else {
    Add-FormRow $u.setup 'Match' @((New-Label "$([string](Get-Cfg 'host_preset' 'play')): original timers, as in a real match" -Dim))
  }
  $u.hold = New-Object Windows.Forms.CheckBox
  $u.hold.Text = 'Wait for my OK: hold the lobby until I press Start match'; $u.hold.AutoSize = $true
  $u.hold.Checked = [bool](Get-Cfg 'hold_for_host' $true)
  Add-FormRow $u.setup '' @($u.hold)
  # Experimental: kept for later (mae 2026-11-01: tunnels are the supported route for now).
  $u.upnp = New-Object Windows.Forms.CheckBox
  $u.upnp.Text = 'Experimental: ask my router to open the port instead of a tunnel'; $u.upnp.AutoSize = $true
  $u.upnp.ForeColor = $dim
  $u.upnp.Checked = [bool](Get-Cfg 'host_open_port' $false)
  Add-FormRow $u.setup '' @($u.upnp)
  Add-Stack $root $u.setup

  # ---- buttons ----
  $bar = New-Object Windows.Forms.FlowLayoutPanel
  $bar.AutoSize = $true; $bar.WrapContents = $false; $bar.Dock = 'Fill'
  $bar.Margin = New-Object Windows.Forms.Padding(0, 10, 0, 4)
  $u.open = New-Button 'Open lobby' -Primary
  $u.start = New-Button 'Start match' -Primary
  $u.stop = New-Button 'Stop server'
  $u.stop.Height = $u.open.Height
  $u.hint = New-Label '' -Dim -Wrap 300
  $u.hint.Margin = New-Object Windows.Forms.Padding(8, 10, 0, 0)
  foreach ($c in $u.open, $u.start, $u.stop, $u.hint) { $bar.Controls.Add($c) }
  Add-Stack $root $bar
  $u.msg = New-Label '' -Dim -Wrap 820
  Add-Stack $root $u.msg

  # ---- players ----
  Add-Stack $root (New-Label 'Players' -Section)
  $u.list = New-Object Windows.Forms.ListView
  $u.list.View = 'Details'
  $u.list.FullRowSelect = $true
  $u.list.HeaderStyle = 'Nonclickable'
  $u.list.Dock = 'Fill'
  $u.list.BackColor = $panel
  $u.list.ForeColor = $fg
  $u.list.Font = New-Object Drawing.Font('Segoe UI', 9.5)
  # Roomier rows (a ListView takes its row height from its image list).
  $rowSize = New-Object Windows.Forms.ImageList
  $rowSize.ImageSize = New-Object Drawing.Size(1, 26)
  $u.list.SmallImageList = $rowSize
  foreach ($c in @(@('Name', 110), @('Status', 100), @('Leader', 120), @('Board', 50), @('This round', 120), @('PC', 80), @('Address', 130), @('Changed', 70))) {
    [void]$u.list.Columns.Add($c[0], $c[1])
  }
  # The players table and the events share the room left. A dark 1 px frame around the table.
  $frame = New-Object Windows.Forms.Panel
  $frame.Dock = 'Fill'
  $frame.Padding = New-Object Windows.Forms.Padding(1)
  $frame.BackColor = [Drawing.Color]::FromArgb(14, 15, 19)
  $frame.Controls.Add($u.list)
  Add-Stack $root $frame 55
  $u.note = New-Label '' -Dim -Wrap 820
  Add-Stack $root $u.note

  # ---- what happened ----
  Add-Stack $root (New-Label 'Server events' -Section)
  $u.events = New-Object Windows.Forms.ListBox
  $u.events.Dock = 'Fill'
  $u.events.BorderStyle = 'None'
  $u.events.BackColor = [Drawing.Color]::FromArgb(21, 23, 28)
  $u.events.ForeColor = [Drawing.Color]::FromArgb(215, 218, 224)
  $u.events.Font = New-Object Drawing.Font('Consolas', 9)
  $u.events.IntegralHeight = $false
  Add-Stack $root (Add-ListScroll $u.events) 45

  $u.open.Add_Click({ Open-HostLobby })
  $u.start.Add_Click({
    $n = @(Get-HostPresent $script:hostLog | Where-Object { $_.status -in 'in lobby', 'playing' }).Count
    Remove-Item (Get-HoldFlag) -ErrorAction SilentlyContinue
    $script:holdSince = $null
    Set-HostMsg $(if ($n) { "Match starting with $n player(s); bots fill the other seats." } else { 'Match starting; bots fill the other seats.' }) $good
  })
  $u.stop.Add_Click({
    if ((Test-HostStarted $script:hostLog) -and $script:hostLog.port -and
        [Windows.Forms.MessageBox]::Show('A match is running. Stop the server? Everyone in the match is disconnected.', 'Stop server', 'YesNo', 'Question') -ne 'Yes') { return }
    $script:hostStopping = $true
    Set-HostMsg 'Stopping the server ...'
    $said = Stop-HostGame
    Close-Router
    $script:hostStopping = $false
    $script:holdSince = $null
    Set-HostMsg $said
  })
  Start-FeedCheck
}

# Asked by the main window before it closes: $false keeps it open.
function Confirm-HostClose {
  if (-not ((Get-OurGame) -and $script:runRole -eq 'host')) { Close-Router; return $true }
  $held = Test-Path (Get-HoldFlag)
  $q = if ($held) { "Your match is waiting for Start match.`n`nYes: stop the server and close.`nNo: close and leave the server running (delete $(Get-HoldFlag) to start it).`nCancel: keep the launcher open." }
    else { "You are hosting. Stop the server too? Players in your match are dropped.`n`nYes: stop it and close.  No: close and leave it running.  Cancel: keep the launcher open." }
  $a = [Windows.Forms.MessageBox]::Show($q, $form.Text, 'YesNoCancel', 'Question')
  if ($a -eq 'Cancel') { return $false }
  if ($a -eq 'Yes') { [void](Stop-HostGame); Close-Router }
  return $true
}
