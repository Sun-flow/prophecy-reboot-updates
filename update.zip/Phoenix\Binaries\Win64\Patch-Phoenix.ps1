# Applies the player-side exe patches (client-patches.json, exported from
# research\prophecy\dev-copy\patches\phoenix_patches.py export-client) to a friend's Phoenix.exe.
# Friends have no Python, so this is the PowerShell twin of "phoenix_patches.py apply" for the
# patches every player needs (CLIENT_SET: shop-six, rts-cam, all-boards, minimap).
#
#   Patch-Phoenix.ps1                         # Phoenix.exe and client-patches.json next to this script
#   Patch-Phoenix.ps1 -Exe <path> -Json <path>
#
# Safe to run before every launch: each patch is applied only if every site still has its original
# bytes, skipped if already applied, and left alone (with a warning) if the exe has something else
# there. An earlier version of a patch (listed under "old_versions") is put back to the original
# bytes and replaced by the current one ("upgraded from ..."). A patch listed under "requires" is
# only applied when that file is in the game copy (else a "MISSING" line). The first change saves
# Phoenix.orig.exe next to the exe. Prints one line per patch.
# Needs only Windows PowerShell 5.1.
param(
  [string]$Exe = '',
  [string]$Json = ''
)
$ErrorActionPreference = 'Stop'
if (-not $Exe) { $Exe = Join-Path $PSScriptRoot 'Phoenix.exe' }
if (-not $Json) { $Json = Join-Path $PSScriptRoot 'client-patches.json' }
if (-not (Test-Path $Json)) { 'No client-patches.json; nothing to patch.'; return }
if (-not (Test-Path $Exe)) { throw "Phoenix.exe not found at $Exe" }
$spec = Get-Content $Json -Raw | ConvertFrom-Json
$data = [IO.File]::ReadAllBytes($Exe)
# Every site's original bytes are checked below, which is the real version check: a different
# Phoenix.exe build fails it and is left alone. Patches made for build $spec.exe_version.

function Get-Hex([string]$hex) {
  $b = New-Object byte[] ($hex.Length / 2)
  for ($i = 0; $i -lt $b.Length; $i++) { $b[$i] = [Convert]::ToByte($hex.Substring(2 * $i, 2), 16) }
  return ,$b
}

$pe = [BitConverter]::ToInt32($data, 0x3C)

# Patches too big for the exe's padding live in an extra section (code_section in the json):
# append it, int3-filled, if a patch needs it and it isn't there yet (add_code_section in
# phoenix_patches.py does the same). Changes are written below only if a patch applies.
$cs = $spec.code_section
$addedSection = $false
if ($cs) {
  $csRva = [long]$cs.rva
  $needs = @($spec.patches.PSObject.Properties | ForEach-Object { $_.Value } | Where-Object {
    $r = [Convert]::ToInt64($_.rva, 16); $r -ge $csRva -and $r -lt $csRva + [long]$cs.size })
  $n = [BitConverter]::ToUInt16($data, $pe + 6)
  $osz = [BitConverter]::ToUInt16($data, $pe + 20)
  $have = $false
  $haveIdx = -1
  for ($i = 0; $i -lt $n; $i++) { if ([BitConverter]::ToUInt32($data, $pe + 24 + $osz + $i * 40 + 12) -eq $csRva) { $have = $true; $haveIdx = $i } }
  # An older, smaller section (0x1000 before the minimap) as the last section: grow it in place.
  if ($needs.Count -and $have -and $haveIdx -eq $n - 1) {
    $o = $pe + 24 + $osz + $haveIdx * 40
    $rsz = [long][BitConverter]::ToUInt32($data, $o + 16)
    $rptr = [long][BitConverter]::ToUInt32($data, $o + 20)
    if ($rsz -lt [long]$cs.size) {
      $grown = New-Object byte[] ($rptr + [long]$cs.size)
      [Array]::Copy($data, $grown, $rptr + $rsz)
      for ($i = $rptr + $rsz; $i -lt $grown.Length; $i++) { $grown[$i] = 0xCC }
      foreach ($f in 8, 16) { [Array]::Copy([BitConverter]::GetBytes([uint32]$cs.size), 0, $grown, $o + $f, 4) }
      [Array]::Copy([BitConverter]::GetBytes([uint32]($csRva + [long]$cs.size)), 0, $grown, $pe + 24 + 56, 4)
      $data = $grown
      $addedSection = $true
    }
  }
  if ($needs.Count -and -not $have) {
    if ([BitConverter]::ToUInt32($data, $pe + 24 + 56) -ne $csRva) { throw 'This Phoenix.exe is not the build these patches are for (image size differs).' }
    $hdr = $pe + 24 + $osz + $n * 40
    $falign = [BitConverter]::ToUInt32($data, $pe + 24 + 36)
    $raw = [long]([Math]::Ceiling($data.Length / $falign) * $falign)
    $grown = New-Object byte[] ($raw + [long]$cs.size)
    [Array]::Copy($data, $grown, $data.Length)
    for ($i = $raw; $i -lt $grown.Length; $i++) { $grown[$i] = 0xCC }
    $nameBytes = [Text.Encoding]::ASCII.GetBytes($cs.name)
    [Array]::Copy($nameBytes, 0, $grown, $hdr, $nameBytes.Length)
    $fields = @([uint32]$cs.size, [uint32]$csRva, [uint32]$cs.size, [uint32]$raw)
    for ($i = 0; $i -lt 4; $i++) { [Array]::Copy([BitConverter]::GetBytes($fields[$i]), 0, $grown, $hdr + 8 + 4 * $i, 4) }
    [Array]::Copy([BitConverter]::GetBytes([uint32]$cs.chars), 0, $grown, $hdr + 36, 4)
    [Array]::Copy([BitConverter]::GetBytes([uint16]($n + 1)), 0, $grown, $pe + 6, 2)
    [Array]::Copy([BitConverter]::GetBytes([uint32]($csRva + [long]$cs.size)), 0, $grown, $pe + 24 + 56, 4)
    $data = $grown
    $addedSection = $true
  }
}

# PE section table: rva -> file offset (same as rva2off in phoenix_patches.py).
$nsec = [BitConverter]::ToUInt16($data, $pe + 6)
$optsz = [BitConverter]::ToUInt16($data, $pe + 20)
$sections = for ($i = 0; $i -lt $nsec; $i++) {
  $o = $pe + 24 + $optsz + $i * 40
  [pscustomobject]@{ va = [BitConverter]::ToUInt32($data, $o + 12); rawsize = [BitConverter]::ToUInt32($data, $o + 16); raw = [BitConverter]::ToUInt32($data, $o + 20) }
}
function Get-Offset([long]$rva) {
  foreach ($s in $sections) { if ($rva -ge $s.va -and $rva -lt $s.va + $s.rawsize) { return [long]($s.raw + $rva - $s.va) } }
  throw ('rva 0x{0:x} is not in any section' -f $rva)
}
function Test-Bytes([long]$off, [byte[]]$want) {
  for ($i = 0; $i -lt $want.Length; $i++) { if ($data[$off + $i] -ne $want[$i]) { return $false } }
  return $true
}

$changed = $addedSection
foreach ($p in $spec.patches.PSObject.Properties) {
  # Some patches need a file in the game copy too (shop-six: the shop-screen pak). Without it the
  # patch stays off, and the line starting "MISSING" tells the join window to say so.
  $need = if ($spec.requires) { $spec.requires.($p.Name) } else { $null }
  if ($need -and -not (Test-Path (Join-Path (Split-Path $Exe) $need))) {
    "MISSING $($p.Name): needs $(Split-Path $need -Leaf); left off"
    continue
  }
  $sites = foreach ($site in $p.Value) {
    [pscustomobject]@{ off = Get-Offset ([Convert]::ToInt64($site.rva, 16)); orig = (Get-Hex $site.orig); new = (Get-Hex $site.new) }
  }
  $isNew = @($sites | Where-Object { Test-Bytes $_.off $_.new }).Count
  if ($isNew -eq $sites.Count) { "$($p.Name): already applied"; continue }
  # An earlier version fully in place: undo it in memory (written only together with the new one).
  $undo = $null
  $from = ''
  $olds = if ($spec.old_versions) { $spec.old_versions.($p.Name) } else { $null }
  if ($olds) {
    foreach ($v in $olds.PSObject.Properties) {
      $vs = foreach ($site in $v.Value) {
        [pscustomobject]@{ off = Get-Offset ([Convert]::ToInt64($site.rva, 16)); orig = (Get-Hex $site.orig); new = (Get-Hex $site.new) }
      }
      if (@($vs | Where-Object { Test-Bytes $_.off $_.new }).Count -eq @($vs).Count) { $undo = $vs; $from = $v.Name; break }
    }
  }
  $keep = $null
  if ($undo) {
    $keep = $data.Clone()
    foreach ($s in $undo) { [Array]::Copy($s.orig, 0, $data, $s.off, $s.orig.Length) }
  }
  $isOrig = @($sites | Where-Object { Test-Bytes $_.off $_.orig }).Count
  if ($isOrig -ne $sites.Count) {
    if ($keep) { $data = $keep }
    Write-Warning "$($p.Name): this Phoenix.exe has unexpected bytes there; left alone"
    continue
  }
  foreach ($s in $sites) { [Array]::Copy($s.new, 0, $data, $s.off, $s.new.Length) }
  if ($from) { "$($p.Name): upgraded from $from" } else { "$($p.Name): applied" }
  $changed = $true
}

if ($changed) {
  $backup = Join-Path (Split-Path $Exe) 'Phoenix.orig.exe'
  if (-not (Test-Path $backup)) { Copy-Item $Exe $backup; "backup: $backup" }
  $tmp = "$Exe.tmp"
  try {
    [IO.File]::WriteAllBytes($tmp, $data)
    Move-Item $tmp $Exe -Force
  } catch {
    Remove-Item $tmp -ErrorAction SilentlyContinue
    throw "Couldn't update Phoenix.exe (is the game still running?): $($_.Exception.Message)"
  }
}
