# Game-mode presets

A preset is a small JSON file in this folder that names one way to play: mode, map, bots,
timers and rules. `..\Start-Preset.ps1` turns a preset into the dev copy's `Engine.ini` and
`Game.ini`, then launches the game. Copy any preset to make a new one.

```powershell
.\Start-Preset.ps1 -List                                  # what's available
.\Start-Preset.ps1 -Preset test-solo                      # TESTING: solo, you + bots
.\Start-Preset.ps1 -Preset test-host -Role host           # TESTING: listen server (port 7777)
.\Start-Preset.ps1 -Preset test-join -Role client -Connect 192.168.1.20:7777 -Dev C:\...\Prophecy-Dev2
.\Start-Preset.ps1 -Preset play -Role host                # real game with friends
.\Start-Preset.ps1 -Preset test-solo -DryRun              # show the ini and pak it would set
```

Every run prints the preset, whether it is a TESTING or normal run, each phase timer (marked
`(original)` where the preset leaves it alone) and the intro and sudden-death values the copy will
play with, so a test log always says what it ran with.

## Testing presets: use them for every test run

Every kind of run has a testing version with accelerated rounds and combat and no intro. Test runs
use these; real games use the normal ones. In the launcher, tick **Testing** on the Play screen.

| Run | Testing preset | Normal preset | Notes |
|---|---|---|---|
| Solo vs bots (launcher Solo) | `test-solo` | `standard` | |
| Host / multiplayer (launcher Host) | `test-host` | `play` | Needs the patched host exe. `humans: 2`. |
| Join (launcher Join, `-Role client`) | `test-join` | (any) | A joiner's phases, intro and combat all come from the host, so `test-join` only labels the run. **The host must run `test-host`** for the test to be fast. `-Role client` with `test-join` prints that reminder. |
| Friend bundle, Play alone | `test-solo` ("Quick match vs 7 bots") | `standard` | Friends' copies have no override tools, so the intro still plays there. |

What the testing presets change, against the original match:

| | Original | `test-*` | Why not lower |
|---|---|---|---|
| Intro | 45 s (30 s in `play`) | 1 s | Override pak `IntroductionFailSafeTime`, verified 1 s. |
| `InitialDuration` | 30 s | 3 s | |
| `LeaderSpawnDelay` | 3.75 s | 0.5 s | Verified at 0.5 in the old `fast-test`. |
| `PrepareTransitionDuration` | 2.5 s | 0.5 s | Verified. |
| `PrepareDuration` | 30 s | 8 s | Long enough to buy and place one unit. Later rounds add time on top. |
| `StandbyDuration` | 3.5 s | **3.5 s** | Must stay 3.5: at 1 s combat ends after 1 s every round. |
| Sudden death (`CombatLightningDuration`) | 20 s | 10 s | Override pak. Shortens long fights; **not yet checked in a game**. |
| `CombatDuration` | native | native | Not set until someone checks what a short value does to a fight. |
| `ResultDuration` | 1 s | 1 s | Already short. |

The number of rounds in a match isn't configurable; per the testing rule a test stops after one round.

The old names still work: `fast-test` runs `test-solo` and `lan-host` runs `test-host` (Start-Preset
prints the new name), so saved launcher and friend settings keep working.

## Every preset

| Preset | Kind | Mode | Players | Initial | Prepare | Transition | Standby | Result | Leader spawn | Intro | Sudden death | What it's for |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| `test-solo` | TESTING | match | you + 7 bots | 3 | 8 | 0.5 | 3.5 | 1 | 0.5 | 1 | 10 | Fast solo test run. |
| `test-host` | TESTING | match | 2 humans + bots | 3 | 8 | 0.5 | 3.5 | 1 | 0.5 | 1 | 10 | Fast multiplayer test run (host). |
| `test-join` | TESTING | (host's) | (host's) | host | host | host | host | host | host | host | host | Joiner side of a test run. |
| `play` | normal | match | 2 humans + bots | 30 | 30 | 2.5 | 3.5 | 1 | 3.75 | 30 | 20 | Real games with friends. |
| `standard` | normal | match | you + 7 bots | 30 | 30 | 2.5 | 3.5 | 1 | 3.75 | 45 | 20 | Real solo game, original everything. |
| `duel` | normal | match | you + 1 bot (game fills 7) | 30 | 30 | 2.5 | 3.5 | 1 | 3.75 | copy's | copy's | One-on-one. |
| `rich-start` | normal | match | you + 7 bots | 30 | 30 | 2.5 | 3.5 | 1 | 3.75 | copy's | copy's | Rules example: more gold, bigger trait pool. |
| `practice` | normal | practice | you | n/a | n/a | n/a | n/a | n/a | n/a | n/a | n/a | Team Builder sandbox. |

Seconds throughout. "copy's" = the preset has no `overrides`, so it plays with whatever the copy's
override pak has (the launcher's Intro setting).

The script only replaces the sections it owns, so other settings the game writes stay. Game
settings are written under both the native class section and the Blueprint class section.

## Verified on the PC (2026-10-29, Windows PowerShell 5.1)

- `-List`, `-DryRun` for every preset, and `-Role client` all work on Windows PowerShell 5.1.
- **Keep `StandbyDuration` at 3.5.** At 1 s, combat ends after 1 s every round: the opponent side of each fight is still empty when Combat starts. Restored to 3.5 in `fast-test` and `lan-host` on 2026-10-29, and combat then ran ~15 s with fights resolving.
- `fast-test` (now `test-solo`) timers take effect (host log timestamps): Prepare 30 s became 10 s, Standby 3.5 s became 1 s,
  the Transition back to Prepare 2.5 s became 0.5 s, and Result stays 1 s. Round 2's Prepare ran 15 s, so later rounds seem to add time.
  Intros still take about 45 s.
- **`bots` / `MaxAIPlayers` is ignored.** With `MaxAIPlayers=0` in Game.ini, and with `?NumBots=0?MaxAIPlayers=0`
  on the URL, the host still creates 7 AI at WaitingToStart, before anyone can join. So `lan-host`'s (now `test-host`)
  "5 bots leave seats for humans" doesn't hold yet: a joiner becomes a 9th seat with no board
  ([listen-test run 3](../../listen-test/run3/README.md)).
- `rules` (`GlobalGameRules`) has not been checked in-game yet.

## Fields

| Field | Values | Meaning |
|---|---|---|
| `description` | text | One line shown by `-List`. |
| `mode` | `match` (default), `practice`, `testing` | `match` = the real 8-player autobattler. `practice` = the Team Builder sandbox with scripted encounters. `testing` = match rules with help mode. |
| `map` | `streamed8` (default), `dragon`, `greek`, `themis`, `preview` | Battleground. All are cooked into the pak. |
| `bots` | 0-7 | Bot opponents (`MaxAIPlayers`). Leave seats free for humans when hosting. |
| `humans` | 1-8 | Host only: how many humans (host included) the host waits for before the match starts (`-Humans=N`). Needs the patched host exe (`patches/phoenix_patches.py`, `humans-arg`); a stock exe ignores it. Bots then fill the remaining seats. Default 1. `Start-Preset.ps1 -Humans N` overrides it. |
| `oneOnOne` | `true`/`false` | Duel mode (`bIsOneOnOne`). Defaults to true when `bots` is 0 or 1. |
| `timers` | object of seconds | Phase lengths, see below. Leave out any you don't want to change. |
| `rules` | object | Match economy and pool rules, see below. |
| `testing` | `true`/`false` | Marks a testing preset. The launcher's Testing switch shows these; Start-Preset labels the run TESTING. |
| `role` | `client` | The preset is only for that role (`test-join`). Start-Preset refuses it for another role. |
| `overrides` | `{ "intro": s, "lightning": s }` | Values baked into the override pak, see below. Host and solo only. |
| `defaultLeaderId` | leader id | Writes `DefaultLeaderId`. **Probably has no effect:** the native leader setup never reads it (only a Blueprint getter does), and offline players get a random leader. To choose a leader, use the launcher's Leaders screen or `Start-Preset.ps1 -Leader <UnitId>` with the host's `leader-pick` patch ([leader select](../../../../docs/server/leader-select.md)). |

### Timers (`timers`)

These are all config-backed on the game mode (checked in the exe's reflection data), so they
take effect from `Game.ini`. Original values are for `match`.

| Name | Original | What it controls |
|---|---|---|
| `InitialDuration` | 30 | Wait before the first round. |
| `LeaderSpawnDelay` | 3.75 | Delay before leaders appear. |
| `PrepareTransitionDuration` | 2.5 | Transition into the shopping phase. |
| `PrepareDuration` | 30 | Shopping and placement phase. |
| `StandbyDuration` | 3.5 | Pause between shopping and combat. |
| `CombatDuration` | (native default) | Combat time before overtime. Lightning (sudden death) begins at 20 s. |
| `ResultDuration` | 1 | Round result screen. |

**Not settable in Game.ini:** the intro sequence at match start (about 45 s) and when sudden
death starts. `IntroductionFailSafeTime` and `CombatLightningDuration` are Blueprint defaults, not
config properties, so they go through `overrides` instead.

### Override pak (`overrides`)

| Name | Original | What it controls |
|---|---|---|
| `intro` | 45 | Longest the intro may run (`IntroductionFailSafeTime`). 1 skips it. |
| `lightning` | 20 | Combat seconds before sudden death (`CombatLightningDuration`). |

When a host or solo launch's preset has `overrides` and the copy's pak was built with other values,
Start-Preset rebuilds it with [`../overrides/Build-OverridePak.ps1`](../overrides/README.md) first
(needs `local\tools`, the game must be closed; takes a little while). Intro 45 with lightning 20 just
switches the pak off. `-NoOverrides` skips this. The pak only exists on the copy that runs the match,
so joiners never need it. Presets without `overrides` leave the pak as it is.

### Rules (`rules`)

Each rule takes a number (sets the value and enables the rule), `true`/`false` (switches it on
or off at its original value), or `{ "enabled": ..., "value": ... }`.

| Rule | Original (match) | Meaning |
|---|---|---|
| `StartGold` | 1 | Gold at the start of the match. |
| `VictoryGold` | off, 1 | Bonus gold for winning a round. |
| `MinRoundGold` | 1 | Lowest per-round income. |
| `MaxRoundGold` | 5 | Highest per-round income. |
| `EnableReroll` | 1 | Whether shop rerolls are allowed. |
| `ItemTypes` | 40 | Distinct items in the match pool (practice: all). |
| `ItemCount` | 4 | Copies of each item. |
| `TraitTypes` | 16 | Distinct traits drawn into this match's pool (practice: all). |
| `TraitCount` | 10 | Copies of each trait in the pool. |
| `AILevelUpCostThreshold` | 100 | Bot levelling behaviour. |

## Presets included

See [Every preset](#every-preset) above.
