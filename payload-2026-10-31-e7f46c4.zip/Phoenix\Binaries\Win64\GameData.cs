// Reads the leader and trait data and the trait icons straight from the game's own pak files, so
// the friend bundle and its public updates never have to carry game text or art (mae, 2026-10-30).
//
// Compiled at run time by Windows PowerShell 5.1 (Add-Type), so it is plain C# 5: no string
// interpolation, no ?. or => members, no LINQ. Extract-GameData.ps1 loads it; the join window calls
// that. What it reads, and why each format detail is what it is: friend\README.md, "Game data".
//
// Pieces, in order:
//   Pak         UE 4.22 pak index (v8, also v3-v7), zlib blocks, a merged view over several paks
//   Package     .uasset summary (names, imports, exports) + the main export's tagged properties
//   Locres      the English text table (for leader skills, which no table links to a leader)
//   Texture     cooked Texture2D -> Bitmap (B8G8R8A8, G8, DXT1/3/5)
//   Extractor   builds leaders.json, traits.json and trait-icons\*.png like launcher\tools does
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;

namespace ProphecyData
{
    // ---- little-endian reader over a byte array --------------------------------------------------

    public class Reader
    {
        public byte[] B;
        public int P;
        public Reader(byte[] b, int p) { B = b; P = p; }
        public byte U8() { return B[P++]; }
        public sbyte I8() { return (sbyte)B[P++]; }
        public short I16() { short v = BitConverter.ToInt16(B, P); P += 2; return v; }
        public int I32() { int v = BitConverter.ToInt32(B, P); P += 4; return v; }
        public uint U32() { uint v = BitConverter.ToUInt32(B, P); P += 4; return v; }
        public long I64() { long v = BitConverter.ToInt64(B, P); P += 8; return v; }
        public float F32() { float v = BitConverter.ToSingle(B, P); P += 4; return v; }
        public double F64() { double v = BitConverter.ToDouble(B, P); P += 8; return v; }
        public byte[] Bytes(int n) { byte[] r = new byte[n]; Buffer.BlockCopy(B, P, r, 0, n); P += n; return r; }
        public void Skip(int n) { P += n; }

        // FString: int32 length incl. terminator; negative = UTF-16 code units.
        public string FString()
        {
            int n = I32();
            if (n == 0) return "";
            if (n < 0)
            {
                if (n < -1000000) throw new InvalidDataException("bad FString length " + n + " at " + (P - 4));
                string s = Encoding.Unicode.GetString(B, P, -2 * n);
                P += -2 * n;
                return s.TrimEnd('\0');
            }
            if (n > 1000000 || P + n > B.Length) throw new InvalidDataException("bad FString length " + n + " at " + (P - 4));
            string a = Encoding.UTF8.GetString(B, P, n);
            P += n;
            return a.TrimEnd('\0');
        }
    }

    // ---- pak files ---------------------------------------------------------------------------------

    public class PakEntry
    {
        public string PakPath;
        public long Offset, Size, UncompressedSize;
        public int Method;            // 0 = none, else index+1 into the pak's method names (zlib here)
        public long[] BlockStart, BlockEnd;
        public int HeaderSize;        // the copy of this record that precedes the data in the pak
    }

    public class Pak
    {
        const uint Magic = 0x5A6F12E1;
        public Dictionary<string, PakEntry> Entries = new Dictionary<string, PakEntry>(StringComparer.OrdinalIgnoreCase);
        public List<string> Log = new List<string>();

        // Later paks win, so pass the base pak first and patch paks (*_P.pak) after it.
        public void Open(string path)
        {
            using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                int tailLen = (int)Math.Min(fs.Length, 2048);
                byte[] tail = new byte[tailLen];
                fs.Seek(fs.Length - tailLen, SeekOrigin.Begin);
                ReadFull(fs, tail);
                int m = -1;
                for (int i = tailLen - 4; i >= 0; i--)
                    if (BitConverter.ToUInt32(tail, i) == Magic) { m = i; break; }
                if (m < 0) throw new InvalidDataException(path + ": no pak footer");
                Reader t = new Reader(tail, m + 4);
                int version = t.I32();
                long indexOffset = t.I64();
                long indexSize = t.I64();
                if (m >= 1 && tail[m - 1] != 0) throw new InvalidDataException(path + ": the pak index is encrypted");
                byte[] index = new byte[indexSize];
                fs.Seek(indexOffset, SeekOrigin.Begin);
                ReadFull(fs, index);
                // 4.22 writes the v8 compression index as one byte, 4.23+ as four; try both and keep
                // the reading that uses up the index exactly.
                Dictionary<string, PakEntry> got = null;
                Exception last = null;
                foreach (int methodBytes in new int[] { 1, 4 })
                {
                    try { got = ReadIndex(path, index, version, methodBytes); break; }
                    catch (Exception e) { last = e; }
                }
                if (got == null) throw new InvalidDataException(path + ": can't read the pak index (v" + version + "): " + last.Message);
                foreach (KeyValuePair<string, PakEntry> kv in got) Entries[kv.Key] = kv.Value;
                Log.Add(Path.GetFileName(path) + ": pak v" + version + ", " + got.Count + " files");
            }
        }

        static Dictionary<string, PakEntry> ReadIndex(string pak, byte[] index, int version, int methodBytes)
        {
            Reader r = new Reader(index, 0);
            string mount = r.FString();
            int count = r.I32();
            if (count < 0 || count > 10000000) throw new InvalidDataException("bad entry count " + count);
            while (mount.StartsWith("../")) mount = mount.Substring(3);
            Dictionary<string, PakEntry> d = new Dictionary<string, PakEntry>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < count; i++)
            {
                string name = r.FString();
                int start = r.P;
                PakEntry e = new PakEntry();
                e.PakPath = pak;
                e.Offset = r.I64();
                e.Size = r.I64();
                e.UncompressedSize = r.I64();
                if (version >= 8) e.Method = methodBytes == 1 ? r.U8() : (int)r.U32();
                else e.Method = r.I32();
                if (version <= 1) r.Skip(8);       // timestamp
                r.Skip(20);                        // SHA1
                if (version >= 3)
                {
                    if (e.Method != 0)
                    {
                        int n = r.I32();
                        if (n < 0 || n > 1000000) throw new InvalidDataException("bad block count " + n);
                        e.BlockStart = new long[n];
                        e.BlockEnd = new long[n];
                        for (int b = 0; b < n; b++) { e.BlockStart[b] = r.I64(); e.BlockEnd[b] = r.I64(); }
                    }
                    if (r.U8() != 0) throw new InvalidDataException(name + " is encrypted");
                    r.Skip(4);                     // compression block size
                }
                e.HeaderSize = r.P - start;
                if (e.Offset < 0 || e.Size < 0 || e.UncompressedSize < 0) throw new InvalidDataException("bad entry " + name);
                d[(mount + name).Replace('\\', '/')] = e;
            }
            if (r.P != index.Length) throw new InvalidDataException("index read " + r.P + " of " + index.Length + " bytes");
            return d;
        }

        public bool Has(string path) { return Entries.ContainsKey(path); }

        public byte[] Read(string path)
        {
            PakEntry e;
            if (!Entries.TryGetValue(path, out e)) return null;
            using (FileStream fs = new FileStream(e.PakPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                if (e.Method == 0)
                {
                    byte[] raw = new byte[e.Size];
                    fs.Seek(e.Offset + e.HeaderSize, SeekOrigin.Begin);
                    ReadFull(fs, raw);
                    return raw;
                }
                MemoryStream outp = new MemoryStream((int)e.UncompressedSize);
                for (int b = 0; b < e.BlockStart.Length; b++)
                {
                    // Block offsets count from the entry's record (v5+); older paks use absolute ones.
                    long s = e.BlockStart[b] < e.Offset ? e.Offset + e.BlockStart[b] : e.BlockStart[b];
                    byte[] blk = new byte[e.BlockEnd[b] - e.BlockStart[b]];
                    fs.Seek(s, SeekOrigin.Begin);
                    ReadFull(fs, blk);
                    // zlib = 2-byte header + raw deflate + checksum; DeflateStream wants the deflate part.
                    using (DeflateStream z = new DeflateStream(new MemoryStream(blk, 2, blk.Length - 2), CompressionMode.Decompress))
                        z.CopyTo(outp);
                }
                return outp.ToArray();
            }
        }

        static void ReadFull(Stream s, byte[] buf)
        {
            int got = 0;
            while (got < buf.Length)
            {
                int n = s.Read(buf, got, buf.Length - got);
                if (n <= 0) throw new EndOfStreamException();
                got += n;
            }
        }
    }

    // ---- cooked packages (.uasset + .uexp) -------------------------------------------------------

    public class Import { public string ClassName, ObjectName; public int Outer; }

    public class Package
    {
        public string[] Names;
        public Import[] Imports;
        public byte[] Exp;            // .uexp
        public int HeaderSize;        // .uasset length; export offsets count from its start
        public string Name;
        public long MainOffset, MainSize;

        public Package(byte[] uasset, byte[] uexp, string name)
        {
            Exp = uexp;
            Name = name;
            HeaderSize = uasset.Length;
            Reader r = new Reader(uasset, 0);
            if (r.U32() != 0x9E2A83C1) throw new InvalidDataException(name + ": not a package");
            int legacy = r.I32();
            if (legacy != -4) r.I32();     // LegacyUE3Version
            r.I32(); r.I32();               // FileVersionUE4, licensee
            if (legacy <= -2)
            {
                int n = r.I32();
                r.Skip(n * 20);             // custom versions: GUID + int
            }
            r.I32();                        // TotalHeaderSize
            r.FString();                    // FolderName
            r.U32();                        // PackageFlags
            int nameCount = r.I32(), nameOffset = r.I32();
            r.I32(); r.I32();               // gatherable text
            int exportCount = r.I32(), exportOffset = r.I32();
            int importCount = r.I32(), importOffset = r.I32();

            Names = new string[nameCount];
            Reader nr = new Reader(uasset, nameOffset);
            for (int i = 0; i < nameCount; i++) { Names[i] = nr.FString(); nr.Skip(4); }   // + two name hashes

            Imports = new Import[importCount];
            Reader ir = new Reader(uasset, importOffset);
            for (int i = 0; i < importCount; i++)
            {
                Import im = new Import();
                ReadName(ir);               // class package
                im.ClassName = ReadName(ir);
                im.Outer = ir.I32();
                im.ObjectName = ReadName(ir);
                Imports[i] = im;
            }

            // Export records are 104 bytes in 4.22; the main export is the one named like the file
            // (else the biggest).
            long bestSize = -1;
            for (int i = 0; i < exportCount; i++)
            {
                Reader er = new Reader(uasset, exportOffset + i * 104);
                er.Skip(16);                // class, super, template, outer
                string objName = ReadName(er);
                er.Skip(4);                 // object flags
                long size = er.I64(), offset = er.I64();
                if (string.Equals(objName, name, StringComparison.OrdinalIgnoreCase))
                { MainOffset = offset; MainSize = size; break; }
                if (size > bestSize) { MainOffset = offset; MainSize = size; bestSize = size; }
            }
            if (MainOffset - HeaderSize < 0 || MainOffset - HeaderSize > Exp.Length)
                throw new InvalidDataException(name + ": export offset " + MainOffset + " outside .uexp");
        }

        public string ReadName(Reader r)
        {
            int i = r.I32(), num = r.I32();
            if (i < 0 || i >= Names.Length) throw new InvalidDataException(Name + ": name index " + i + " at " + (r.P - 8));
            return num > 0 ? Names[i] + "_" + (num - 1) : Names[i];
        }

        // ObjectProperty value -> "/Game/.../Asset" for an import inside another package, else its name.
        public string ObjectPath(int index)
        {
            if (index >= 0 || -index - 1 >= Imports.Length) return null;
            Import im = Imports[-index - 1];
            if (im.Outer < 0 && -im.Outer - 1 < Imports.Length)
            {
                Import outer = Imports[-im.Outer - 1];
                if (outer.ClassName == "Package") return outer.ObjectName;
            }
            return im.ObjectName;
        }

        public Reader MainReader() { return new Reader(Exp, (int)(MainOffset - HeaderSize)); }

        // The main export's own properties.
        public Dictionary<string, object> Properties(out Reader after)
        {
            Reader r = MainReader();
            Dictionary<string, object> props = Props.ReadTagged(this, r, Exp.Length);
            after = r;
            return props;
        }

        // A DataTable: row name -> row properties.
        public Dictionary<string, Dictionary<string, object>> Rows()
        {
            Reader r;
            Properties(out r);
            if (r.I32() != 0) r.Skip(16);   // UObject: has-GUID flag (+ GUID)
            int n = r.I32();
            if (n < 0 || n > 100000) throw new InvalidDataException(Name + ": bad row count " + n);
            Dictionary<string, Dictionary<string, object>> rows = new Dictionary<string, Dictionary<string, object>>();
            for (int i = 0; i < n; i++)
            {
                string key = ReadName(r);
                rows[key] = Props.ReadTagged(this, r, Exp.Length);
            }
            return rows;
        }
    }

    // Tagged property values as plain objects: Dictionary for structs, List for arrays, string for
    // names, strings and text (the English source string), int/long/float/bool for numbers, a List
    // of {Key, Value} dictionaries for maps, null for anything this reader skips.
    public static class Props
    {
        public static Dictionary<string, object> ReadTagged(Package pkg, Reader r, int limit)
        {
            Dictionary<string, object> d = new Dictionary<string, object>();
            while (true)
            {
                string name = pkg.ReadName(r);
                if (name == "None") return d;
                string type = pkg.ReadName(r);
                int size = r.I32();
                int arrayIndex = r.I32();
                string structName = null, inner = null, valueType = null;
                bool boolVal = false;
                if (type == "StructProperty") { structName = pkg.ReadName(r); r.Skip(16); }
                else if (type == "BoolProperty") boolVal = r.U8() != 0;
                else if (type == "ByteProperty" || type == "EnumProperty") pkg.ReadName(r);
                else if (type == "ArrayProperty" || type == "SetProperty") inner = pkg.ReadName(r);
                else if (type == "MapProperty") { inner = pkg.ReadName(r); valueType = pkg.ReadName(r); }
                if (r.U8() != 0) r.Skip(16);   // property GUID
                int start = r.P;
                if (size < 0 || start + size > limit) throw new InvalidDataException(pkg.Name + ": property " + name + " size " + size + " at " + start);
                object v = null;
                try
                {
                    if (type == "BoolProperty") v = boolVal;
                    else if (type == "StructProperty") v = ReadStruct(pkg, r, structName, start + size);
                    else if (type == "ArrayProperty" || type == "SetProperty") v = ReadArray(pkg, r, inner, start + size, type == "SetProperty");
                    else if (type == "MapProperty") v = ReadMap(pkg, r, inner, valueType, start + size);
                    else if (type == "ByteProperty") v = size == 1 ? (object)(int)r.U8() : pkg.ReadName(r);
                    else v = ReadValue(pkg, r, type, size);
                }
                catch (Exception) { v = null; }
                r.P = start + size;
                if (arrayIndex > 0) name = name + "[" + arrayIndex + "]";
                d[name] = v;
            }
        }

        // One value of a simple type (also used for array, set and map elements).
        public static object ReadValue(Package pkg, Reader r, string type, int size)
        {
            switch (type)
            {
                case "IntProperty": return r.I32();
                case "UInt32Property": return (long)r.U32();
                case "Int64Property": case "UInt64Property": return r.I64();
                case "Int16Property": case "UInt16Property": return (int)r.I16();
                case "Int8Property": return (int)r.I8();
                case "FloatProperty": return r.F32();
                case "DoubleProperty": return r.F64();
                case "BoolProperty": return r.U8() != 0;
                case "ByteProperty": return size == 8 ? (object)pkg.ReadName(r) : (int)r.U8();
                case "NameProperty": case "EnumProperty": return pkg.ReadName(r);
                case "StrProperty": return r.FString();
                case "TextProperty": return ReadText(pkg, r);
                case "ObjectProperty": case "ClassProperty": case "InterfaceProperty":
                case "WeakObjectProperty": case "LazyObjectProperty":
                    return pkg.ObjectPath(r.I32());
                case "SoftObjectProperty": case "SoftClassProperty":
                    { string p = pkg.ReadName(r); r.FString(); return p; }
            }
            throw new InvalidDataException("unsupported " + type);
        }

        // FText (cooked): flags, history type, then the history. Base histories carry the English
        // source string; string-table entries give their key, which here is the same word.
        public static string ReadText(Package pkg, Reader r)
        {
            r.U32();
            sbyte history = r.I8();
            if (history == -1) return r.I32() != 0 ? r.FString() : "";
            if (history == 0) { r.FString(); r.FString(); return r.FString(); }
            if (history == 11) { pkg.ReadName(r); return r.FString(); }
            throw new InvalidDataException("text history " + history);
        }

        static readonly Dictionary<string, int> Fixed = new Dictionary<string, int>
        {
            { "Vector", 12 }, { "Rotator", 12 }, { "Vector2D", 8 }, { "Vector4", 16 }, { "Quat", 16 },
            { "LinearColor", 16 }, { "Color", 4 }, { "Guid", 16 }, { "IntPoint", 8 }, { "IntVector", 12 },
            { "Box", 25 }, { "Box2D", 17 }, { "DateTime", 8 }, { "Timespan", 8 }, { "FrameNumber", 4 },
        };

        public static object ReadStruct(Package pkg, Reader r, string structName, int end)
        {
            if (structName == "GameplayTagContainer")
            {
                int n = r.I32();
                List<object> tags = new List<object>();
                for (int i = 0; i < n; i++) tags.Add(pkg.ReadName(r));
                return tags;
            }
            if (structName == "SoftObjectPath" || structName == "SoftClassPath")
            {
                string p = pkg.ReadName(r); r.FString(); return p;
            }
            int len;
            if (structName != null && Fixed.TryGetValue(structName, out len)) { r.Skip(len); return null; }
            return ReadTagged(pkg, r, end);
        }

        static object ReadElement(Package pkg, Reader r, string type, string structName, int end)
        {
            if (type == "StructProperty") return ReadStruct(pkg, r, structName, end);
            return ReadValue(pkg, r, type, type == "ByteProperty" ? 1 : 0);
        }

        static List<object> ReadArray(Package pkg, Reader r, string inner, int end, bool isSet)
        {
            if (isSet) r.I32();             // elements to remove
            int n = r.I32();
            if (n < 0 || n > 1000000) throw new InvalidDataException("bad array length " + n);
            List<object> list = new List<object>();
            string structName = null;
            if (inner == "StructProperty" && !isSet)
            {
                // Arrays of structs carry one inner tag for all elements.
                pkg.ReadName(r); pkg.ReadName(r); r.I32(); r.I32();
                structName = pkg.ReadName(r); r.Skip(16);
                if (r.U8() != 0) r.Skip(16);
            }
            if (inner == "ByteProperty" && n > 0 && (end - r.P) == n * 8)
                inner = "NameProperty";      // enum-valued bytes are names
            for (int i = 0; i < n; i++) list.Add(ReadElement(pkg, r, inner, structName, end));
            return list;
        }

        static List<object> ReadMap(Package pkg, Reader r, string keyType, string valueType, int end)
        {
            int remove = r.I32();
            for (int i = 0; i < remove; i++) ReadElement(pkg, r, keyType, null, end);
            int n = r.I32();
            if (n < 0 || n > 1000000) throw new InvalidDataException("bad map length " + n);
            List<object> list = new List<object>();
            for (int i = 0; i < n; i++)
            {
                Dictionary<string, object> kv = new Dictionary<string, object>();
                kv["Key"] = ReadElement(pkg, r, keyType, null, end);
                kv["Value"] = ReadElement(pkg, r, valueType, null, end);
                list.Add(kv);
            }
            return list;
        }
    }

    // ---- .locres (the game's English text) -------------------------------------------------------

    public static class Locres
    {
        static readonly byte[] MagicBytes = { 0x0E, 0x14, 0x74, 0x75, 0x67, 0x4A, 0x03, 0xFC, 0x4A, 0x15, 0x90, 0x9D, 0xC3, 0x37, 0x7F, 0x1B };

        // (namespace, key, string) for every entry, versions 0-3.
        public static List<string[]> Read(byte[] b)
        {
            int ver = 0;
            Reader r = new Reader(b, 0);
            bool magic = b.Length > 17;
            for (int i = 0; magic && i < 16; i++) if (b[i] != MagicBytes[i]) magic = false;
            if (magic) { ver = b[16]; r.P = 17; }
            List<string> strings = null;
            if (ver >= 1)
            {
                long q = r.I64();
                Reader s = new Reader(b, (int)q);
                int count = s.I32();
                strings = new List<string>();
                for (int i = 0; i < count; i++)
                {
                    strings.Add(s.FString());
                    if (ver >= 2) s.Skip(4);      // reference count
                }
            }
            if (ver >= 2) r.Skip(4);              // entry count
            uint namespaces = r.U32();
            List<string[]> entries = new List<string[]>();
            for (uint n = 0; n < namespaces; n++)
            {
                if (ver >= 2) r.Skip(4);          // namespace hash
                string ns = r.FString();
                uint count = r.U32();
                for (uint i = 0; i < count; i++)
                {
                    if (ver >= 2) r.Skip(4);      // key hash
                    string key = r.FString();
                    r.Skip(4);                    // source string hash
                    string str = ver >= 1 ? strings[r.I32()] : r.FString();
                    entries.Add(new string[] { ns, key, str });
                }
            }
            return entries;
        }
    }

    // ---- cooked Texture2D -> Bitmap ---------------------------------------------------------------

    public static class Texture
    {
        // Finds the platform data by its pixel format string (PF_...) and decodes the largest mip it
        // can read: inline in the .uexp, or in the .ubulk.
        public static Bitmap Decode(byte[] uexp, byte[] ubulk, int uassetSize, out string format)
        {
            byte[] pf = Encoding.ASCII.GetBytes("PF_");
            for (int i = 4; i + 3 < uexp.Length; i++)
            {
                if (uexp[i] != pf[0] || uexp[i + 1] != pf[1] || uexp[i + 2] != pf[2]) continue;
                int len = BitConverter.ToInt32(uexp, i - 4);
                if (len < 4 || len > 40 || i + len > uexp.Length || uexp[i + len - 1] != 0 || i < 16) continue;
                string fmt = Encoding.ASCII.GetString(uexp, i, len - 1);
                Reader r = new Reader(uexp, i - 16);
                int sizeX = r.I32(), sizeY = r.I32(), packed = r.I32();
                r.P = i + len;
                if ((packed & (1 << 30)) != 0) r.Skip(8);     // optional data
                r.I32();                                      // first mip to load
                int numMips = r.I32();
                if (numMips <= 0 || numMips > 16 || sizeX <= 0 || sizeX > 8192 || sizeY <= 0 || sizeY > 8192) continue;
                int bestW = 0, bestH = 0;
                byte[] best = null;
                for (int m = 0; m < numMips; m++)
                {
                    r.Skip(4);                                // cooked flag
                    uint flags = r.U32();
                    long onDisk;
                    if ((flags & 0x2000) != 0) { r.I64(); onDisk = r.I64(); } else { r.I32(); onDisk = r.I32(); }
                    long offset = r.I64();
                    byte[] data = null;
                    if ((flags & 0x20) != 0 || onDisk <= 0) { }
                    else if ((flags & 0x1) == 0) data = r.Bytes((int)onDisk);              // inline
                    else if ((flags & 0x100) != 0)                                         // .ubulk
                    {
                        if (ubulk != null && offset >= 0 && offset + onDisk <= ubulk.Length)
                        { data = new byte[onDisk]; Buffer.BlockCopy(ubulk, (int)offset, data, 0, (int)onDisk); }
                    }
                    else                                                                   // end of this package
                    {
                        long o = offset - uassetSize;
                        if (o >= 0 && o + onDisk <= uexp.Length)
                        { data = new byte[onDisk]; Buffer.BlockCopy(uexp, (int)o, data, 0, (int)onDisk); }
                    }
                    int w = r.I32(), h = r.I32(); r.I32();
                    if (data != null && w * h > bestW * bestH) { best = data; bestW = w; bestH = h; }
                }
                if (best == null) throw new InvalidDataException(fmt + " " + sizeX + "x" + sizeY + ": no readable mip");
                format = fmt;
                return ToBitmap(fmt, bestW, bestH, best);
            }
            throw new InvalidDataException("no texture data (PF_...) found");
        }

        static Bitmap ToBitmap(string fmt, int w, int h, byte[] d)
        {
            byte[] rgba = new byte[w * h * 4];
            if (fmt == "PF_B8G8R8A8")
            {
                for (int i = 0; i < w * h; i++)
                { rgba[i * 4] = d[i * 4 + 2]; rgba[i * 4 + 1] = d[i * 4 + 1]; rgba[i * 4 + 2] = d[i * 4]; rgba[i * 4 + 3] = d[i * 4 + 3]; }
            }
            else if (fmt == "PF_G8")
            {
                for (int i = 0; i < w * h; i++) { rgba[i * 4] = rgba[i * 4 + 1] = rgba[i * 4 + 2] = d[i]; rgba[i * 4 + 3] = 255; }
            }
            else if (fmt == "PF_DXT1" || fmt == "PF_DXT3" || fmt == "PF_DXT5")
            {
                int bs = fmt == "PF_DXT1" ? 8 : 16;
                int bw = (w + 3) / 4, bh = (h + 3) / 4;
                for (int by = 0; by < bh; by++)
                    for (int bx = 0; bx < bw; bx++)
                    {
                        int o = (by * bw + bx) * bs;
                        byte[][] px = fmt == "PF_DXT1" ? ColorBlock(d, o, false) : ColorBlock(d, o + 8, true);
                        if (fmt != "PF_DXT1")
                        {
                            int[] a = fmt == "PF_DXT5" ? AlphaDxt5(d, o) : AlphaDxt3(d, o);
                            for (int i = 0; i < 16; i++) px[i][3] = (byte)a[i];
                        }
                        for (int i = 0; i < 16; i++)
                        {
                            int x = bx * 4 + i % 4, y = by * 4 + i / 4;
                            if (x < w && y < h) Buffer.BlockCopy(px[i], 0, rgba, (y * w + x) * 4, 4);
                        }
                    }
            }
            else throw new InvalidDataException("pixel format " + fmt + " not supported");

            Bitmap bmp = new Bitmap(w, h, PixelFormat.Format32bppArgb);
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                {
                    int i = (y * w + x) * 4;
                    bmp.SetPixel(x, y, Color.FromArgb(rgba[i + 3], rgba[i], rgba[i + 1], rgba[i + 2]));
                }
            return bmp;
        }

        static byte[] C565(int c)
        {
            return new byte[] { (byte)(((c >> 11) & 31) * 255 / 31), (byte)(((c >> 5) & 63) * 255 / 63), (byte)((c & 31) * 255 / 31), 255 };
        }

        static byte[][] ColorBlock(byte[] d, int o, bool fourColor)
        {
            int c0 = BitConverter.ToUInt16(d, o), c1 = BitConverter.ToUInt16(d, o + 2);
            uint bits = BitConverter.ToUInt32(d, o + 4);
            byte[] p0 = C565(c0), p1 = C565(c1);
            byte[][] pal = new byte[4][];
            pal[0] = p0; pal[1] = p1;
            if (c0 > c1 || fourColor)
            {
                pal[2] = new byte[] { (byte)((2 * p0[0] + p1[0]) / 3), (byte)((2 * p0[1] + p1[1]) / 3), (byte)((2 * p0[2] + p1[2]) / 3), 255 };
                pal[3] = new byte[] { (byte)((p0[0] + 2 * p1[0]) / 3), (byte)((p0[1] + 2 * p1[1]) / 3), (byte)((p0[2] + 2 * p1[2]) / 3), 255 };
            }
            else
            {
                pal[2] = new byte[] { (byte)((p0[0] + p1[0]) / 2), (byte)((p0[1] + p1[1]) / 2), (byte)((p0[2] + p1[2]) / 2), 255 };
                pal[3] = new byte[] { 0, 0, 0, 0 };
            }
            byte[][] px = new byte[16][];
            for (int i = 0; i < 16; i++) px[i] = (byte[])pal[(bits >> (2 * i)) & 3].Clone();
            return px;
        }

        static int[] AlphaDxt5(byte[] d, int o)
        {
            int a0 = d[o], a1 = d[o + 1];
            ulong bits = 0;
            for (int i = 0; i < 6; i++) bits |= (ulong)d[o + 2 + i] << (8 * i);
            int[] pal = new int[8];
            pal[0] = a0; pal[1] = a1;
            if (a0 > a1) for (int i = 1; i <= 6; i++) pal[i + 1] = ((7 - i) * a0 + i * a1) / 7;
            else { for (int i = 1; i <= 4; i++) pal[i + 1] = ((5 - i) * a0 + i * a1) / 5; pal[6] = 0; pal[7] = 255; }
            int[] a = new int[16];
            for (int i = 0; i < 16; i++) a[i] = pal[(int)((bits >> (3 * i)) & 7)];
            return a;
        }

        static int[] AlphaDxt3(byte[] d, int o)
        {
            ulong bits = BitConverter.ToUInt64(d, o);
            int[] a = new int[16];
            for (int i = 0; i < 16; i++) a[i] = (int)((bits >> (4 * i)) & 15) * 17;
            return a;
        }
    }

    // ---- leaders.json, traits.json, trait-icons ---------------------------------------------------

    public class Extractor
    {
        public Pak Pak = new Pak();
        public List<string> Log = new List<string>();
        const string Tables = "Phoenix/Content/Game/DataTables/";
        static readonly string[] Stats = { "Health", "Mana", "AttackSpeed", "BasicPower", "AbilityPower", "BasicProtection", "AbilityProtection" };

        // paksDir: <game>\Phoenix\Content\Paks. Base paks first, patch paks (*_P.pak) after them.
        public Extractor(string paksDir)
        {
            List<string> paks = new List<string>(Directory.GetFiles(paksDir, "*.pak"));
            paks.Sort(delegate (string a, string b)
            {
                bool pa = a.EndsWith("_P.pak", StringComparison.OrdinalIgnoreCase), pb = b.EndsWith("_P.pak", StringComparison.OrdinalIgnoreCase);
                if (pa != pb) return pa ? 1 : -1;
                return string.Compare(a, b, StringComparison.OrdinalIgnoreCase);
            });
            if (paks.Count == 0) throw new FileNotFoundException("no .pak files in " + paksDir);
            foreach (string p in paks) Pak.Open(p);
            Log.AddRange(Pak.Log);
        }

        public Package Load(string path)
        {
            byte[] a = Pak.Read(path + ".uasset"), e = Pak.Read(path + ".uexp");
            if (a == null || e == null) throw new FileNotFoundException(path + " is not in the game's paks");
            return new Package(a, e, path.Substring(path.LastIndexOf('/') + 1));
        }

        // Dump one asset's properties as JSON (for checking the reader against FModel exports).
        public string Dump(string path, bool rows)
        {
            Package p = Load(path);
            if (rows)
            {
                Dictionary<string, object> d = new Dictionary<string, object>();
                foreach (KeyValuePair<string, Dictionary<string, object>> kv in p.Rows()) d[kv.Key] = kv.Value;
                return Json.Write(d);
            }
            Reader after;
            return Json.Write(p.Properties(out after));
        }

        static object Get(Dictionary<string, object> d, string k) { object v; return d != null && d.TryGetValue(k, out v) ? v : null; }
        static string Str(Dictionary<string, object> d, string k) { object v = Get(d, k); return v == null ? "" : Convert.ToString(v, CultureInfo.InvariantCulture).Trim(); }

        public Dictionary<string, object> Leaders(List<string[]> locres)
        {
            Dictionary<string, Dictionary<string, object>> leaderRows = Load(Tables + "LeaderTable").Rows();
            Dictionary<string, Dictionary<string, object>> cardRows = Load(Tables + "CardDataTable").Rows();
            Dictionary<string, Dictionary<string, object>> stats = Load(Tables + "BotStatTable").Rows();
            Dictionary<string, Dictionary<string, object>> items = Load(Tables + "Common_Pool_ItemTable").Rows();
            Dictionary<long, string> cardKeyById = new Dictionary<long, string>();
            foreach (KeyValuePair<string, Dictionary<string, object>> kv in cardRows)
            {
                object id = Get(kv.Value, "DBCardID");
                if (id != null) cardKeyById[Convert.ToInt64(id)] = kv.Key;
            }
            List<string> texts = new List<string>();
            if (locres != null) foreach (string[] e in locres) if (e[0] == "") texts.Add(e[2].Trim());

            List<Dictionary<string, object>> leaders = new List<Dictionary<string, object>>();
            foreach (KeyValuePair<string, Dictionary<string, object>> kv in leaderRows)
            {
                Dictionary<string, object> r = kv.Value;
                long unitId = Convert.ToInt64(Get(r, "UnitId") ?? 0);
                string cardKey;
                Dictionary<string, object> card = null;
                if (cardKeyById.TryGetValue(unitId, out cardKey)) card = cardRows[cardKey];
                string statKey = Str(card, "StatsRowName");
                if (statKey == "" || statKey == "None") statKey = cardKey ?? "";
                Dictionary<string, object> st;
                stats.TryGetValue(statKey, out st);
                Dictionary<string, object> item;
                items.TryGetValue(Str(r, "ItemName"), out item);
                string cls = "";
                List<object> kw = Get(st, "Keywords") as List<object>;
                if (kw != null)
                    foreach (object k in kw)
                    {
                        string s = Convert.ToString(k);
                        if (s.StartsWith("UnitKeyword.UnitType.")) { cls = s.Substring(s.LastIndexOf('.') + 1); break; }
                    }
                string name = Str(card, "Name");
                if (name == "") name = kv.Key;

                Dictionary<string, object> l = new Dictionary<string, object>();
                l["key"] = kv.Key;
                l["id"] = unitId;
                l["enabled"] = Convert.ToBoolean(Get(r, "Enabled") ?? false);
                l["name"] = name;
                l["class"] = cls;
                Dictionary<string, object> passive = new Dictionary<string, object>();
                passive["name"] = Str(item, "DisplayName");
                passive["type"] = Str(item, "Type");
                passive["description"] = Str(item, "Description");
                l["passive"] = passive;
                Dictionary<string, object> statOut = new Dictionary<string, object>();
                foreach (string s in Stats) { object v = Get(st, s); if (v != null) statOut[s] = v; }
                l["stats"] = statOut;
                // No table links a skill to its leader; as in export_leaders.py --skills, the
                // description is the most common English string that starts with the leader's name.
                Dictionary<string, int> counts = new Dictionary<string, int>();
                Regex rx = new Regex("^" + Regex.Escape(name) + @"\b");
                foreach (string t in texts) if (rx.IsMatch(t)) { int c; counts.TryGetValue(t, out c); counts[t] = c + 1; }
                string skill = "";
                int best = 0;
                foreach (string t in texts)   // first-seen order breaks ties, like Counter.most_common
                {
                    int c;
                    if (counts.TryGetValue(t, out c) && c > best) { best = c; skill = t; }
                }
                Dictionary<string, object> sk = new Dictionary<string, object>();
                sk["name"] = "";
                sk["description"] = skill;
                l["skill"] = sk;
                leaders.Add(l);
            }
            leaders.Sort(delegate (Dictionary<string, object> a, Dictionary<string, object> b)
            {
                bool ea = (bool)a["enabled"], eb = (bool)b["enabled"];
                if (ea != eb) return ea ? -1 : 1;
                return string.CompareOrdinal((string)a["name"], (string)b["name"]);
            });
            Dictionary<string, object> outp = new Dictionary<string, object>();
            outp["source"] = "Read from this PC's Prophecy paks: LeaderTable, CardDataTable, BotStatTable, Common_Pool_ItemTable, PhoenixGame.locres";
            outp["leaders"] = leaders;
            return outp;
        }

        public Dictionary<string, object> Traits(string iconDir)
        {
            Reader after;
            Dictionary<string, object> props = Load("Phoenix/Content/Game/UnitBonuses/UnitBonusTable_V12").Properties(out after);
            List<object> table = Get(props, "DataTable") as List<object>;
            if (table == null) throw new InvalidDataException("UnitBonusTable_V12 has no DataTable map");
            if (iconDir != null) Directory.CreateDirectory(iconDir);
            List<Dictionary<string, object>> traits = new List<Dictionary<string, object>>();
            int icons = 0;
            foreach (object o in table)
            {
                Dictionary<string, object> kv = (Dictionary<string, object>)o;
                Dictionary<string, object> key = kv["Key"] as Dictionary<string, object>;
                Dictionary<string, object> v = kv["Value"] as Dictionary<string, object>;
                if (v == null) continue;
                List<string> values = new List<string>();
                List<object> combos = Get(v, "Combos") as List<object>;
                if (combos != null) foreach (object c in combos) values.Add(Convert.ToString(c).Trim());
                string template = Str(v, "BonusDescription");
                string effect = Regex.Replace(template, @"\{(\d+)\}", delegate (Match m)
                {
                    int i = int.Parse(m.Groups[1].Value);
                    return i < values.Count ? values[i] : m.Value;
                });
                List<object> tiers = new List<object>();
                List<object> bonuses = Get(v, "Bonuses") as List<object>;
                if (bonuses != null)
                    for (int i = 0; i < bonuses.Count; i++)
                    {
                        Dictionary<string, object> t = new Dictionary<string, object>();
                        t["holders"] = Get(bonuses[i] as Dictionary<string, object>, "RequiredCount");
                        t["value"] = i < values.Count ? values[i] : "";
                        tiers.Add(t);
                    }
                // "/Game/UX/.../T_Trait_Endurance" -> "Phoenix/Content/UX/.../T_Trait_Endurance"
                string iconPkg = Str(v, "IconLarge");
                string iconPath = iconPkg.StartsWith("/Game/") ? "Phoenix/Content/" + iconPkg.Substring(6) : "";
                string icon = iconPath.Length > 0 ? iconPath.Substring(iconPath.LastIndexOf('/') + 1) : "";

                Dictionary<string, object> tr = new Dictionary<string, object>();
                tr["tag"] = Str(key, "TagName");
                tr["name"] = Str(v, "Title");
                tr["bonus"] = Str(v, "BonusName");
                tr["flavor"] = Str(v, "Description");
                tr["effect"] = effect;
                tr["template"] = template;
                tr["tiers"] = tiers;
                tr["icon"] = icon;
                tr["icon_path"] = iconPath;
                traits.Add(tr);

                if (iconDir != null && icon != "")
                {
                    try
                    {
                        byte[] ua = Pak.Read(iconPath + ".uasset"), ue = Pak.Read(iconPath + ".uexp"), ub = Pak.Read(iconPath + ".ubulk");
                        if (ue == null) throw new FileNotFoundException(iconPath + ".uexp not in the paks");
                        string fmt;
                        using (Bitmap bmp = Texture.Decode(ue, ub, ua == null ? 0 : ua.Length, out fmt))
                            bmp.Save(Path.Combine(iconDir, icon + ".png"), ImageFormat.Png);
                        icons++;
                    }
                    catch (Exception e) { Log.Add("icon " + icon + ": " + e.Message); }
                }
            }
            traits.Sort(delegate (Dictionary<string, object> a, Dictionary<string, object> b)
            { return string.Compare((string)a["name"], (string)b["name"], StringComparison.OrdinalIgnoreCase); });
            Log.Add(traits.Count + " traits, " + icons + " icons");
            Dictionary<string, object> outp = new Dictionary<string, object>();
            outp["source"] = "Read from this PC's Prophecy paks: Game/UnitBonuses/UnitBonusTable_V12";
            outp["traits"] = traits;
            return outp;
        }

        // Writes leaders.json, traits.json and trait-icons\ into outDir. Returns a log.
        public static string Run(string gameDir, string outDir)
        {
            Extractor x = new Extractor(Path.Combine(gameDir, @"Phoenix\Content\Paks"));
            Directory.CreateDirectory(outDir);
            List<string[]> loc = null;
            byte[] lb = x.Pak.Read("Phoenix/Content/Localization/PhoenixGame/en/PhoenixGame.locres");
            if (lb != null) loc = Locres.Read(lb); else x.Log.Add("no English locres; leader skills stay blank");
            Dictionary<string, object> leaders = x.Leaders(loc);
            x.Log.Add(((List<Dictionary<string, object>>)leaders["leaders"]).Count + " leaders");
            File.WriteAllText(Path.Combine(outDir, "leaders.json"), Json.Write(leaders), new UTF8Encoding(false));
            Dictionary<string, object> traits = x.Traits(Path.Combine(outDir, "trait-icons"));
            File.WriteAllText(Path.Combine(outDir, "traits.json"), Json.Write(traits), new UTF8Encoding(false));
            return string.Join(Environment.NewLine, x.Log.ToArray());
        }
    }

    // ---- minimal JSON writer ---------------------------------------------------------------------

    public static class Json
    {
        public static string Write(object o) { StringBuilder sb = new StringBuilder(); W(sb, o, 0); sb.Append('\n'); return sb.ToString(); }

        static void W(StringBuilder sb, object o, int ind)
        {
            string pad = new string(' ', 2 * (ind + 1)), end = new string(' ', 2 * ind);
            if (o == null) { sb.Append("null"); return; }
            if (o is string) { Str(sb, (string)o); return; }
            if (o is bool) { sb.Append((bool)o ? "true" : "false"); return; }
            if (o is float || o is double)
            {
                double d = Convert.ToDouble(o);
                sb.Append(o is float ? ((float)o).ToString("R", CultureInfo.InvariantCulture) : d.ToString("R", CultureInfo.InvariantCulture));
                return;
            }
            if (o is int || o is long || o is short || o is byte || o is uint) { sb.Append(Convert.ToString(o, CultureInfo.InvariantCulture)); return; }
            System.Collections.IDictionary dict = o as System.Collections.IDictionary;
            if (dict != null)
            {
                if (dict.Count == 0) { sb.Append("{}"); return; }
                sb.Append("{\n");
                bool first = true;
                foreach (System.Collections.DictionaryEntry e in dict)
                {
                    if (!first) sb.Append(",\n");
                    first = false;
                    sb.Append(pad); Str(sb, Convert.ToString(e.Key)); sb.Append(": "); W(sb, e.Value, ind + 1);
                }
                sb.Append('\n').Append(end).Append('}');
                return;
            }
            System.Collections.IEnumerable list = o as System.Collections.IEnumerable;
            if (list != null)
            {
                bool any = false;
                foreach (object x in list)
                {
                    sb.Append(any ? ",\n" : "[\n");
                    any = true;
                    sb.Append(pad); W(sb, x, ind + 1);
                }
                sb.Append(any ? "\n" + end + "]" : "[]");
                return;
            }
            Str(sb, o.ToString());
        }

        static void Str(StringBuilder sb, string s)
        {
            sb.Append('"');
            foreach (char c in s)
            {
                if (c == '"') sb.Append("\\\"");
                else if (c == '\\') sb.Append("\\\\");
                else if (c == '\n') sb.Append("\\n");
                else if (c == '\r') sb.Append("\\r");
                else if (c == '\t') sb.Append("\\t");
                else if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
                else sb.Append(c);
            }
            sb.Append('"');
        }
    }
}
