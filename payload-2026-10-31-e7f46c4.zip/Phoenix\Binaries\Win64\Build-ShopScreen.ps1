# Builds a pak of edited game assets on this PC, from this copy's own game files: unpacks the
# assets a recipe names from pakchunk0 with repak, turns them into the edited ones (COPY ranges of
# the original plus our new bytes, checked by SHA-256 before and after), and packs them. No game
# files come from the internet. Two recipes:
#   shop-screen-delta.json   the 6-card shop's screen (Phoenix-WindowsNoEditor_ShopUI_P.pak), made
#                            on the host by research\prophecy\dev-copy\overrides\shop-ui\make_delta.py
#   board-layout-delta.json  boards moved close together, bigger sky domes (Phoenix-WindowsNoEditor_Boards_P.pak),
#                            made by research\prophecy\dev-copy\overrides\board-layout\make_board_layout.py
#
#   Build-ShopScreen.ps1                                                  # the shop screen
#   Build-ShopScreen.ps1 -Recipe board-layout-delta.json -Label 'board layout'
#   Build-ShopScreen.ps1 -Recipe <path> -Bin <copy>\Phoenix\Binaries\Win64 -Repak <repak.exe>   # another copy (host)
#
# The join window runs it for each recipe before launch. Does nothing when the pak is already built
# from the current recipe (a record next to the pak keeps the recipe id). Prints "<label>: ..."
# lines; on failure the last line starts "<LABEL> FAILED:" and the exit code is 1, and
# Patch-Phoenix.ps1 then leaves the patch that needs the pak off ("MISSING").
# Needs only Windows PowerShell 5.1 and tools\repak.exe (shipped with the bundle and its updates).
param(
  [string]$Recipe = 'shop-screen-delta.json',   # relative to -Bin, or a full path
  [string]$Label = 'shop screen',
  [string]$Bin = '',                             # the game copy's Phoenix\Binaries\Win64; default: this script's folder
  [string]$Repak = ''                            # default: tools\repak.exe in -Bin
)
$ErrorActionPreference = 'Stop'
# Windows PowerShell leaves $PSScriptRoot empty inside param() when started with -File.
$bin = [IO.Path]::GetFullPath($(if ($Bin) { $Bin } else { $PSScriptRoot }))
$deltaFile = if ([IO.Path]::IsPathRooted($Recipe)) { $Recipe } else { Join-Path $bin $Recipe }
$repak = if ($Repak) { $Repak } else { Join-Path $bin 'tools\repak.exe' }
$paks = [IO.Path]::GetFullPath((Join-Path $bin '..\..\Content\Paks'))
$work = Join-Path $env:TEMP "prophecy-pak-recipe-$PID"

# Windows PowerShell 5.1 turns a native tool's stderr into a terminating error under 'Stop', so
# repak runs with 'Continue' and its output is returned as text, with the exit code in $LASTEXITCODE.
function Invoke-Repak {
  $eap = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  try { return (& $repak @args 2>&1 | Out-String) } finally { $ErrorActionPreference = $eap }
}

function Get-Sha256([byte[]]$bytes) {
  $h = [Security.Cryptography.SHA256]::Create()
  try { return (($h.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') }) -join '') } finally { $h.Dispose() }
}

try {
  if (-not (Test-Path $deltaFile)) { "${Label}: no $(Split-Path $deltaFile -Leaf); nothing to build."; exit 0 }
  $spec = Get-Content $deltaFile -Raw | ConvertFrom-Json
  $pak = Join-Path $paks $spec.pak
  $record = [IO.Path]::ChangeExtension($pak, '.json')
  if ((Test-Path $pak) -and (Test-Path $record) -and ((Get-Content $record -Raw | ConvertFrom-Json).id -eq $spec.id)) {
    "${Label}: up to date"; exit 0
  }
  if ((Test-Path $pak) -and -not (Test-Path $record)) { "${Label}: using the pak that came with the bundle"; exit 0 }
  if (-not (Test-Path $repak)) { throw 'tools\repak.exe is missing; click Update or ask the host for a new bundle.' }
  if ($spec.repak_sha256 -and (Get-FileHash $repak -Algorithm SHA256).Hash.ToLower() -ne $spec.repak_sha256) {
    throw 'tools\repak.exe is not the expected file; click Update.'
  }
  $base = Join-Path $paks 'pakchunk0-WindowsNoEditor.pak'
  if (-not (Test-Path $base)) { throw "the game pak is missing ($base)." }
  "${Label}: building it from this copy's game files ..."

  Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
  New-Item -ItemType Directory -Force "$work\orig", "$work\stage" | Out-Null
  $assets = @($spec.files | ForEach-Object { $_.path -replace '\.(uasset|uexp|umap|ubulk)$', '' } | Select-Object -Unique)
  # repak may refuse to unpack into a folder that is not empty, so each asset gets its own and
  # they are merged into orig afterwards.
  for ($i = 0; $i -lt $assets.Count; $i++) {
    $out = Invoke-Repak unpack -i "$($assets[$i]).*" -o "$work\u$i" $base
    if ($LASTEXITCODE) { throw "repak could not read $($assets[$i]) from the game pak: $out" }
    Copy-Item "$work\u$i\*" "$work\orig" -Recurse -Force
  }
  foreach ($f in $spec.files) {
    $rel = $f.path -replace '/', '\'
    $srcPath = Join-Path "$work\orig" $rel
    if (-not (Test-Path $srcPath)) { throw "$rel is not in this copy's game pak." }
    $src = [IO.File]::ReadAllBytes($srcPath)
    if ((Get-Sha256 $src) -ne $f.src_sha256) { throw "$rel differs from the host's game files (a different game version?)." }
    $ms = New-Object IO.MemoryStream
    foreach ($op in $f.ops) {
      if ($op[0] -eq 'c') { $ms.Write($src, [int]$op[1], [int]$op[2]) }
      else { $b = [Convert]::FromBase64String($op[1]); $ms.Write($b, 0, $b.Length) }
    }
    $dst = $ms.ToArray()
    if ((Get-Sha256 $dst) -ne $f.dst_sha256) { throw "$rel did not come out as expected." }
    $dstPath = Join-Path "$work\stage" $rel
    New-Item -ItemType Directory -Force (Split-Path $dstPath) | Out-Null
    [IO.File]::WriteAllBytes($dstPath, $dst)
  }
  # Same pak version, mount point and compression as the game's own paks.
  $tmpPak = Join-Path $work $spec.pak
  $out = Invoke-Repak pack --version V8A --mount-point ../../../ --compression Zlib "$work\stage" $tmpPak
  # A missing or empty pak crashes the game at start, so only a good one is installed.
  if ($LASTEXITCODE -or -not (Test-Path $tmpPak) -or (Get-Item $tmpPak).Length -eq 0) { throw "repak could not pack the ${Label}: $out" }
  Copy-Item $tmpPak $pak -Force
  [ordered]@{ id = $spec.id; built = (Get-Date).ToString('s') } | ConvertTo-Json | Set-Content $record -Encoding ascii
  "${Label}: built {0} ({1:N0} KB)" -f $spec.pak, ((Get-Item $pak).Length / 1KB)
} catch {
  # Never leave a half-made pak behind.
  if ($pak -and (Test-Path $pak) -and -not ((Test-Path $record) -and ((Get-Content $record -Raw | ConvertFrom-Json).id -eq $spec.id))) {
    Remove-Item $pak, $record -Force -ErrorAction SilentlyContinue
  }
  "$($Label.ToUpper()) FAILED: $($_.Exception.Message)"
  exit 1
} finally {
  Remove-Item $work -Recurse -Force -ErrorAction SilentlyContinue
}
