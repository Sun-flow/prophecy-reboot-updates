# Join window for the friend bundle: shows the host's address, press Join.
# Lives in <bundle>\Phoenix\Binaries\Win64\ next to Start-Preset.ps1; "Play Prophecy.bat" at the
# bundle root opens it. Settings come from <bundle>\friend.json (written by Build-FriendBundle.ps1,
# every field described in friend\README.md):
#
#   address  the host's public address, e.g. a playit.gg address "name.gl.ply.gg:12345" or a
#            Radmin VPN address "26.1.2.3:7777". Port 7777 if left out.
#   title    window title
#   leader   the leader picked in this window (UnitId from leaders.json next to this script; 0 or
#            missing = random). Saved back to friend.json when you press Join.
#   name     the in-game name typed in this window (letters, digits, _ - . up to 20). Missing or
#            empty = the window makes up a random one (New-RandomName) and saves it at once, so it
#            stays the same across sessions. Saved back to friend.json when you press Join; the
#            host needs the player-name patch to show it.
#   update_url  where the host publishes updates (raw URL of the public feed repo, or the host
#            launcher's own server). Join checks it first and updates the scripts when the
#            version differs. Missing = no check.
#   solo     the solo game picked in this window (a preset name, see $soloGames below; default
#            standard). Saved back to friend.json when you press Play solo.
#
# Needs only Windows PowerShell 5.1, which every Windows 10/11 PC has. Nothing is installed.
param(
  [switch]$AutoJoin,  # set when the window restarts itself after an update from Join: join right away
  [switch]$Updated    # set when it restarts after an update from the Update button: just say so
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()

$bin = $PSScriptRoot
$bundle = (Resolve-Path "$bin\..\..\..").Path
$cfgPath = Join-Path $bundle 'friend.json'
# Files extracted with Explorer from a downloaded zip carry the "from the web" mark
# (Zone.Identifier), and Smart App Control then blocks Play Prophecy.bat. Clear it from the small
# files this window and Start-Preset use, so a hand-extracted update doesn't block the next start.
function Clear-WebMark {
  $files = @(Get-ChildItem $bundle -File -ErrorAction SilentlyContinue) +
    @(Get-ChildItem $bin -Recurse -File -Include *.ps1, *.json, *.md -ErrorAction SilentlyContinue)
  $files | Where-Object { $_.Extension -in '.bat', '.ps1', '.json', '.txt', '.md' } | Unblock-File -ErrorAction SilentlyContinue
}
Clear-WebMark
$cfg = if (Test-Path $cfgPath) { Get-Content $cfgPath -Raw | ConvertFrom-Json } else { [pscustomobject]@{} }
# An update zip brings friend-update.json (new address/title). Merge it in, keeping fields such as
# the leader pick, then remove it so it applies once.
$updPath = Join-Path $bundle 'friend-update.json'
if (Test-Path $updPath) {
  try {
    $upd = Get-Content $updPath -Raw | ConvertFrom-Json
    foreach ($prop in $upd.PSObject.Properties) { $cfg | Add-Member -NotePropertyName $prop.Name -NotePropertyValue $prop.Value -Force }
    $cfg | ConvertTo-Json | Set-Content $cfgPath -Encoding ascii
    Remove-Item $updPath -ErrorAction SilentlyContinue
  } catch { }
}
function Get-Cfg($name, $default) { if ($cfg.PSObject.Properties[$name] -and $cfg.$name) { $cfg.$name } else { $default } }
# A made-up player name, adjective + noun ("AshenOracle"), so nobody joins as "Player N". Every pair
# fits the 20-character name limit and the [A-Za-z0-9_.-] rule.
$nameAdjectives = @('Ashen', 'Amber', 'Bold', 'Brazen', 'Bright', 'Cinder', 'Crimson', 'Dusk', 'Ember', 'Fabled',
  'Fallen', 'Gilded', 'Grim', 'Hallowed', 'Hidden', 'Iron', 'Ivory', 'Jade', 'Lone', 'Lucky', 'Lunar',
  'Mighty', 'Misty', 'Molten', 'Noble', 'Obsidian', 'Pale', 'Quiet', 'Restless', 'Rune', 'Sable',
  'Silver', 'Solar', 'Starlit', 'Stone', 'Storm', 'Swift', 'Thorned', 'Twilight', 'Wild')
$nameNouns = @('Augur', 'Bard', 'Champion', 'Comet', 'Crow', 'Drake', 'Envoy', 'Falcon', 'Fox', 'Golem',
  'Griffin', 'Harbinger', 'Herald', 'Hound', 'Hydra', 'Lantern', 'Lion', 'Mystic', 'Nomad', 'Omen',
  'Oracle', 'Owl', 'Pilgrim', 'Prophet', 'Raven', 'Sage', 'Seer', 'Sentinel', 'Serpent', 'Spark',
  'Sphinx', 'Stag', 'Titan', 'Viper', 'Wanderer', 'Warden', 'Whisper', 'Wolf', 'Wraith', 'Wyrm')
function New-RandomName { (Get-Random -InputObject $nameAdjectives) + (Get-Random -InputObject $nameNouns) }
function Save-Cfg { try { $cfg | ConvertTo-Json | Set-Content $cfgPath -Encoding ascii } catch { } }
# First run (or a cleared name): make one up and keep it, so the same name comes back next time.
if (-not (Get-Cfg 'name' '')) {
  $cfg | Add-Member -NotePropertyName name -NotePropertyValue (New-RandomName) -Force
  Save-Cfg
}
$title = Get-Cfg 'title' 'Prophecy'
$exe = Join-Path $bin 'Phoenix.exe'
# Leader and trait info (text and icons) is read from this PC's own game files into <bundle>\gamedata
# by Extract-GameData.ps1 (GameData.cs); it only does work the first time and after the paks
# change. Game text and art never ship in public updates (mae, 2026-10-30). Copies a full bundle
# brought next to this script are the fallback if reading the game files fails.
$gameData = Join-Path $bundle 'gamedata'
$gameDataNote = ''
$extractor = Join-Path $bin 'Extract-GameData.ps1'
# A bootstrap update (docs/server/friend-updates.md) has the script but not GameData.cs yet.
if ((Test-Path $extractor) -and (Test-Path (Join-Path $bin 'GameData.cs'))) {
  try { [void](& $extractor -Game $bundle -Out $gameData) }
  catch {
    $gameDataNote = "Couldn't read leader and trait info from your game files ($($_.Exception.Message)). Send the host gamedata-error.txt from your Prophecy folder."
    try { Set-Content (Join-Path $bundle 'gamedata-error.txt') ($_ | Out-String) -Encoding ascii } catch { }
  }
}
function Get-DataPath($name) { $p = Join-Path $gameData $name; if (Test-Path $p) { $p } else { Join-Path $bin $name } }
# Leaders the host can give you (enabled ones).
$leaderFile = Get-DataPath 'leaders.json'
$leaders = @()
if (Test-Path $leaderFile) { $leaders = @((Get-Content $leaderFile -Raw -Encoding UTF8 | ConvertFrom-Json).leaders | Where-Object { $_.enabled }) }
# Trait reference for the "All traits" table.
$traitFile = Get-DataPath 'traits.json'
$traits = @()
if (Test-Path $traitFile) { $traits = @((Get-Content $traitFile -Raw -Encoding UTF8 | ConvertFrom-Json).traits) }
# The game's trait icons, trait-icons\<icon>.png.
$iconDir = Get-DataPath 'trait-icons'
# Solo games against bots: presets\<name>.json next to Start-Preset.ps1. Bots always fill all 7
# seats (MaxAIPlayers in a preset is ignored by the game), so a 1-bot duel isn't offered.
# test-solo is the testing preset (8 s shop); the intro still plays here, since skipping it needs the
# override pak, which only the host's tools build.
$soloGames = [ordered]@{
  'standard'  = 'Normal match vs 7 bots'
  'test-solo' = 'Quick match vs 7 bots (8 s shop)'
  'practice'  = 'Team Builder practice'
}
$logFile = Join-Path $bundle 'Phoenix\Saved\Logs\Phoenix.log'

# ---- helpers ------------------------------------------------------------------------------------

# "host[:port]" -> "ip:port". A playit.gg address is a host name whose IP can change, so it is
# looked up on every join and the game always gets a plain IP.
function Get-JoinAddress($text) {
  $text = $text.Trim()
  if (-not $text) { throw 'Type the address the host gave you.' }
  $m = [regex]::Match($text, '^([A-Za-z0-9.\-]+)(?::(\d{1,5}))?$')
  if (-not $m.Success) { throw "'$text' is not an address like name.gl.ply.gg:12345 or 26.1.2.3:7777" }
  $hostName = $m.Groups[1].Value
  $port = if ($m.Groups[2].Success) { $m.Groups[2].Value } else { '7777' }
  $ip = $null
  if (-not [Net.IPAddress]::TryParse($hostName, [ref]$ip)) {
    # The first lookup of a playit name can fail for a few seconds (seen in the 2026-10-30 test),
    # so retry. If it never resolves, hand the name to the game, which resolves it itself.
    $a = $null
    for ($i = 1; $i -le 5 -and -not $a; $i++) {
      try {
        $a = [Net.Dns]::GetHostAddresses($hostName) | Where-Object { $_.AddressFamily -eq 'InterNetwork' } | Select-Object -First 1
      } catch { $a = $null }
      if (-not $a -and $i -lt 5) { Say "Looking up $hostName (try $i of 5) ..."; Start-Sleep -Seconds 2 }
    }
    if ($a) { $hostName = $a.IPAddressToString }
  }
  return "${hostName}:$port"
}

# UE4 needs the Visual C++ 2015+ runtime and parts of the DirectX 9 runtime; the game ships
# Microsoft's installer for both.
function Test-Prereqs {
  $sys = "$env:windir\System32"
  return (Test-Path "$sys\vcruntime140.dll") -and (Test-Path "$sys\msvcp140.dll") -and (Test-Path "$sys\xinput1_3.dll")
}

function Get-OurGame { Get-Process Phoenix -ErrorAction SilentlyContinue | Where-Object { $_.Path -and $_.Path -like "$bundle\*" } }

# ---- window -------------------------------------------------------------------------------------

$fg = [Drawing.Color]::FromArgb(230, 232, 238)
$dim = [Drawing.Color]::FromArgb(154, 160, 171)
$good = [Drawing.Color]::FromArgb(124, 199, 127)
$bad = [Drawing.Color]::FromArgb(229, 115, 115)
$gold = [Drawing.Color]::FromArgb(217, 164, 65)

$form = New-Object Windows.Forms.Form
$form.Text = $title
$form.ClientSize = New-Object Drawing.Size(460, 462)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'
$form.BackColor = [Drawing.Color]::FromArgb(29, 32, 39)
$form.ForeColor = $fg
$form.Font = New-Object Drawing.Font('Segoe UI', 10)

$head = New-Object Windows.Forms.Label
$head.Text = 'Join a Prophecy match'
$head.Font = New-Object Drawing.Font('Segoe UI', 14, [Drawing.FontStyle]::Bold)
$head.ForeColor = $gold
$head.SetBounds(18, 12, 420, 30)
$form.Controls.Add($head)

$lbl = New-Object Windows.Forms.Label
$lbl.Text = "Host address (already filled in; change it only if the host gives you a new one):"
$lbl.SetBounds(20, 48, 420, 22)
$lbl.ForeColor = $dim
$form.Controls.Add($lbl)

$box = New-Object Windows.Forms.TextBox
$box.Font = New-Object Drawing.Font('Consolas', 12)
$box.SetBounds(20, 74, 290, 30)
$box.Text = Get-Cfg 'address' ''
$form.Controls.Add($box)

$join = New-Object Windows.Forms.Button
$join.Text = 'Join'
$join.Font = New-Object Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
$join.BackColor = $gold
$join.ForeColor = [Drawing.Color]::FromArgb(26, 26, 26)
$join.FlatStyle = 'Flat'
$join.SetBounds(322, 71, 118, 36)
$form.Controls.Add($join)
$form.AcceptButton = $join

$nameLbl = New-Object Windows.Forms.Label
$nameLbl.Text = 'Your name:'
$nameLbl.SetBounds(20, 119, 90, 22)
$form.Controls.Add($nameLbl)

$nameBox = New-Object Windows.Forms.TextBox
$nameBox.Font = New-Object Drawing.Font('Consolas', 11)
$nameBox.SetBounds(112, 116, 198, 26)
$nameBox.MaxLength = 20
$nameBox.Text = Get-Cfg 'name' ''
$form.Controls.Add($nameBox)

# Rolls a new random name into the box; Join saves it like a typed one.
$reroll = New-Object Windows.Forms.Button
$reroll.Text = 'New'
$reroll.FlatStyle = 'Flat'
$reroll.SetBounds(316, 115, 46, 28)
$reroll.Add_Click({ $nameBox.Text = New-RandomName })
$form.Controls.Add($reroll)
(New-Object Windows.Forms.ToolTip).SetToolTip($reroll, 'Pick a new random name')

$nameHint = New-Object Windows.Forms.Label
$nameHint.Text = 'A-Z 0-9 _ - .'
$nameHint.ForeColor = $dim
$nameHint.SetBounds(368, 119, 90, 22)
$form.Controls.Add($nameHint)

$leaderLbl = New-Object Windows.Forms.Label
$leaderLbl.Text = 'Your leader:'
$leaderLbl.SetBounds(20, 155, 90, 22)
$form.Controls.Add($leaderLbl)

$pick = New-Object Windows.Forms.ComboBox
$pick.DropDownStyle = 'DropDownList'
$pick.SetBounds(112, 152, 198, 26)
[void]$pick.Items.Add('Random')
foreach ($l in $leaders) { [void]$pick.Items.Add(('{0} ({1})' -f $l.name, $l.class)) }
$saved = [int](Get-Cfg 'leader' 0)
$pick.SelectedIndex = 0
for ($i = 0; $i -lt $leaders.Count; $i++) { if ($leaders[$i].id -eq $saved) { $pick.SelectedIndex = $i + 1 } }
$form.Controls.Add($pick)

$table = New-Object Windows.Forms.Button
$table.Text = 'All leaders'
$table.FlatStyle = 'Flat'
$table.SetBounds(322, 150, 118, 28)
$form.Controls.Add($table)

$passive = New-Object Windows.Forms.Label
$passive.SetBounds(20, 182, 420, 56)
$passive.ForeColor = $dim
$form.Controls.Add($passive)

# Skill / passive text as the game has it; a passive named just "<Leader> Passive" shows its text only.
function Get-LeaderText($l, $part, $label) {
  $p = $l.$part
  if (-not $p -or -not $p.description) { return "${label}: not exported yet." }
  $name = if ($p.name -and $p.name -ne "$($l.name) Passive") { "$($p.name): " } else { '' }
  return "${label}: $name$($p.description)"
}
function Show-Passive {
  $passive.Text = if ($pick.SelectedIndex -gt 0) {
    $l = $leaders[$pick.SelectedIndex - 1]
    (Get-LeaderText $l 'skill' 'Skill') + "`n" + (Get-LeaderText $l 'passive' 'Passive')
  } else { 'The host deals you a random leader. If someone already has your pick, you get a random one too.' }
}

# Read-only table window: $columns is a list of @(heading, width[, 'image']), $rows a list of arrays
# (strings, or a System.Drawing.Image / $null in an image column).
function Show-Table($caption, $columns, $rows) {
  $win = New-Object Windows.Forms.Form
  $win.Text = $caption
  $win.ClientSize = New-Object Drawing.Size(900, 480)
  $win.StartPosition = 'CenterParent'
  $win.BackColor = $form.BackColor
  $win.Font = $form.Font
  $grid = New-Object Windows.Forms.DataGridView
  $grid.Dock = 'Fill'
  $grid.ReadOnly = $true
  $grid.AllowUserToAddRows = $false
  $grid.AllowUserToResizeRows = $false
  $grid.RowHeadersVisible = $false
  $grid.SelectionMode = 'FullRowSelect'
  $grid.AutoSizeRowsMode = 'AllCells'
  $grid.BackgroundColor = $form.BackColor
  $grid.DefaultCellStyle.WrapMode = 'True'
  $grid.DefaultCellStyle.BackColor = $form.BackColor
  $grid.DefaultCellStyle.ForeColor = $fg
  $grid.DefaultCellStyle.SelectionBackColor = [Drawing.Color]::FromArgb(50, 55, 68)
  $grid.EnableHeadersVisualStyles = $false
  $grid.ColumnHeadersDefaultCellStyle.BackColor = [Drawing.Color]::FromArgb(21, 23, 28)
  $grid.ColumnHeadersDefaultCellStyle.ForeColor = $gold
  foreach ($c in $columns) {
    if ($c.Count -gt 2 -and $c[2] -eq 'image') {
      $col = New-Object Windows.Forms.DataGridViewImageColumn
      $col.HeaderText = $c[0]
      $col.ImageLayout = 'Zoom'
      $col.DefaultCellStyle.NullValue = $null   # no red "missing image" cross for rows without an icon
      $i = $grid.Columns.Add($col)
    } else {
      $i = $grid.Columns.Add($c[0], $c[0])
    }
    $grid.Columns[$i].Width = $c[1]
  }
  foreach ($r in $rows) { [void]$grid.Rows.Add([object[]]$r) }
  $win.Controls.Add($grid)
  [void]$win.ShowDialog($form)
}

# Every leader: name, class, skill, passive.
$table.Add_Click({
  $rows = foreach ($l in $leaders) {
    ,@($l.name, $l.class, ((Get-LeaderText $l 'skill' 'Skill') -replace '^Skill: ', ''),
      ((Get-LeaderText $l 'passive' 'Passive') -replace '^Passive: ', ''))
  }
  Show-Table 'Leaders' @(@('Leader', 90), @('Class', 70), @('Skill', 360), @('Passive', 360)) $rows
})
$pick.Add_SelectedIndexChanged({ Show-Passive })
Show-Passive

$soloLbl = New-Object Windows.Forms.Label
$soloLbl.Text = 'Play alone:'
$soloLbl.SetBounds(20, 249, 90, 22)
$form.Controls.Add($soloLbl)

$soloPick = New-Object Windows.Forms.ComboBox
$soloPick.DropDownStyle = 'DropDownList'
$soloPick.SetBounds(112, 246, 198, 26)
foreach ($k in $soloGames.Keys) { [void]$soloPick.Items.Add($soloGames[$k]) }
$soloKeys = @($soloGames.Keys)
$savedSolo = [string](Get-Cfg 'solo' 'standard')
if ($savedSolo -eq 'fast-test') { $savedSolo = 'test-solo' }  # renamed 2026-10-30
$soloPick.SelectedIndex = [Math]::Max(0, [array]::IndexOf($soloKeys, $savedSolo))
$form.Controls.Add($soloPick)

$solo = New-Object Windows.Forms.Button
$solo.Text = 'Play solo'
$solo.FlatStyle = 'Flat'
$solo.SetBounds(322, 244, 118, 28)
$form.Controls.Add($solo)

$status = New-Object Windows.Forms.Label
$status.SetBounds(20, 284, 420, 60)
$status.ForeColor = $dim
$status.Text = 'Press Join when the host says they are hosting. You have about a minute; the match starts when everyone is in.'
if ($gameDataNote) { $status.Text = $gameDataNote; $status.ForeColor = $bad }
$form.Controls.Add($status)

$close = New-Object Windows.Forms.Button
$close.Text = 'Close game'
$close.FlatStyle = 'Flat'
$close.SetBounds(20, 350, 110, 30)
$form.Controls.Add($close)

$logBtn = New-Object Windows.Forms.Button
$logBtn.Text = 'Open game log'
$logBtn.FlatStyle = 'Flat'
$logBtn.SetBounds(140, 350, 130, 30)
$form.Controls.Add($logBtn)

$traitBtn = New-Object Windows.Forms.Button
$traitBtn.Text = 'All traits'
$traitBtn.FlatStyle = 'Flat'
$traitBtn.SetBounds(322, 350, 118, 30)
$form.Controls.Add($traitBtn)

# A trait's icon scaled to 32 px, or $null when its PNG isn't in this copy. Read from bytes so the
# file isn't locked (an update can replace it while the window is open).
function Get-TraitIcon($t) {
  $png = Join-Path $iconDir "$($t.icon).png"
  if (-not $t.icon -or -not (Test-Path $png)) { return $null }
  try {
    $img = [Drawing.Image]::FromStream((New-Object IO.MemoryStream(, [IO.File]::ReadAllBytes($png))))
    return (New-Object Drawing.Bitmap($img, 32, 32))
  } catch { return $null }
}

# Every trait: icon, name, bonus, holders needed per tier, effect (tier values filled in, as the game words it).
$traitBtn.Add_Click({
  if (-not $traits) { Say 'No trait list in this copy (traits.json missing). Ask the host for the latest update.' $bad; return }
  $rows = foreach ($t in $traits) {
    ,@((Get-TraitIcon $t), $t.name, $t.bonus, (@($t.tiers | ForEach-Object { $_.holders }) -join '/'), $t.effect)
  }
  Show-Table 'Traits' @(@('', 40, 'image'), @('Trait', 110), @('Bonus', 140), @('Holders', 70), @('Effect', 500)) $rows
})

function Say($text, $color) {
  $status.Text = $text
  $status.ForeColor = if ($color) { $color } else { $dim }
  $form.Refresh()
}

# ---- updates from the host ------------------------------------------------------------------
# Updates come from the feed at update_url (or the host's launcher). Update-Prophecy.ps1 does the
# work (it updates itself first, then installs the payload; docs/server/friend-updates.md), and
# this window restarts into the new version.
$verFile = Join-Path $bundle 'version.txt'
function Get-Version { if (Test-Path $verFile) { (Get-Content $verFile -TotalCount 1).Trim() } else { '' } }
$updater = Join-Path $bin 'Update-Prophecy.ps1'

# update_url as a full URL without a trailing slash, or '' when none is set.
function Get-UpdateUrl {
  $url = [string](Get-Cfg 'update_url' '')
  if (-not $url) { return '' }
  if ($url -notmatch '^https?://') { $url = "http://$url" }
  # GitHub only speaks TLS 1.2+, which Windows PowerShell 5.1 doesn't enable by default.
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  return $url.TrimEnd('/')
}

# The line next to the Update button: result of the last check.
function Set-UpdateState($text, $color) {
  if (-not $updState) { return }
  $updState.Text = $text
  $updState.ForeColor = if ($color) { $color } else { $dim }
}
function Show-CheckResult($latestVersion) {
  $when = Get-Date -Format 'HH:mm'
  if (-not $latestVersion -or $latestVersion -eq (Get-Version)) { Set-UpdateState "Up to date (checked $when)" $good }
  else { Set-UpdateState "Update available: $latestVersion. Press Update or Join." $gold }
}

# 'current', 'unreachable', 'none' (no update_url), 'failed', or 'restarting'.
function Update-FromHost([switch]$ThenJoin) {
  $url = Get-UpdateUrl
  if (-not $url) { Set-UpdateState 'No update address set.'; return 'none' }
  if (-not (Test-Path $updater)) { Set-UpdateState 'Update-Prophecy.ps1 is missing; ask the host for an update zip.' $bad; return 'failed' }
  Say 'Checking for updates ...'
  $out = @(& powershell -NoProfile -ExecutionPolicy Bypass -File $updater -Bundle $bundle -Url $url 2>&1 | ForEach-Object { "$_" })
  $code = $LASTEXITCODE
  $result = [string]($out | Where-Object { $_ -like 'RESULT *' } | Select-Object -Last 1)
  switch ($code) {
    0 { Show-CheckResult ''; return 'current' }
    2 { Set-UpdateState "Couldn't check for updates ($(Get-Date -Format 'HH:mm'))." $bad; return 'unreachable' }
    3 { }
    default {
      $why = if ($result) { $result -replace '^RESULT failed ', '' } else { ($out -join ' ').Trim() }
      Say "Update failed: $why Press Join to try again." $bad
      Set-UpdateState 'Update failed to install.' $bad
      return 'failed'
    }
  }
  Clear-WebMark
  # This script is already in memory, so start the new one and close this window.
  Start-Process powershell -ArgumentList '-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', "`"$PSCommandPath`"", $(if ($ThenJoin) { '-AutoJoin' } else { '-Updated' })
  $form.Close()
  return 'restarting'
}

# Checks shared by Join and Play solo; throws with a message for the status line.
function Assert-CanStart {
  if (-not (Test-Path $exe)) { throw "Phoenix.exe is missing from $bin. Unzip the whole bundle first." }
  if (Get-OurGame) { throw 'The game is already running. Close it first (Close game).' }
  # The 6-card shop screen and the board layout are built here from this copy's own game files.
  # Fast when already built; on failure Patch-Phoenix leaves shop-six / board-layout off below.
  $shopBuild = Join-Path $bin 'Build-ShopScreen.ps1'
  if (Test-Path $shopBuild) {
    Say 'Checking the shop screen ...'
    $script:shopOut = & powershell -NoProfile -ExecutionPolicy Bypass -File $shopBuild 2>&1 | Out-String
    if (Test-Path (Join-Path $bin 'board-layout-delta.json')) {
      Say 'Checking the board layout ...'
      $script:shopOut += & powershell -NoProfile -ExecutionPolicy Bypass -File $shopBuild -Recipe board-layout-delta.json -Label 'board layout' 2>&1 | Out-String
    }
  }
  # Player-side exe patches (RTS camera, all boards visible, ...). Safe to run every time.
  $patcher = Join-Path $bin 'Patch-Phoenix.ps1'
  if (Test-Path $patcher) {
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File $patcher 2>&1
    if ($LASTEXITCODE) { throw ($out | Out-String) }
    # A patch that needs a file this copy doesn't have yet (the 6-card shop screen, the board
    # layout) stays off; the host refuses a copy without it ("incompatible version"), so say why
    # once per window.
    $missing = @($out | Where-Object { "$_" -like 'MISSING *' })
    if ($missing.Count -and -not $script:toldMissing) {
      $script:toldMissing = $true
      [void][Windows.Forms.MessageBox]::Show("This copy is missing a game file it builds for itself (the 6-card shop screen or the board layout), so that part is off and the host will refuse this copy. Click Update and try again (or ask the host for a new bundle).`n`n" + ($missing -join "`n") + $(if ($script:shopOut) { "`n`n" + $script:shopOut.Trim() } else { '' }), $title, 'OK', 'Warning')
    }
  }
  if (-not (Test-Prereqs)) {
    $setup = Join-Path $bundle 'Engine\Extras\Redist\en-us\UE4PrereqSetup_x64.exe'
    $ans = [Windows.Forms.MessageBox]::Show("This PC is missing Visual C++ / DirectX parts the game needs. Install them now? This runs Microsoft's installer that ships with the game. You can say No and try anyway.", $title, 'YesNo', 'Question')
    if ($ans -eq 'Yes' -and (Test-Path $setup)) { Start-Process $setup -Wait }
  }
}

$join.Add_Click({
  try {
    Assert-CanStart
    # After a restart from an update the check already ran; skipping it also rules out a loop.
    if (-not $AutoJoin -and (Update-FromHost -ThenJoin) -in 'failed', 'restarting') { return }
    $script:AutoJoin = $false
    Say 'Finding the host...'
    $addr = Get-JoinAddress $box.Text
    $leaderId = if ($pick.SelectedIndex -gt 0) { [int]$leaders[$pick.SelectedIndex - 1].id } else { 0 }
    $cfg | Add-Member -NotePropertyName leader -NotePropertyValue $leaderId -Force
    # Same rule as Start-Preset.ps1 -Name: only characters that can ride in the join URL.
    # A box left empty gets a random name rather than the game's "Player N".
    $nameBox.Text = ($nameBox.Text -replace '[^A-Za-z0-9_.-]', '')
    if (-not $nameBox.Text) { $nameBox.Text = New-RandomName }
    $cfg | Add-Member -NotePropertyName name -NotePropertyValue $nameBox.Text -Force
    Save-Cfg
    Say "Starting the game and connecting to $addr ..."
    # Keep the last run's log for diagnosis; a fresh log lets the watcher below read from the start.
    if (Test-Path $logFile) { Move-Item $logFile ($logFile -replace '\.log$', '-previous.log') -Force -ErrorAction SilentlyContinue }
    # An empty -Name '' would reach powershell.exe as a bare -Name, so add it only when set.
    $nameArg = if ($nameBox.Text) { @('-Name', $nameBox.Text) } else { @() }
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $bin 'Start-Preset.ps1') -Role client -Connect $addr -Dev $bundle -Leader $leaderId @nameArg 2>&1
    if ($LASTEXITCODE) { throw ($out | Out-String) }
    Say "Game started, connecting to $addr. It loads straight into the match. Keep this window open: it tells you if the connection drops." $good
    Start-Watch
  } catch {
    Say $_.Exception.Message $bad
  }
})
# A game of your own against bots on this PC, no host needed. Start-Preset writes this copy's
# Engine.ini/Game.ini for the preset; the next Join rewrites the boot settings for joining, and the
# Game.ini rules only apply to games this PC runs itself, so nothing needs restoring. Your leader
# pick isn't used: picking needs the leader-pick patch, which only the host's exe has.
$solo.Add_Click({
  try {
    Assert-CanStart
    $preset = $soloKeys[$soloPick.SelectedIndex]
    $cfg | Add-Member -NotePropertyName solo -NotePropertyValue $preset -Force
    try { $cfg | ConvertTo-Json | Set-Content $cfgPath -Encoding ascii } catch { }
    $watch.Stop()
    Say "Starting a solo game ($($soloGames[$preset])) ..."
    $out = & powershell -NoProfile -ExecutionPolicy Bypass -File (Join-Path $bin 'Start-Preset.ps1') -Role solo -Preset $preset -Dev $bundle 2>&1
    if ($LASTEXITCODE) { throw ($out | Out-String) }
    Say 'Solo game started: you against bots, after the intro. Close the game window (or press Close game) when you are done.' $good
  } catch {
    Say $_.Exception.Message $bad
  }
})

# ---- connection watcher ---------------------------------------------------------------------
# When the host closes or the connection drops, the game times out (~25 s) and falls back to its
# empty default map, which ends in "Failed to load package ''". The engine does that fallback on
# its own, so instead this follows the game log: on the first sign of a lost connection it closes
# the game before the fallback and says what happened in plain words.
$joinedRx = 'Welcomed by server|Join succeeded'
$lostRx = 'Network Failure|NetworkFailure|TravelFailure|Connection TIMED OUT|Connection timed out|ConnectionLost|PendingConnectionFailure|Failed to load package '''''
$script:logPos = 0
$script:joined = $false
$watch = New-Object Windows.Forms.Timer
$watch.Interval = 500

function Start-Watch {
  $script:logPos = 0
  $script:joined = $false
  $watch.Start()
}

function Read-NewLog {
  if (-not (Test-Path $logFile)) { return '' }
  try {
    $fs = [IO.File]::Open($logFile, 'Open', 'Read', 'ReadWrite')
    try {
      if ($fs.Length -lt $script:logPos) { $script:logPos = 0 }
      [void]$fs.Seek($script:logPos, 'Begin')
      $text = (New-Object IO.StreamReader($fs)).ReadToEnd()
      $script:logPos = $fs.Length
      return $text
    } finally { $fs.Close() }
  } catch { return '' }
}

$watch.Add_Tick({
  $text = Read-NewLog
  if (-not $script:joined -and $text -match $joinedRx) {
    $script:joined = $true
    Say 'In the match. Keep this window open: it tells you if the connection drops.' $good
  }
  if ($text -match $lostRx) {
    $watch.Stop()
    Get-OurGame | Stop-Process -Force -ErrorAction SilentlyContinue
    if ($script:joined) {
      Say 'The host closed the match, or the connection dropped. The game was closed. Press Join to reconnect when the host is hosting again.' $bad
    } else {
      Say "Couldn't reach the host. Check that they're hosting right now and the address is right, then press Join again." $bad
    }
    return
  }
  if (-not (Get-OurGame)) {
    $watch.Stop()
    if ($script:joined) { Say 'Game closed.' }
  }
})

$close.Add_Click({
  $p = Get-OurGame
  $watch.Stop()
  if ($p) { $p | Stop-Process -Force; Say 'Game closed.' } else { Say 'No game running from this folder.' }
})
$logBtn.Add_Click({ if (Test-Path $logFile) { Start-Process notepad.exe $logFile } else { Say 'No log yet; start the game first.' } })

$updBtn = New-Object Windows.Forms.Button
$updBtn.Text = 'Update'
$updBtn.FlatStyle = 'Flat'
$updBtn.SetBounds(20, 386, 110, 28)
$form.Controls.Add($updBtn)
$updBtn.Add_Click({
  if (Get-OurGame) { Say 'Close the game first, then press Update.'; return }
  switch (Update-FromHost) {
    'none' { Say 'No update address is set; ask the host for an update zip.' }
    'unreachable' { Say "Couldn't reach the update address. Check your internet connection, or ask the host for an update zip." $bad }
    'current' { Say 'You have the latest version.' $good }
  }
})

# Two lines next to the Update button: the last check's result, and this copy's version.
$updState = New-Object Windows.Forms.Label
$updState.Font = New-Object Drawing.Font('Segoe UI', 8.5)
$updState.SetBounds(140, 384, 300, 17)
$form.Controls.Add($updState)
$ver = New-Object Windows.Forms.Label
$v = Get-Version
$ver.Text = if ($v) { "Your version: $v" } else { 'Your version: unknown' }
$ver.ForeColor = $dim
$ver.Font = New-Object Drawing.Font('Segoe UI', 8)
$ver.SetBounds(140, 401, 300, 16)
$form.Controls.Add($ver)

# A sleepy sloth in the lower right corner (plain ASCII: this file has no BOM, so PS 5.1 reads it as ANSI).
$sloth = New-Object Windows.Forms.Label
$sloth.Text = @'
==========/====
    ( -.- ) zZ
    /)   (\
'@
$sloth.Font = New-Object Drawing.Font('Consolas', 8)
$sloth.ForeColor = $gold
$sloth.TextAlign = 'TopLeft'   # per-line right alignment would skew the drawing
$sloth.SetBounds(340, 418, 112, 42)
$form.Controls.Add($sloth)

# On open, check for a newer version in the background (nothing is installed until Update or
# Join), so the window doesn't hang while offline. The download runs as a .NET task and a timer on
# this window's thread polls it, so no PowerShell code runs on another thread.
$checkTimer = New-Object Windows.Forms.Timer
$checkTimer.Interval = 250
$checkTimer.Add_Tick({
  $t = $script:checkTask
  if (-not $t.IsCompleted) {
    if (((Get-Date) - $script:checkStart).TotalSeconds -gt 15) { $checkTimer.Stop(); Set-UpdateState "Couldn't check for updates ($(Get-Date -Format 'HH:mm'))." $bad }
    return
  }
  $checkTimer.Stop()
  if ($t.IsFaulted -or $t.IsCanceled) { Set-UpdateState "Couldn't check for updates ($(Get-Date -Format 'HH:mm'))." $bad; return }
  try { Show-CheckResult ($t.Result | ConvertFrom-Json).version } catch { Set-UpdateState "Couldn't read the update info." $bad }
})
function Start-UpdateCheck {
  $url = Get-UpdateUrl
  if (-not $url) { Set-UpdateState 'No update address set.'; return }
  Set-UpdateState 'Checking for updates ...'
  try {
    $script:checkTask = (New-Object Net.WebClient).DownloadStringTaskAsync([Uri]"$url/latest.json?t=$([DateTime]::UtcNow.Ticks)")
    $script:checkStart = Get-Date
    $checkTimer.Start()
  } catch { Set-UpdateState 'Press Update to check for a newer version.' }
}

$form.Add_Shown({
  # An older join window installed the bootstrap (update.zip) and restarted into this one: run the
  # updater now for the full update (it restarts the window again), then carry on as asked.
  if ((Get-Version) -like '*-bootstrap') {
    Say 'Finishing the update ...'
    if ((Update-FromHost -ThenJoin:$AutoJoin) -eq 'restarting') { return }
  }
  if ($AutoJoin) { Set-UpdateState "Updated to $v." $good; Say "Updated to version $v. Joining ..." $good; $join.PerformClick() }
  elseif ($Updated) { Set-UpdateState "Updated to $v." $good; Say "Updated to version $v. Press Join when the host is hosting." $good }
  else { Start-UpdateCheck }
})

[void]$form.ShowDialog()
