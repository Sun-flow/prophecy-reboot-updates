# Builds leaders.json, traits.json and trait-icons\*.png from the game's own pak files, so game
# text and art never have to ship in the friend bundle or its public updates (mae, 2026-10-30).
# The join window runs it at start; it does nothing when the paks haven't changed since last time.
# The reader is GameData.cs next to this script, compiled by Windows PowerShell itself (Add-Type),
# so nothing is installed. Details: friend\README.md, "Game data".
#
#   Extract-GameData.ps1                                   # in a bundle: <bundle>\gamedata from <bundle>'s paks
#   Extract-GameData.ps1 -Game local\Prophecy-Dev2 -Out local\gamedata-test -Force
#   Extract-GameData.ps1 -Game ... -Out ... -Compare launcher\data      # diff against the launcher's exports
#   Extract-GameData.ps1 -Game ... -Dump Phoenix/Content/Game/DataTables/LeaderTable -Rows   # one asset as JSON
param(
  [string]$Game = '',     # game folder (holds Phoenix\Content\Paks); default: the bundle this script is in
  [string]$Out = '',      # default: <Game>\gamedata
  [string]$Compare = '',  # folder with leaders.json, traits.json, trait-icons\ to compare against
  [string]$Dump = '',     # pak path of one asset, without extension: print its properties as JSON
  [switch]$Rows,          # with -Dump: the asset is a DataTable, print its rows
  [switch]$Force          # extract even if the paks haven't changed
)
$ErrorActionPreference = 'Stop'
if (-not $Game) { $Game = (Resolve-Path "$PSScriptRoot\..\..\..").Path }
$Game = [IO.Path]::GetFullPath($Game)
if (-not $Out) { $Out = Join-Path $Game 'gamedata' }
$Out = [IO.Path]::GetFullPath($Out)
$paks = Join-Path $Game 'Phoenix\Content\Paks'
$source = Join-Path $PSScriptRoot 'GameData.cs'

function Import-Reader {
  if (-not ('ProphecyData.Extractor' -as [type])) {
    Add-Type -Path $source -ReferencedAssemblies System.Drawing
  }
}

if ($Dump) {
  Import-Reader
  $x = New-Object ProphecyData.Extractor($paks)
  return $x.Dump($Dump, [bool]$Rows)
}

# Re-extract only when a pak or the reader changed: size + time of each pak, size of GameData.cs.
$stampFile = Join-Path $Out 'stamp.txt'
$stamp = (@(Get-ChildItem $paks -Filter *.pak | Sort-Object Name | ForEach-Object { "$($_.Name) $($_.Length) $($_.LastWriteTimeUtc.Ticks)" }) +
  "reader $((Get-Item $source).Length)") -join "`n"
$current = (Test-Path $stampFile) -and (Test-Path (Join-Path $Out 'leaders.json')) -and (Test-Path (Join-Path $Out 'traits.json')) -and
  ((Get-Content $stampFile -Raw).Trim() -eq $stamp.Trim())
if ($current -and -not $Force -and -not $Compare) { return 'Game data is up to date.' }

if (-not $current -or $Force) {
  Import-Reader
  $log = [ProphecyData.Extractor]::Run($Game, $Out)
  Set-Content $stampFile $stamp -Encoding ascii
  $log
  "Wrote $Out"
}

if ($Compare) {
  # Field-by-field check against known-good exports (launcher\data on the host PC).
  $Compare = [IO.Path]::GetFullPath($Compare)
  $diffs = New-Object System.Collections.Generic.List[string]
  function Test-Same($what, $a, $b) { if ("$a" -ne "$b") { $diffs.Add("${what}: '$a' vs '$b'") } }
  $mine = (Get-Content (Join-Path $Out 'leaders.json') -Raw -Encoding UTF8 | ConvertFrom-Json).leaders
  $ref = (Get-Content (Join-Path $Compare 'leaders.json') -Raw -Encoding UTF8 | ConvertFrom-Json).leaders
  Test-Same 'leader count' $mine.Count $ref.Count
  $leaderCount = @($ref).Count
  foreach ($r in $ref) {
    $m = $mine | Where-Object { $_.key -eq $r.key } | Select-Object -First 1
    if (-not $m) { $diffs.Add("leader $($r.key) missing"); continue }
    foreach ($f in 'id', 'enabled', 'name', 'class') { Test-Same "leader $($r.key) $f" $m.$f $r.$f }
    foreach ($f in 'name', 'description') { Test-Same "leader $($r.key) passive.$f" $m.passive.$f $r.passive.$f }
    if ($r.skill) { Test-Same "leader $($r.key) skill" $m.skill.description $r.skill.description }
    foreach ($s in $r.stats.PSObject.Properties) { Test-Same "leader $($r.key) $($s.Name)" ([double]$m.stats.($s.Name)) ([double]$s.Value) }
  }
  $mine = (Get-Content (Join-Path $Out 'traits.json') -Raw -Encoding UTF8 | ConvertFrom-Json).traits
  $ref = (Get-Content (Join-Path $Compare 'traits.json') -Raw -Encoding UTF8 | ConvertFrom-Json).traits
  Test-Same 'trait count' $mine.Count $ref.Count
  $traitCount = @($ref).Count
  foreach ($r in $ref) {
    $m = $mine | Where-Object { $_.tag -eq $r.tag } | Select-Object -First 1
    if (-not $m) { $diffs.Add("trait $($r.tag) missing"); continue }
    foreach ($f in 'name', 'bonus', 'effect', 'icon') { Test-Same "trait $($r.name) $f" $m.$f $r.$f }
    Test-Same "trait $($r.name) holders" (@($m.tiers | ForEach-Object { $_.holders }) -join '/') (@($r.tiers | ForEach-Object { $_.holders }) -join '/')
  }
  # Icons: same size and pixels as the launcher's PNGs (two independent decoders).
  Add-Type -AssemblyName System.Drawing
  $refIcons = Join-Path $Compare 'trait-icons'
  $checked = 0
  if (Test-Path $refIcons) {
    foreach ($f in Get-ChildItem $refIcons -Filter *.png) {
      $p = Join-Path $Out "trait-icons\$($f.Name)"
      if (-not (Test-Path $p)) { $diffs.Add("icon $($f.Name) missing"); continue }
      $a = New-Object Drawing.Bitmap($p); $b = New-Object Drawing.Bitmap($f.FullName)
      try {
        if ($a.Width -ne $b.Width -or $a.Height -ne $b.Height) { $diffs.Add("icon $($f.Name): $($a.Width)x$($a.Height) vs $($b.Width)x$($b.Height)"); continue }
        $off = 0
        for ($y = 0; $y -lt $a.Height; $y++) { for ($x = 0; $x -lt $a.Width; $x++) {
          $c = $a.GetPixel($x, $y); $d = $b.GetPixel($x, $y)
          if ([Math]::Abs($c.R - $d.R) + [Math]::Abs($c.G - $d.G) + [Math]::Abs($c.B - $d.B) + [Math]::Abs($c.A - $d.A) -gt 8) { $off++ }
        } }
        if ($off) { $diffs.Add("icon $($f.Name): $off pixels differ") }
        $checked++
      } finally { $a.Dispose(); $b.Dispose() }
    }
  }
  "Compared with ${Compare}: $leaderCount leaders (id, enabled, name, class, passive, skill, stats), $traitCount traits (name, bonus, effect, icon, holders), $checked icons (pixels): $($diffs.Count) differences"
  $diffs | Select-Object -First 60
}
